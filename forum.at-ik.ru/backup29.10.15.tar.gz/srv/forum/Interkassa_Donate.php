<?php
/**
 * Created by PhpStorm.
 * User: Oleg
 * Date: 08.05.2015
 * Time: 17:35
 */

$XF_ROOT1=$_SERVER['DOCUMENT_ROOT'];

//Здесь будем генерить платёжную форму Интеркассы:

$fileDir = dirname(__FILE__);
require($fileDir . '/library/XenForo/Autoloader.php');
XenForo_Autoloader::getInstance()->setupAutoloader($fileDir . '/library');
XenForo_Application::initialize($fileDir . '/library', $fileDir);

$options = XenForo_Application::get('options'); //Получаем список опций

$ID_Interkassa=$options->interkassaDonateId; //Получаем из настроек ID кассы
$Key_Interkassa=$options->interkassaDonateKey; //Получаем из настроек секретный ключ кассы
$Form_Interkassa=$options->InterkassaDonateForma; //Получаем из настроек названия платежа.

$IdPl=mt_rand (5, 800); //Получаем ID платежа... Просто случайное число !

//Сделаем проверку на дурака:*******************************************************************************************

if (isset($_POST['mytext']))
{
    $Pay_InterkassaGet=$_POST['mytext']; //Получаем сколько нужно оплатить из формы доната...
	
	$Pay_Interkassa=filter_var($Pay_InterkassaGet,FILTER_SANITIZE_NUMBER_FLOAT);
}
else
{
    echo 'Dont Worked ! :)';
    exit();
};

//**********************************************************************************************************************

//Для генерации цифровой подписи в начале сформируем строку, по алгоритму протокола Интеркасса:Цена+ID+РУБ+'Описание платежа'+'Номер платежа'+'Секретный ключ'

$SignatureISTR=$Pay_Interkassa.':'.$ID_Interkassa.':'.'RUB'.':'.$Form_Interkassa.':'.$IdPl.':'.$Key_Interkassa;

$SignatureHash=base64_encode(hash('sha256', $SignatureISTR, true)); //Генерим цифровую подпись платежа...

//Генерим платёжную страницу:

$toreturn ='<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Подтверждение платежа !</title>
</head>

<body>



 <form id="payment" name="payment" method="post" action="https://sci.interkassa.com/" enctype="utf-8">
	<input type="hidden" name="ik_co_id" value="'.$ID_Interkassa.'" />
	<input type="hidden" name="ik_pm_no" value= "'.$IdPl.'" />
	<input type="hidden" name="ik_am" value="'.$Pay_Interkassa.'" />
	<input type="hidden" name="ik_cur" value="RUB" />
	<input type="hidden" name="ik_desc" value="'.$Form_Interkassa.'" />
	<input type="hidden" name="ik_sign" value="'.$SignatureHash.'">

	<p align="center"><span lang="ru"><font size="5"><b>Подтверждение платежа:</b></font></span></p>
	&nbsp;

<table align="center">
<tr>
<td>
<font size="5">Сумма платежа:</font></td><td class="estsp_form_plain_description estsp_elastic"><b>
<font size="5">'.$Pay_Interkassa.' рублей</font></b></td></tr><tr><td>
<font size="5">Назначение платежа:</font></td><td class="estsp_form_plain_description estsp_elastic"><b>
	<font size="5">'.$Form_Interkassa.'</font></b></td></tr><tr><td>
<font size="5">Пояснение:</font></td><td class="estsp_form_plain_description estsp_elastic"><b>
	<font size="5">После нажатия на кнопку "Оплатить", Вы сможите оплатить любым удобным способом !</font></b></td></tr>
	</table><table align="center"><tr><td>

	<p>&nbsp;</p>
			<font size="4">
<input type="submit" value="ОПЛАТИТЬ !"></font></td></tr></table></form>
<p><img border="0" src="/PlSystems.png" width="1530" height="683"></p>
</body>

</html>
';

echo $toreturn; //Выводим нашу платёжную страничку...

?>


