<?php
// Init autoloader
require('../packages/DBTech/Shout/Autoloader.php');
DBTech_Shout_Autoloader::register(getcwd() . '/../packages');

if (DBTech_Shout_Core_Admin::getSystem() == 'vBulletin')
{
	error_reporting(E_ALL & ~E_NOTICE);
	define('THIS_SCRIPT', 'vbshout');
	$phrasegroups = $specialtemplates = array();

	require_once('./global.php');
}

// Init the Admin applicatiom
DBTech_Shout_Core_Admin::init();

// Run the action based on URL params
DBTech_Shout_Core_Admin::runAction();

// Render page output
DBTech_Shout_Core_Admin::renderOutput(DBTech_Shout_Core_Admin::getOutput());
?>