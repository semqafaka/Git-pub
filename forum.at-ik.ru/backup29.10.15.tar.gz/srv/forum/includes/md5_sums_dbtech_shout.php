<?php
/*======================================================================*\
|| #################################################################### ||
|| # ---------------------------------------------------------------- # ||
|| # Copyright ©2014 DragonByte Technologies					 	  # ||
|| # All Rights Reserved. 											  # ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ---------------------------------------------------------------- # ||
|| # You are not allowed to use this on your server unless the files  # ||
|| # you downloaded were done so with permission.					  # ||
|| # ---------------------------------------------------------------- # ||
|| #################################################################### ||
\*======================================================================*/

$md5_sums = array (
  '/' => 
  array (
    'vbshout.php' => '96d2bb19d1fb4538190045cf1eec5bc6',
  ),
  '/admincp' => 
  array (
    'vbshout.php' => 'db55653ddab28ff62384f116ab97feee',
  ),
  '/library/DBTech/Shout' => 
  array (
    'Install.php' => '75cbf9eb930176672d8b5b050f31645d',
  ),
  '/library/DBTech/Shout/ControllerAdmin' => 
  array (
    'Vbshout.php' => 'd0c2863fab7edbe7750ee4ae694f9ae1',
  ),
  '/library/DBTech/Shout/ControllerPublic' => 
  array (
    'Profile.php' => '9e82233a6051c84b25eba251c0dde67d',
  ),
  '/library/DBTech/Shout/DataWriter/Discussion' => 
  array (
    'Thread.php' => '0ab13354ddfdfd0232571a99823cace2',
  ),
  '/library/DBTech/Shout/DataWriter/DiscussionMessage' => 
  array (
    'Post.php' => 'e072414d598e450be478dddadee74802',
  ),
  '/library/DBTech/Shout/EventListener' => 
  array (
    'TemplateHook.php' => '425e2b531bb72a13f9f2359f271ae599',
    'FrontControllerPostView.php' => '21c88ee9cb69f2c103cbfeed3221e814',
    'LoadClass.php' => 'c60028cefff3e1fe0349295d89ee5ee4',
    'TemplatePostRender.php' => '4d4d288dc1547ec18343d43e8fb390aa',
  ),
  '/library/DBTech/Shout/Install' => 
  array (
    '510.php' => 'fb38f8eecb8a631321291b099c41ceab',
    '520.php' => '36c8ff354ab10e0e8f078fb8e35d1100',
    '450.php' => '43255f291d5ab73d3c06630cee40ca46',
    '621.php' => 'febf77a95e1d4e421e3b8dd29f2d4860',
    '530.php' => '35bc12ee175f755ed33b5b47ec47f370',
    'Uninstall.php' => 'ba07cccbcd4c28c0539d23082f269af0',
    '620.php' => '56e662ce0648fe3ff5f62340a7bf2ac1',
    '603.php' => '1f025c0b781224f13185ee1cc144ed93',
    '400.php' => '9daac8801244306f7bccb72dfd778efe',
    '500.php' => '4b5698d6ec4d2a7b1027b787bed93677',
    '540.php' => '46e6214631edc892ba69448d94087b15',
    '600.php' => '1209b6c050598cfe5ca2dadc3a7a8767',
    '628.php' => 'c05138c9cd55cfb2ebcb693f159b50f8',
  ),
  '/library/DBTech/Shout/Option' => 
  array (
    'BrandingFree.php' => '7c63b75f6b595c586b8459c7cea8c398',
  ),
  '/library/DBTech/Shout/Route/Prefix' => 
  array (
    'Profile.php' => '58412de64f7bb3888176940d39320502',
  ),
  '/library/DBTech/Shout/Route/PrefixAdmin' => 
  array (
    'Vbshout.php' => '5ab6fdc116ab296de066788d6f9f27b7',
  ),
  '/packages/DBTech/Shout' => 
  array (
    'Autoloader.php' => 'bc17560016582edc6fc4fee6be71f9ac',
    'DataManager.php' => 'bd80bd9bfcff54c98118d723f4a73714',
    'Database.php' => 'c95fdac7662beeacdb44ccd644fa52ae',
    'adminfunctions_xenforo.php' => '12e02c821457ef8f4428bb96d6386aa5',
    'Shoutbox.php' => 'c769669a511e53536ffb2d61c90b64c0',
    'adminfunctions_vbulletin.php' => '773e99ea3cdca0b01858c22de8d46a99',
    'Cache.php' => '4bbc8adaf2f76516ca90a3c7d9800c5f',
    'Core.php' => 'b0bc9169f7b9ba7a59fd40d62d41f390',
  ),
  '/packages/DBTech/Shout/Action' => 
  array (
    'Ajax.php' => '1129b87aa9974afcd9088f61eaa87573',
    'Archive.php' => 'd762d967df462b4fed6ff7ef20bb3063',
    'Abstract.php' => '4c8e8d04327617883e12d018041347ee',
  ),
  '/packages/DBTech/Shout/Action/Admin' => 
  array (
    'Options.php' => 'b326024abfbabe40acd49933cadd1da0',
    'Commandlog.php' => '0d2735454b247c449fd0f4db30f06a12',
    'Download.php' => '8e820861fc2aff6fbe4ab59223fddc56',
    'Instance.php' => '83222a1ff194a2b534913cbcc6f22e7b',
    'Banned.php' => 'aeda8251ae7e81c1c37d591913b26ff0',
    'Repaircache.php' => 'ec52664d5250bf19883e6966d71baeda',
    'Chatroom.php' => 'cfee5cb7bbc1f48be2ecac2db66a58a3',
    'Notifications.php' => '018f15e1d088c1b656ee0af67ed75724',
    'Abstract.php' => 'fe916c0670dd87d1d02cf2b951875f8f',
  ),
  '/packages/DBTech/Shout/Action/Ajax' => 
  array (
    'Invisible.php' => '796014420b701bc0083b6d8584454f9c',
    'Save.php' => 'dd4198375717e9e08367940d7f4f0c50',
    'Usermanage.php' => 'a1e60f8889e01216891e62e3f44cdaa9',
    'Fetchsticky.php' => 'c49e69a8a6717eb4304416f34dd48352',
    'Styleprops.php' => '65bc25c2e1ab7cc05b5dccef059e43d1',
    'Lookup.php' => '4aef3cabab28e75cba2d1f717c0cf1a2',
    'Joinchat.php' => '99ab7598165f741cfe925c1fa02dcbbe',
    'Leavechat.php' => 'afd3f9921d7f9cb3616ff90d3c31f7fd',
    'Sounds.php' => 'dc1ea81f800c45fd8ec31541b6b4a9cc',
    'Createchat.php' => '32528b986743426c9788dea61c821dbc',
    'Unidle.php' => 'aa6da1a66c9c3b7980ac02ab5cb42285',
    'Delete.php' => '26d79a1b022c29ea245ca60320753d10',
    'Fetch.php' => '3f64b006024382944d27e2f1df6536bd',
  ),
  '/packages/DBTech/Shout/Core' => 
  array (
    'Admin.php' => '20c5b43848756b864edfacd5b45fa461',
  ),
  '/packages/DBTech/Shout/Data/JS' => 
  array (
    'jquery.tmpl.min.js' => '2b26540d6761fa6eb1e66d97ec176364',
    'vbshout.js' => 'e387d89f0efd5ef30adea18fbbab25fd',
  ),
  '/packages/DBTech/Shout/DataManager' => 
  array (
    'Instance.php' => 'ba76426d56a9d6475195aefa263e1257',
    'Chatroom.php' => '8dedfd50c1c31e0aa637e4092d2ffc5f',
    'Shout.php' => '5a22a736d22ec7cde2c5cfc97ff70996',
  ),
  '/packages/DBTech/Shout/DataManager/Helper' => 
  array (
    'Instance.php' => '6ef1c58382d59bfd149d6e6b43600a8a',
    'Chatroom.php' => '3f31e6068ff1bab9261cb1f366f96609',
    'Shout.php' => '7e4a003346c0010dd971af34b5f862ce',
  ),
);

$md5_sum_softwareid = 'dbtech_shout';
$md5_sum_versions['dbtech_shout'] = '7.0.0 Beta 3';
?>