!function($, window, document, _undefined) {
	$(function() {
		var chat = $('#siropuChat');
		var chatElements = $('#siropuChat, #siropuChatBar');
		var chatBar = $('#siropuChatBar');
		var chatToggle = $('#siropuChatToggle');
		var chatSettings = $('#siropuChatSettings');
		var chatMessages = $('#siropuChatMessages');
		var chatRooms = $('#siropuChatRooms');
		var chatToggleRooms = $('#siropuChatToggleRooms');
		var chatUsers = $('#siropuChatUsers');
		var chatLastMassage = $('#siropuChatLastMessage');
		var chatEditor = $('#siropuChatEditor');
		var chatInput = chatEditor.find('input[name="message"]');
		var chatSubmit = $('#siropuChatSubmit');
		var chatAjaxURL = 'index.php?chat/';
		var chatSoundAlert = new Audio('styles/Siropu/Chat/sounds/alert.mp3');
		var chatSoundError = new Audio('styles/Siropu/Chat/sounds/error.mp3');

		if (window.chatRefreshActiveVisible == undefined) {
			window.chatRefreshActiveVisible = 5000;
		}
		if (chatRefreshActiveHidden == undefined) {
			window.chatRefreshActiveHidden = 15000;
		}
		if (chatRefreshInactiveVisible == undefined) {
			window.chatRefreshInactiveVisible = 30000;
		}
		if (chatRefreshInactiveHidden == undefined) {
			window.chatRefreshInactiveHidden = 60000;
		}

		$(window).resize(function() {
			if (window.matchMedia('(min-width: 800px)').matches
				&& chatUsers.is(':hidden')
				&& !chat.hasClass('siropuChatNoUsers')
				&& !chat.hasClass('siropuChatSidebar')) {
				chatUsers.show();
			}
			chatAdjustMaximizedHeight();
		});

		function chatGetSettings($setting) {
			return chatSettings.find('input[name="' + $setting + '"]').is(':checked');
		}

		function chatAutoscroll($inverse) {
			chatMessages.scroll(function() {
				chat.attr('data-autoscroll', 0);
				if ((chatMessages.scrollTop() == chatMessages[0].scrollHeight - chatMessages.innerHeight() && !$inverse)
					|| chatMessages.scrollTop() == 0 && $inverse) {
					chat.attr('data-autoscroll', 1);
				}
			});

			if (chat.attr('data-autoscroll') == 1) {
				if ($inverse) {
					chatMessages.scrollTop(0);
				} else {
					chatMessages.scrollTop(1000000);
				}
			}
		}

		var chatPageTitle = $('title').text();
		var chatPageFocus = true;
		var titleBlinkInterval = '';

		$(window).blur(function() {
			chatPageFocus = false;
		});

		$(window).focus(function() {
			chatPageFocus = true;
			clearInterval(titleBlinkInterval);
			$('title').text(chatPageTitle);
		});

		function chatPlaySound($sound, $enabled) {
			if (chatMessages.attr('data-last-id') > 0
				&& chatMessages.attr('data-last-id') != chatMessages.find('> li:last').attr('id')) {
				if ($enabled && chatPageFocus) {
					$sound.play();
				}
				if (!chatPageFocus && window.chatNewMessageBlinkAlert) {
					clearInterval(titleBlinkInterval);
					titleBlinkInterval = setInterval(function() {
						$('title').text($('title').text() == chatPageTitle ? window.chatPhrases.new_message : chatPageTitle);
					}, 1500);
				}
			}
		}

		function chatWrapText(text, tag) {
			return '[' + tag + ']' + text + '[/' + tag + ']';
		}

		function chatInsertBBCode(tag) {
			var len = chatInput.val().length;
			var start = chatInput[0].selectionStart;
			var end = chatInput[0].selectionEnd;
			var selectedText = chatInput.val().substring(start, end);
			chatInput.val(chatInput.val().substring(0, start) + chatWrapText(selectedText, tag) + chatInput.val().substring(end, len)).focus();
		}

		function chatChangeColor() {
			var chatSelectColor = $('#siropuChatSelectColor');
			if (chatSelectColor.length) {
				chatSelectColor.find('label').css('color', '#' + chatSelectColor.find('select').val());
			}
		}

		function chatAdjustMaximizedHeight() {
			if (chat.hasClass('siropuChatAllPages')) {
				var chatContent = $('#siropuChatContent');
				var chatNoticeHeight = $('#siropuChatNotice').outerHeight(true);
				var chatAdsHeight = 0;
				$('.siropuChatAds').each(function() {
					if (!$(this).parents('#siropuChatEditor').length) {
						chatAdsHeight += $(this).outerHeight(true);
					}
				});
				if (chat.hasClass('siropuChatMaximized')) {
					chatContent.css('height', chat.height() - chatEditor.outerHeight(true) - $('#siropuChatHeader').outerHeight(true) - chatNoticeHeight - chatAdsHeight - (chatMessages.outerHeight(true) - chatMessages.height()) - 2 + 'px');
				} else {
					chatContent.attr('style', '');
				}
			}
		}

		function chatUpdateUserCount($count) {
			if ($count) {
				chatToggle.find('span').text($count);
			}
		}

		function chatGetRooms() {
			chatRooms.html('');
			XenForo.ajax(
				chatAjaxURL + 'rooms-get',
				{},
				function(ajaxData) {
					chatRooms.html(ajaxData.rooms).xfActivate();
					if ($('#siropuChatRooms > li').length > 5) {
						chatInput.focus().val('/room ').focus();
					}
				},
				{global: false, error: false}
			);
		}

		function chatCloseOverlay($this) {
			$this.find('.OverlayCloser').trigger('click');
		}

		function chatGetUint($option) {
			if ($option) {
				return 1;
			} else {
				return 0;
			}
		}

		function chatRemoveDuplicates() {
			var list = [];
			var data = [];
			if (chatGetSettings('inverse')) {
				data = $('#siropuChatMessages > li').slice(0, 10);
			} else {
				data = $('#siropuChatMessages > li').slice(-10);
			}
			data.each(function() {
				var id = $(this).attr('id');

				if (list[id]) {
					$(this).remove();
				} else {
					list[id] = true;
				}
			});
		}

		function chatGetMessages() {
			if (chatInput.is(':disabled')) {
				return false;
			}
			XenForo.ajax(
				chatAjaxURL + 'refresh',
				{
					room_id: chat.attr('data-room-id'),
					last_id: chatMessages.attr('data-last-id'),
					inverse: chatGetUint(chatGetSettings('inverse')),
					no_users: chatGetUint(chatGetSettings('hide_chatters')),
					show_ignored: chatGetUint(chatGetSettings('show_ignored')),
					all_pages: chatGetUint(chat.hasClass('siropuChatAllPages')),
					embedded: chatGetUint(chat.hasClass('siropuChatEmbedded')),
				},
				function(ajaxData) {
					if (ajaxData.messageActions) {
						$messageActions = jQuery.parseJSON(ajaxData.messageActions);
						for (var $id in $messageActions) {
							var $row = chatMessages.find('li[id="' + $id + '"]');
							switch ($messageActions[$id]['action']) {
								case 'prune':
									if (!$row.length) {
										chatMessages.html('');
									}
									break;
								case 'delete':
									$row.remove();
									break;
								case 'edit':
									var $message = $messageActions[$id]['message'];
									if ($message && $message != $row.find('.siropuChatMessage').html()) {
										$row.find('.siropuChatMessage').html($message);
									}
									break;
							}
						}
					}
					if (ajaxData.messages != '') {
						if (chatMessages.attr('data-last-id')) {
							if (chatGetSettings('inverse')) {
								chatMessages.prepend(ajaxData.messages);
							} else {
								chatMessages.append(ajaxData.messages);
							}
						} else {
							chatMessages.html(ajaxData.messages);
						}
						chatPlaySound(chatSoundAlert, chatGetSettings('sound'));
						chatMessages.attr('data-last-id', ajaxData.lastId);
						if (ajaxData.lastRow) {
							chatLastMassage.html(ajaxData.lastRow);
						}
						chatRemoveDuplicates();
						chatAutoscroll(chatGetSettings('inverse'));
					}
					if (ajaxData.refreshUserList) {
						chatUsers.html(ajaxData.users);
						chatUpdateUserCount(ajaxData.userCount);
					}
					if (chat.hasClass('siropuChatAllPages')) {
						chatElements.xfActivate();
					} else {
						chat.xfActivate();
					}
				},
				{global: false, error: false}
			);
		}

		if (!chat.hasClass('siropuChatPage')) {
			chatGetMessages();
		}

		function chatInitRefreshInterval() {
			if (chat.attr('data-session') == 1) {
				if (chat.is(':visible')) {
					chatRefreshInterval = setInterval(chatGetMessages, window.chatRefreshActiveVisible);
				} else {
					chatRefreshInterval = setInterval(chatGetMessages, window.chatRefreshActiveHidden);
				}
			} else {
				if (chat.is(':visible')) {
					chatRefreshInterval = setInterval(chatGetMessages, window.chatRefreshInactiveVisible);
				} else {
					chatRefreshInterval = setInterval(chatGetMessages, window.chatRefreshInactiveHidden);
				}
			}
		}

		setTimeout(function() {
			chatAutoscroll(chatGetSettings('inverse'));
		}, 1500);

		chatInitRefreshInterval();
		chatChangeColor();

		chatBar.click(function(e) {
			chat.toggle();
			chatLastMassage.toggle();
			chatToggle.toggleClass('siropuChatActiveTab');
			clearInterval(chatRefreshInterval);
			chatInitRefreshInterval();
			chatAutoscroll(chatGetSettings('inverse'));
			chatInput.focus();
			chatAdjustMaximizedHeight();
		});

		chatToggle.click(function(e) {
			e.preventDefault();
		});

		var chatFocus = false;

		$('#siropuChat, #siropuChatBar').mouseover(
			function() {
				chatFocus = true;
			}
		)
		.mouseout(
			function() {
				chatFocus = false;
			}
		);

		$(document).click(function(e) {
			if (chat.is(':visible') && !$('.xenOverlay:visible').length && !$('.Menu:visible').length && !chatFocus) {
				chatBar.trigger('click');
			}
		});

		chatMessages.on('click', '.siropuChatContentLeft > .username', function(e) {
			e.preventDefault();
			var author = $(this).parents('li').data('author');
			if (author && chat.data('user') != author
				&& !chatInput.val().match(author.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1"))) {
				var tagData = chatInput.val() + '@' + author + ', ';
				chatInput.focus().val(tagData).focus();
			}
		});

		$(document).on('click', '.siropuChatWhisperAction', function(e) {
			e.preventDefault();
			chatInput.focus();
			if (($(this).hasClass('Tooltip') || !chatInput.val().match(/\/whisper/)) && chatInput.val().length) {
				chatInput.val('');
			}
			var username = $(this).data('username');
			var inputData = chatInput.val();
			if (!inputData.match(username.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1"))) {
				if (inputData.match(/whisper/)) {
					chatInput.val(inputData.replace(']', ', ' + username + ']')).focus();
				} else {
					chatInput.val('/whisper [' + username + '] ').focus();
				}
			} else {
				var newInput = inputData.replace(username, '').replace(', ', '');
				chatInput.val(newInput.match(/\[\]/) ? '' : newInput).focus();
			}
		});

		$(document).on('click', '.siropuChatQuote', function(e) {
			e.preventDefault();
			XenForo.ajax(
				$(this).attr('href'),
				{},
				function(ajaxData) {
					if (ajaxData.quotedMessage && ajaxData.quotedMessage != chatInput.val().trim()) {
						chatInput.val((chatInput.val() ? chatInput.val() + ' ' : '') + ajaxData.quotedMessage + ' ');
					}
					chatInput.focus();
				},
				{global: false, error: false}
			);
		});

		$(document).on('click', '#siropuChatBBCode button', function() {
			var $this = $(this);
			var type = $this.data('type');
			var tag = $this.data('tag');
			switch (type) {
				case 'tag':
					chatInsertBBCode(tag);
					break;
				case 'link':
				case 'image':
				case 'media':
				case 'quote':
				case 'spoiler':
				case 'code':
					XenForo.ajax(
						chatAjaxURL + 'media',
						{
							type: type,
						},
						function(ajaxData) {
							XenForo.createOverlay(null, ajaxData.templateHtml).load();
						},
						{global: false, error: false}
					);
					break;
				case 'smilie':
					var $smilies = $('<div id="siropuChatSmilies" />');
					if (!$('#siropuChatSmilies').length) {
						XenForo.ajax(
							'index.php?editor/smilies',
							{},
							function(ajaxData) {
								$smilies.html(ajaxData.templateHtml);
								$this.parent().after($smilies);
								$smilies.xfActivate();
								chatAdjustMaximizedHeight();
							},
							{global: false, error: false}
						);
					}
					$('#siropuChatSmilies').toggle();
					chatAdjustMaximizedHeight();
					break;
			}
		});

		$(document).on('submit', '#siropuChatMedia', function(e) {
			e.preventDefault();
			var $this = $(this);
			var url = $this.find('input[name="url"]').val();
			var content = $this.find('textarea').val();
			var insert = '';
			switch ($this.data('type')) {
				case 'link':
					insert = chatWrapText(url, 'URL');
					break;
				case 'image':
					insert = chatWrapText(url, 'IMG');
					break;
				case 'media':
					XenForo.ajax(
						'index.php?editor/media',
						$this.serialize(),
						function(ajaxData) {
							chatInput.val(chatInput.val() + ajaxData.matchBbCode).focus();
						},
						{global: false, error: false}
					);
					break;
				case 'quote':
					var name = $this.find('input[name="name"]').val();
					insert = '[QUOTE' + (name ? '=' + name : '') + ']' + (content ? content : '') + '[/QUOTE]';
					break;
				case 'spoiler':
					var title = $this.find('input[name="title"]').val();
					insert = '[SPOILER' + (title ? '=' + title : '') + ']' + (content ? content : '') + '[/SPOILER]';
					break;
				case 'code':
					insert = chatWrapText(content, $this.find('select').val());
					break;
			}
			if (insert) {
				chatInput.val(chatInput.val() + insert).focus();
			}
			chatCloseOverlay($this);
			if ($('#siropuChatMedia').attr('data-submit')) {
				chatSubmit.submit();
			}
			$('#siropuChatMedia').removeAttr('data-submit');
		});

		$(document).on('click', '#siropuChatInsertSubmit', function() {
			$('#siropuChatMedia').attr('data-submit', true);
		});

		$(document).on('click', '#siropuChatToggleRooms', function(e) {
			e.preventDefault();
			if (chatRooms.is(':hidden')) {
				chatGetRooms();
			} else {
				chatInput.val('').focus();
			}
			chatRooms.toggle();
			chatMessages.toggle();
		});

		$(document).on('click', '#siropuChatSmilies .Smilie', function() {
			chatInput.val(chatInput.val() + ' ' + $(this).find('img').attr('alt')).focus();
		});

		$(document).on('click', '#siropuChatToggleUsers', function(e) {
			e.preventDefault();
			chatUsers.toggle();
		});

		$(document).on('click', '.siropuChatKick', function(e) {
			e.preventDefault();
			XenForo.ajax(
				chatAjaxURL + 'kick',
				{
					user_id: $(this).data('user-id')
				},
				function(ajaxData) {
					if (!XenForo.hasResponseError(ajaxData)) {
						if (ajaxData.kicked) {
							chatUsers.find('li[id="' + ajaxData.kicked + '"]').remove();
						}
					} else {
						chatSoundError.play();
					}
				},
				{global: false, error: false}
			);
		});

		$(document).on('click', '.siropuChatLogout', function(e) {
			e.preventDefault();
			XenForo.ajax(
				chatAjaxURL + 'logout',
				{},
				function(ajaxData) {
					if (!XenForo.hasResponseError(ajaxData)) {
						if (ajaxData.loggedOut) {
							chatUsers.find('li[id="' + ajaxData.loggedOut + '"]').remove();
							chat.attr('data-session', 0);
						}
					} else {
						chatSoundError.play();
					}
				},
				{global: false, error: false}
			);
		});

		$(document).on('mouseover', '#siropuChatMessages > li', function() {
			var $messageActions = $(this).find('.siropuChatMessageActions');
			if ($messageActions.find('li').length) {
				$(this).find('.DateTime').hide();
				$messageActions.css('display', 'inline-block');
			}
		});

		$(document).on('mouseout', '#siropuChatMessages > li', function() {
			$(this).find('.DateTime').show();
			$(this).find('.siropuChatMessageActions').hide();
		});

		$('#siropuChatSettings input, #siropuChatSettings select').change(function() {
			var form = $(this).parents('form');
			var name = $(this).attr('name');
			switch (name) {
				case 'maximized':
					chat.toggleClass('siropuChatMaximized');
					chatAdjustMaximizedHeight();
					break;
				case 'inverse':
					chatAutoscroll(chatGetSettings('inverse'));
					break;
				case 'editor_on_top':
					if (confirm(window.chatPhrases.action_reload)) {
						location.reload();
					}
					break;
				case 'color':
					chatChangeColor();
					break;
				case 'hide_chatters':
					chat.toggleClass('siropuChatNoUsers');
					break;
				case 'disabled':
					if (chatGetSettings('disabled')) {
						$('#siropuChat, #siropuChatBar').fadeOut();
					} else {
						$('#siropuChat, #siropuChatBar').fadeIn();
					}
					break;
			}

			XenForo.ajax(
				chatAjaxURL + 'settings',
				form.serialize(),
				function(ajaxData) {
					if (name == 'display_mode'
						&& !chat.hasClass('siropuChatPage')
						&& confirm(window.chatPhrases.action_reload)) {
						location.reload();
					}
					if (!chatSettings.attr('data-warning')) {
						XenForo.hasResponseError(ajaxData);
					}
					chatSettings.attr('data-warning', true)
				},
				{error: false}
			);
		});

		$(document).on('click', '.siropuChatColorPicker input.save', function() {
			chatSettings.find('input[name="color"]').val($('.siropuChatColorPicker').find('input[name="remove"]').is(':checked') ? '' : $('.siropuChatColorPicker').find('#pctrl_h').val());
			XenForo.ajax(
				chatAjaxURL + 'settings',
				chatSettings.serialize(),
				function(ajaxData) {},
				{error: false}
			);
		});

		chatInput.keyup(function() {
			var input = $(this).val();
			if (chatRooms.is(':visible') && input.match(/\/room/)) {
				var regex = new RegExp(input.replace('/room', '').trim(), 'gi');
				$('#siropuChatRooms > li').hide().each(function() {
					if ($(this).data('name').match(regex)) {
						$(this).show();
					}
				});
			}
		});

		$(document).on('submit', '#siropuChatRoomDelete', function(e) {
			e.preventDefault();
			var $this = $(this);
			XenForo.ajax(
				chatAjaxURL + 'rooms/delete',
				$(this).serialize(),
				function(ajaxData) {
					if (!XenForo.hasResponseError(ajaxData)) {
						if (ajaxData.roomId != '') {
							chatRooms.find('li[id="' + ajaxData.roomId + '"]').fadeOut();
						}
						chatCloseOverlay($this);
					}
				},
				{global: false, error: false}
			);
		});

		$(document).on('submit', '#siropuChatRoomAdd', function(e) {
			e.preventDefault();
			var $this = $(this);
			XenForo.ajax(
				chatAjaxURL + 'rooms/save',
				$this.serialize(),
				function(ajaxData) {
					if (!XenForo.hasResponseError(ajaxData)) {
						if (ajaxData.roomAdded) {
							if (chatRooms.is(':hidden')) {
								chatToggleRooms.trigger('click');
							} else {
								chatGetRooms();
							}
							chatCloseOverlay($this);
						}
					} else {
						chatSoundError.play();
					}
				}
			);
		});

		$(document).on('submit', '.siropuChatRoomActions form', function(e) {
			e.preventDefault();
			var $this = $(this);
			var $password = $this.find('input[name="password"]');
			if ($password.length && !$password.val().trim()) {
				$password.toggle().css('right', $(this).find('button').outerWidth()).focus();
				return false;
			}
			XenForo.ajax(
				chatAjaxURL + 'rooms/join',
				$this.serialize(),
				function(ajaxData) {
					if (!XenForo.hasResponseError(ajaxData)) {
						chatRooms.toggle();
						chatMessages.toggle();
						chat.attr('data-room-id', $this.find('input[name="room_id"]').val());
						chatMessages.html(ajaxData.messages);
						chatMessages.attr('data-last-id', ajaxData.lastId);
						chatUsers.html(ajaxData.users);
						chatToggle.find('span').text(ajaxData.userCount);
						if (ajaxData.lastRow) {
							chatLastMassage.html(ajaxData.lastRow);
						}
						chatAutoscroll(chatGetSettings('inverse'));
						$('#siropuChatHeader h3 span').text(' - ' + $this.parents('li').data('name'));
						chatInput.val('').focus();
						if ($('#siropuChatBannedMessage').length) {
							if (confirm(window.chatPhrases.reload_page)) {
								location.reload();
							}
						}
						if (chat.hasClass('siropuChatAllPages')) {
							chatElements.xfActivate();
						} else {
							chat.xfActivate();
						}
					} else {
						chatSoundError.play();
					}
				},
				{global: false, error: false}
			);
		});

		$(document).on('submit', '#siropuChatEditor form', function(e) {
			e.preventDefault();
			var message = chatInput.val().trim();
			var placeholder = chatInput.attr('placeholder');
			if (!message) {
				chatInput.focus();
				return false;
			}
			if (message.match(/^\/clear/)) {
				chatMessages.html('');
				chatInput.val('').focus();
				return false;
			}
			if (message.match(/^\/help/) || message.match(/^\/rules/)) {
				if (message.match(/^\/help/)) {
					$action = 'help';
				} else {
					$action = 'rules';
				}
				XenForo.ajax(
					chatAjaxURL + $action,
					{},
					function(ajaxData) {
						XenForo.createOverlay(null, ajaxData.templateHtml, {
							title: ajaxData.title,
							fixed: false,
							className: 'siropuChatHelp'
						}).load();
						chatInput.val('').focus();
					},
					{error: false}
				);
				return false;
			}
			if (message.match(/^\/rooms/)) {
				chatInput.val('').focus();
				chatToggleRooms.trigger('click');
				return false;
			}
			if (message.match(/^\/quit/)) {
				var $quit = true;
			} else {
				var $quit = false;
			}
			clearInterval(chatRefreshInterval);
			chatInput.prop('disabled', true).val('').attr('placeholder', window.chatPhrases.please_wait);
			chatSubmit.prop('disabled', true).addClass('disabled');
			XenForo.ajax(
				chatAjaxURL + 'submit',
				{
					message: message,
					room_id: chat.attr('data-room-id'),
					last_id: chatMessages.attr('data-last-id'),
					inverse: chatGetUint(chatGetSettings('inverse')),
					no_users: chatGetUint(chatGetSettings('hide_chatters')),
					show_ignored: chatGetUint(chatGetSettings('show_ignored')),
					all_pages: chatGetUint(chat.hasClass('siropuChatAllPages')),
					embedded: chatGetUint(chat.hasClass('siropuChatEmbedded')),
				},
				function(ajaxData) {
					if (!XenForo.hasResponseError(ajaxData)) {
						if ($quit) {
							chat.attr('data-session', 0);
						}
						if (ajaxData.prune) {
							if (ajaxData.prune == 'all') {
								chatMessages.html('');
							} else {
								chatMessages.find('li[data-author="' + ajaxData.prune + '"]').remove();
							}
						}
						if (ajaxData.messages != '') {
							if (chatMessages.attr('data-last-id')) {
								if (chatGetSettings('inverse')) {
									chatMessages.prepend(ajaxData.messages);
								} else {
									chatMessages.append(ajaxData.messages);
								}
							} else {
								chatMessages.html(ajaxData.messages);
							}
							chatPlaySound(chatSoundAlert, chatGetSettings('sound'));
							chatMessages.attr('data-last-id', ajaxData.lastId);
							if (ajaxData.lastRow) {
								chatLastMassage.html(ajaxData.lastRow);
							}
							chatAutoscroll(chatGetSettings('inverse'));
							if (chat.attr('data-session') == 0 && !$quit) {
								chat.attr('data-session', 1);
							}
							chatInitRefreshInterval();
							if (chatRooms.is(':visible')) {
								chatToggleRooms.trigger('click');
							}
							chatRemoveDuplicates();
						}
						if (ajaxData.refreshUserList) {
							chatUsers.html(ajaxData.users);
							chatUpdateUserCount(ajaxData.userCount);
						}
						if (ajaxData.kick) {
							chatUsers.find('li[id="' + ajaxData.kick + '"]').remove();
						}
						if (chat.hasClass('siropuChatAllPages')) {
							chatElements.xfActivate();
						} else {
							chat.xfActivate();
						}
					} else {
						chatSoundError.play();
					}
					chatInput.prop('disabled', false).attr('placeholder', placeholder).focus();
					chatSubmit.prop('disabled', false).removeClass('disabled');
				},
				{global: false, error: false}
			);
		});
	});
} (jQuery, this, document);