!function($, window, document, _undefined) {
	$(document).on('click', '#siropuChatEnable', function() {
		var $this = $(this);
		XenForo.ajax(
			'index.php?chat/enable',
			{},
			function(ajaxData) {
				if (!XenForo.hasResponseError(ajaxData)) {
					if (ajaxData.enabled != '') {
						if (confirm(window.chatPhrases.chat_enabled)) {
							location.reload();
						}
					}
				} else {
					var soundError = new Audio('data/Siropu/chat/sounds/error.mp3');
					soundError.play();
				}
			},
			{global: false, error: false}
		);
	});
} (jQuery, this, document);