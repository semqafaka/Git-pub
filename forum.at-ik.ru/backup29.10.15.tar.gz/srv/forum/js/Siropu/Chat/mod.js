!function($, window, document, _undefined) {
	var chatAjaxURL = 'index.php?chat/';
	var chatSoundError = new Audio('styles/Siropu/Chat/sounds/error.mp3');

	function chatCloseOverlay($this) {
		$this.find('.OverlayCloser').trigger('click');
	}

	$(document).on('submit', '#siropuChatMessageEdit', function(e) {
		e.preventDefault();
		var $this = $(this);

		if (!$this.find('textarea').val().trim()) {
			$this.focus();
			return false;
		}

		XenForo.ajax(
			chatAjaxURL + 'edit',
			$this.serialize(),
			function(ajaxData) {
				if (!XenForo.hasResponseError(ajaxData)) {
					if (ajaxData.messageEdited != '') {
						$('#siropuChatMessages').find('li[id="' + ajaxData.messageId + '"] .siropuChatMessage').html(ajaxData.messageEdited);
						chatCloseOverlay($this);
					}
				} else {
					chatSoundError.play();
				}
			},
			{global: false, error: false}
		);
	});

	$(document).on('submit', '#siropuChatMessageDelete', function(e) {
		e.preventDefault();
		var $this = $(this);

		XenForo.ajax(
			chatAjaxURL + 'delete',
			$this.serialize(),
			function(ajaxData) {
				if (!XenForo.hasResponseError(ajaxData)) {
					if (ajaxData.messageId != '') {
						$('#siropuChatMessages').find('li[id="' + ajaxData.messageId + '"]').fadeOut();
						chatCloseOverlay($this);
					}
				} else {
					chatSoundError.play();
				}
			},
			{global: false, error: false}
		);
	});

	$(document).on('submit', '#siropuChatMessageReport', function(e) {
		e.preventDefault();
		var $this = $(this);

		XenForo.ajax(
			chatAjaxURL + 'report',
			$this.serialize(),
			function(ajaxData) {
				if (!XenForo.hasResponseError(ajaxData)) {
					if (ajaxData.messageId) {
						$('#siropuChatMessages').find('li[id="' + ajaxData.messageId + '"]').css('opacity', '0.5');
						chatCloseOverlay($this);
					}
				}
			},
			{global: false, error: false}
		);
	});

	$(document).on('submit', '#siropuChatMessagesDeleteAll', function(e) {
		e.preventDefault();
		var $this = $(this);

		XenForo.ajax(
			chatAjaxURL + 'delete-all',
			$this.serialize(),
			function(ajaxData) {
				if (!XenForo.hasResponseError(ajaxData)) {
					if (ajaxData.deleteSuccess != '') {
						$('#siropuChatMessages').attr('data-last-id', 0).find('> li').remove();
						chatCloseOverlay($this);
					}
				} else {
					chatSoundError.play();
				}
			},
			{global: false, error: false}
		);
	});

	$(document).on('submit', '#siropuChatBan', function(e) {
		e.preventDefault();
		var $this = $(this);

		XenForo.ajax(
			chatAjaxURL + 'moderator',
			$this.serialize(),
			function(ajaxData) {
				if (!XenForo.hasResponseError(ajaxData)) {
					if (ajaxData.actionSuccess != '') {
						$('#siropuChatUsers').find('li[id="' + ajaxData.actionSuccess + '"]').remove();
						if (ajaxData.banId) {
							$('#siropuChatUsers').find('tr[id="' + ajaxData.banId + '"]').remove();
						}
						if ($('#siropuChatUsers tr').length == 1) {
							location.reload();
						}
						if ($('#siropuChatToggle').length) {
							$('#siropuChatToggle').find('span').text($('#siropuChatUsers').find('li[class]').length);
						}
						chatCloseOverlay($this);
					}
				} else {
					chatSoundError.play();
				}
			},
			{global: false, error: false}
		);
	});
} (jQuery, this, document);