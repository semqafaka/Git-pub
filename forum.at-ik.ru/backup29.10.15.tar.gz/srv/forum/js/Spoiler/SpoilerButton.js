/** @param {jQuery} $ jQuery Object */
!function($, window, document, _undefined)
{
	XenForo.customEditorSpoiler = function($textarea) { this.__construct($textarea); };

	XenForo.customEditorSpoiler.prototype =
	{
		__construct: function($textarea)
		{
			var redactorOptions = $textarea.data('options'),
			customButtons = this.createSpoilerButton(),
			spoilerEditorOptions = {
				buttons: customButtons
			};

			if(typeof RedactorPlugins == 'undefined')
				RedactorPlugins = {};

			$textarea.data('options', $.extend(redactorOptions, spoilerEditorOptions));	/*Merge your custom Editor Options with the current ones*/
		},
		createSpoilerButton: function()
		{
			return {
				spoiler: {
					title: 'Spoiler',
					tag: 'SPOILER'
				},
			}
		}
	}

	XenForo.register('textarea.BbCodeWysiwygEditor', 'XenForo.customEditorSpoiler');	/*target all textareas with Redactor loaded*/
}
(jQuery, this, document);