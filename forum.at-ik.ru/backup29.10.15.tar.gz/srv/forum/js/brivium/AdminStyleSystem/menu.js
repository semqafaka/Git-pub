!function($, window, document, _undefined)
{
	XenForo.BriviumNavigationMenu = function($element) { this.__construct($element); };
	XenForo.BriviumNavigationMenu.prototype =
	{
		__construct: function($element)
		{
			$this  = this;
			$this.$timer = null;
			$element.find('> li').hover($.context($this, 'hover'));
		},
		
		hover:function(e)
		{
			e.preventDefault();
			var $firstLi = $(e.currentTarget);
			if(e.type == 'mouseenter')
			{
				$this.$timer = setTimeout(function() {
					$firstLi.find('> div').stop().slideDown(200);
				}, 300)
			}else
			{
				clearTimeout($this.$timer);
				$firstLi.find('> div').stop().slideUp(200);
			}
		}
	};
	XenForo.register('div#tabsNav ul.acpTabs', 'XenForo.BriviumNavigationMenu');
}
(jQuery, this, document);