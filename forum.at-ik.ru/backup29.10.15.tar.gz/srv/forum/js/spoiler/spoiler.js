/** @param {jQuery} $ jQuery Object */
!function($, window, document, _undefined)
{
	XenForo.Spoiler = function($spoiler)
	{
		var $content = $spoiler.find('.spoilerContent:first').hide();

		$spoiler.find('.spoilerToggle:first').click(function(e)
		{
			e.preventDefault();
			$content.toggle('slow');
		});
	}

	// *********************************************************************

	XenForo.register('.bbCodeSpoiler', 'XenForo.Spoiler');
}
(jQuery, this, document);