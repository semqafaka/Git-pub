<?php

class AnonymousPosting_FileSums
{
	public static function getHashes()
	{
		return array (
  'library/AnonymousPosting/ControllerAdmin.php' => '6dfb94257f81ef68baf3f6cb1f895f9e',
  'library/AnonymousPosting/Engine.php' => '57ac92da6a4da5bfa2afda589265ffa7',
  'library/AnonymousPosting/Installer.php' => '4940c6caea19dd658bdc8e22913c5909',
  'library/AnonymousPosting/Listener.php' => 'e424913908c52f8887193f7187aa184e',
  'library/AnonymousPosting/Option.php' => '15b427f021040cc4065c3d08139d1453',
  'library/AnonymousPosting/Route/PrefixAdmin.php' => 'f5d0fd4f50b56478a462da1a1b5fb3e4',
  'library/AnonymousPosting/XenForo/ControllerPublic/Forum.php' => 'ce64b1905dbbe4cddd93c26b1b1fbd54',
  'library/AnonymousPosting/XenForo/ControllerPublic/Thread.php' => 'd187afcd5f8951e55ff91cbe54a1df7a',
  'library/AnonymousPosting/XenForo/DataWriter/Discussion/Thread.php' => '116f4f9694ab3c3b9025d06ed5b54d14',
  'library/AnonymousPosting/XenForo/DataWriter/DiscussionMessage/Post.php' => '743efa087bee74836b214f9ba09eaf23',
  'library/AnonymousPosting/XenForo/Model/Forum.php' => '9832c431b2a9de157edb361401fcee57',
  'library/AnonymousPosting/XenForo/Model/Post.php' => '05a735a5d289b4e960946b5fa0f95fbb',
  'library/AnonymousPosting/XenForo/Model/Session.php' => 'f438f3bf485d4d6013eaefb9b0816c88',
);
	}
}