<?php

/**
 * Base class for defining the formatting used by the BB code parser.
 * This class implements HTML formatting.
 *
 * @package DoublePost
 */
class DoublePost_BbCode_Formatter_Base extends XFCP_DoublePost_BbCode_Formatter_Base
{
	protected $_bbCodeParser = null;
	protected $_doublePostTagText = null;
	protected $_doublePostOriginalDateText = null;
	
	/**
	 * Get the list of parsable tags and their parsing rules.
	 *
	 * @return array
	 */
	public function getTags()
	{
		$tags = parent::getTags();
		
		if (!isset($tags['doublepost']))
			$tags['doublepost'] = array('hasOption' => true, 'callback' => array($this, 'renderDoublePost'));
		
		return $tags;
	}
	
	/**
	 * Renders the Double Post divider.
	 *
	 * @param array $tag Tag data from tree
	 * @param array $rendererStates Renderer states to push down. Except in specific cases, cannot be pushed up.
	 *
	 * @return string Rendered version
	 */
	public function renderDoublePost(array $tag, array $rendererStates)
	{
		$timeStamp = 0;
		$originalDate = 0;
		
		if (!empty($tag['option']))
		{
			$parts = explode(',', $tag['option']);
			if (isset($parts[0]))
				$timeStamp = intval(trim($parts[0]));
			if (isset($parts[1]))
				$originalDate = intval(trim($parts[1]));
		}
		
		// bb code
		if (!isset($this->_bbCodeParser))
			$this->_bbCodeParser = new XenForo_BbCode_Parser(XenForo_BbCode_Formatter_Base::create('Base'));
		
		if (!isset($this->_doublePostTagText))
		{
			$tagText = XenForo_Application::get('options')->doublepost_tag_text;
			$tagText = trim(htmlspecialchars_decode(strip_tags($tagText)));
			$tagText = $this->_bbCodeParser->render($tagText, array('lightBox' => false));
			$this->_doublePostTagText = $tagText;
		}
		
		$tagText = $this->_doublePostTagText;
		
		if ($timeStamp)
		{
			$timeStamp = XenForo_Template_Helper_Core::callHelper('datetimehtml', array($timeStamp));
			$tagText = str_replace('{timeStamp}', '<span class="doublePostTimeStamp">' . $timeStamp . '</span>', $tagText);
		}
		else
			$tagText = str_replace('{timeStamp}', '', $tagText);
		
		if ($originalDate)
		{
			if (!isset($this->_doublePostOriginalDateText))
			{
				$originalDateText = XenForo_Application::get('options')->doublepost_tag_text_original_date;
				$originalDateText = trim(htmlspecialchars_decode(strip_tags($originalDateText)));
				$originalDateText = $this->_bbCodeParser->render($originalDateText, array('lightBox' => false));
				$this->_doublePostOriginalDateText = $originalDateText;
			}
			
			$originalDateText = $this->_doublePostOriginalDateText;
			$originalDate = XenForo_Template_Helper_Core::callHelper('datetimehtml', array($originalDate));
			$originalDateText = str_replace('{originalDate}', '<span class="doublePostOriginalDate">' . $originalDate . '</span>', $originalDateText);
			$tagText = str_replace('{originalDateText}', '<span class="doublePostOriginalDateText">' . $originalDateText . '</span>', $tagText);
		}
		else
			$tagText = str_replace('{originalDateText}', '', $tagText);
				
		// censor text
		$tagText = XenForo_Helper_String::censorString($tagText);
		
		if ($this->_view)
		{
			$params = array(
				'tagText' => $tagText
			);
			
			$template = $this->_view->createTemplateObject('doublepost_bb_code_tag', $params);
			return $template->render();
		}
		else
		{
			$html = '<div><blockquote style="text-align: center;font-size: 11px;">';
			$html .= $tagText;
			$html .= '</blockquote><div>';
			return $html;
		}
	}
}