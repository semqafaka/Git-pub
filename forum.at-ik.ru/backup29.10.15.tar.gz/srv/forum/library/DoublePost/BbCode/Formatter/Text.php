<?php

/**
 * BB code formatter that follows the formatting of the text as plain text.
 *
 * @package DoublePost
 */
class DoublePost_BbCode_Formatter_Text extends XFCP_DoublePost_BbCode_Formatter_Text
{
	/**
	 * Gets the list of valid BB code tags. This removes most behaviors.
	 *
	 * @see XenForo_BbCode_Formatter_Base::getTags()
	 */
	public function getTags()
	{
		$tags = parent::getTags();
		
		$tags['doublepost'] = array('hasOption' => true, 'callback' => array($this, 'renderDoublePost'));
		
		return $tags;
	}
	
	public function renderDoublePost(array $tag, array $rendererStates)
	{
		return "\n\n";
	}
}