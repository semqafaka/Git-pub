<?php

/**
 * Controller for handling actions on threads.
 *
 * @package DoublePost
 */
class DoublePost_ControllerPublic_Thread extends XFCP_DoublePost_ControllerPublic_Thread
{
	/**
	 * Inserts a new reply into an existing thread.
	 *
	 * @return XenForo_ControllerResponse_Abstract
	 */
	public function actionAddReply()
	{
		$this->_assertPostOnly();
		
		if ($this->_input->inRequest('more_options'))
		{
			return $this->responseReroute('XenForo_ControllerPublic_Thread', 'reply');
		}
		
		$threadId = $this->_input->filterSingle('thread_id', XenForo_Input::UINT);
		$visitor = XenForo_Visitor::getInstance();
		
		$ftpHelper = $this->getHelper('ForumThreadPost');
		$threadFetchOptions = array('readUserId' => $visitor['user_id']);
		$forumFetchOptions = array('readUserId' => $visitor['user_id']);
		list($thread, $forum) = $ftpHelper->assertThreadValidAndViewable($threadId, $threadFetchOptions, $forumFetchOptions);
		
		$postModel = $this->_getPostModel();
		$options = XenForo_Application::get('options');
		$timeNow = XenForo_Application::$time;
		$isXF12 = XenForo_Application::$versionId > 1020030 ? true : false;
			
		// NOT SAME USER OR POST IS MODERATED
		if ($thread['last_post_user_id'] != $visitor['user_id'])
		{
			return parent::actionAddReply(); // different users
		}
		
		// SECOND POST AUTHOR EXEMPT
		if ($thread['last_post_id'] == $thread['first_post_id'] && $thread['user_id'] == $visitor['user_id'])
		{
			$secondPostMerge = $options->get('doublepost_second_post_merge', false);
			if ($secondPostMerge['doublepost_second_post_merge'] != 'never')
			{
				if ($secondPostMerge['doublepost_second_post_merge'] == 'timed')
				{
					if ($timeNow < $thread['last_post_date'] + ($secondPostMerge['minutes'] * 60))
						return parent::actionAddReply(); // second post author exempt time limit has not yet passed
				}			
			}
			else
				return parent::actionAddReply();
		}
		
		// MODERATED FORUM
		if ($postModel->getPostInsertMessageState($thread, $forum) == 'moderated')
		{
			return parent::actionAddReply(); // moderated
		}
		
		// USERGROUP TIME CUT-OFF
		$nodePermissions = $visitor->getNodePermissions($thread['node_id']);
		$timeLimitMerge = XenForo_Permission::hasContentPermission($nodePermissions, 'doublepost_merge_minutes');
		if ($timeLimitMerge > -1)
		{
			if ($timeLimitMerge < 1 || ($timeNow > $thread['last_post_date'] + ($timeLimitMerge * 60)))
				return parent::actionAddReply(); // time limit reached
		}
		
		// now the the basic checks are complete, check for the obvious
		$this->_assertCanReplyToThread($thread, $forum);
		
		// MAX ATTACHMENTS
		$attachmentHash = $this->_input->filterSingle('attachment_hash', XenForo_Input::STRING);
		if (!empty($attachmentHash))
		{
			$attachmentHandler = $this->getModelFromCache('XenForo_Model_Attachment')->getAttachmentHandler('post');
			$maxAttachments = $attachmentHandler->getAttachmentCountLimit();
			$lastPostAttachmentCount = $postModel->getAttachmentCountByPostId($thread['last_post_id']);
			$newPostAttachmentCount = $postModel->getAttachmentCountByHash($attachmentHash);
			if (($newPostAttachmentCount + $lastPostAttachmentCount) > $maxAttachments)
			{
				return parent::actionAddReply(); // attachments will bring post above allowed limit
			}
		}
			
		$input = $this->_input->filter(array(
			'watch_thread_state' => XenForo_Input::UINT,
			'watch_thread' => XenForo_Input::UINT,
			'watch_thread_email' => XenForo_Input::UINT,
			'_set' => array(XenForo_Input::UINT, 'array' => true),
			'discussion_open' => XenForo_Input::UINT,
			'sticky' => XenForo_Input::UINT
		));
		$message = $this->getHelper('Editor')->getMessageText('message', $this->_input);
		$message = XenForo_Helper_String::autoLinkBbCode($message);
		
		if (!$message)
			throw $this->getErrorOrNoPermissionResponseException('please_enter_valid_message');
		
		// MESSAGE LENGTH
		$maxLength = $options->messageMaxLength;
		$newMessageLength = utf8_strlen($message);
		if ($maxLength && $newMessageLength > $maxLength)
		{
			// new message too long
			$this->responseError(new XenForo_Phrase('please_enter_message_with_no_more_than_x_characters', array('count' => $maxLength)), 'message');
		}
		
		$maxLengthForMerge = $options->doublepost_max_length_for_merge;
		if ($maxLengthForMerge && $newMessageLength > $maxLengthForMerge)
			return parent::actionAddReply(); // new message length exceeds custom length requirements
		
		// START DOUBLE POST
		if (!XenForo_Captcha_Abstract::validateDefault($this->_input))
		{
			return $this->responseCaptchaFailed();
		}
		
		$previousPostDate = $thread['last_post_date'];
		$writer = XenForo_DataWriter::create('XenForo_DataWriter_DiscussionMessage_Post');
		$writer->setExistingData($thread['last_post_id']);
		
		$timeLimitBump = XenForo_Permission::hasContentPermission($nodePermissions, 'doublepost_bump_minutes');
		$doBumpThread = false;
		if ($timeLimitBump < 0 || ($timeLimitBump > 0 && ($timeNow > $previousPostDate + ($timeLimitBump * 60))))
		{
			$doBumpThread = true;
		}
		
		$previousMessage = $writer->get('message');
		
		// DIVIDER TAG
		if ($doBumpThread && !preg_match('/\bDOUBLEPOST=\b\d+,+\d/i', $previousMessage)) // only include original post date once
			$mergedMessage = $previousMessage . '[DOUBLEPOST=' . $timeNow . ',' . $previousPostDate . '][/DOUBLEPOST]' . $message;
		else
			$mergedMessage = $previousMessage . '[DOUBLEPOST=' . $timeNow . '][/DOUBLEPOST]' . $message;
		
		// MERGED LENGTH
		if ($maxLength && utf8_strlen($mergedMessage) > $maxLength)
			return parent::actionAddReply(); // merged post would be too long
		
		// MAX IMAGES OR MEDIA
		$maxImages = $options->messageMaxImages;
		$maxMedia = $options->messageMaxMedia;
		if ($maxImages || $maxMedia)
		{
			$formatter = XenForo_BbCode_Formatter_Base::create('ImageCount', false);
			$parser = new XenForo_BbCode_Parser($formatter);
			$parser->render($mergedMessage);
			
			if ($maxImages && $formatter->getImageCount() > $maxImages)
			{
				return parent::actionAddReply(); // max images above allowed limit
			}
			else if ($maxMedia && $formatter->getMediaCount() > $maxMedia)
			{
				return parent::actionAddReply(); // max media above allowed limit
			}
		}
		
		$writer->set('message', $mergedMessage);
		
		if ($doBumpThread)
		{
			$writer->set('post_date', $timeNow); // set new date
		}
		
		$writer->setExtraData(XenForo_DataWriter_DiscussionMessage::DATA_ATTACHMENT_HASH, $attachmentHash);
		$writer->setExtraData(XenForo_DataWriter_DiscussionMessage_Post::DATA_FORUM, $forum);
		
		// only for XenForo 1.2.x
		if ($isXF12)
		{
			$writer->setOption(XenForo_DataWriter_DiscussionMessage_Post::OPTION_MAX_TAGGED_USERS, $visitor->hasPermission('general', 'maxTaggedUsers'));
			
			// SPAM
			$spamModel = $this->_getSpamPreventionModel();

			if (!$writer->hasErrors()
				&& $writer->get('message_state') == 'visible'
				&& $spamModel->visitorRequiresSpamCheck()
			)
			{
				$spamExtraParams = array(
					'permalink' => XenForo_Link::buildPublicLink('canonical:threads', $thread)
				);
				switch ($spamModel->checkMessageSpam($message, $spamExtraParams, $this->_request))
				{
					case XenForo_Model_SpamPrevention::RESULT_MODERATED:
					{
						return parent::actionAddReply(); // moderated so never merge
					}
					case XenForo_Model_SpamPrevention::RESULT_DENIED;
					{
						$writer->error(new XenForo_Phrase('your_content_cannot_be_submitted_try_later'));
						break;
					}
				}
			}
		}

		$writer->preSave();

		if (!$writer->hasErrors())
		{
			$this->assertNotFlooding('post');
		}
		
		$writer->save();
		
		// only for XenForo 1.2.x
		if ($isXF12)
			$maxTagged = $writer->getOption('maxTaggedUsers');
		
		$post = $writer->getMergedData();
		
		// only for XenForo 1.2.x
		if ($isXF12)
		{
			$spamModel->logContentSpamCheck('post', $post['post_id']);
			$this->_getDraftModel()->deleteDraft('thread-' . $thread['thread_id']);
		}
		
		$threadWriter = XenForo_DataWriter::create('XenForo_DataWriter_Discussion_Thread');
		$threadWriter->setExistingData($thread['thread_id']);
		
		if ($doBumpThread)
		{
			$threadWriter->set('last_post_date', $post['post_date']); // set new date
		}
			
		$threadWriter->setExtraData(XenForo_DataWriter_Discussion_Thread::DATA_FORUM, $forum);
		
		$threadUpdateData = array();
		
		if (!empty($input['_set']['discussion_open']) && $this->_getThreadModel()->canLockUnlockThread($thread, $forum))
		{
			if ($thread['discussion_open'] != $input['discussion_open'])
			{
				$threadUpdateData['discussion_open'] = $input['discussion_open'];
			}
		}
		
		// discussion sticky state - moderator permission required
		if (!empty($input['_set']['sticky']) && $this->_getForumModel()->canStickUnstickThreadInForum($forum))
		{
			if ($thread['sticky'] != $input['sticky'])
			{
				$threadUpdateData['sticky'] = $input['sticky'];
			}
		}
		
		if ($threadUpdateData)
		{
			$threadWriter->bulkSet($threadUpdateData);
		}
		
		$threadWriter->save();
		$thread = $threadWriter->getMergedData();
		
		// for the alerts we only want the new post message and not the merged one
		$post['message'] = $message;
		
		// only for XenForo 1.2.x
		if ($isXF12)
		{
			// ALERT QUOTED
			// alert any members who are directly quoted by this post
			$alertedMembers = $postModel->alertQuotedMembers($post, $thread, $forum);
			
			// USERNAME TAGS
			$taggedUsers = $this->getModelFromCache('XenForo_Model_UserTagging')->getTaggedUsersInMessage($message, $message);
			if ($maxTagged && $taggedUsers)
			{
				if ($maxTagged > 0)
				{
					$alertTagged = array_slice($taggedUsers, 0, $maxTagged, true);
				}
				else
				{
					$alertTagged = $taggedUsers;
				}

				$alertedMembers = array_merge(
					$alertedMembers,
					$postModel->alertTaggedMembers($post, $thread, $forum, $alertTagged, $alertedMembers)
				);
			}
		}
		else // XF 1.1.5
		{
			// ALERT QUOTED
			// alert any members who are directly quoted by this post
			$alertedMembers = $postModel->alertQuotedMembers($post);
		}
		
		$watchModel = $this->_getThreadWatchModel();
		if ($doBumpThread)
		{
			// ALERT WATCH THREAD
			// notify members watching this thread, unless they are already notified of being quoted
			$notified = $watchModel->sendNotificationToWatchUsersOnDoublePost($post, $previousPostDate, $thread, $alertedMembers);
			
			// only for XenForo 1.2.x
			if ($isXF12)
			{
				// ALERT FORUM WATCH MESSAGES
				if (!empty($notified['alerted']))
				{
					$alertedMembers = array_merge($alertedMembers, $notified['alerted']);
				}
				$emailedMembers = !empty($notified['emailed']) ? $notified['emailed'] : array();
			
				$this->getModelFromCache('XenForo_Model_ForumWatch')->sendNotificationToWatchUsersOnMessage($post, null, $alertedMembers, $emailedMembers);
			}
		}
		
		$watchModel->setVisitorThreadWatchStateFromInput($threadId, $input);
		
		
		// this is a standard redirect
		if (!$this->_noRedirect() || !$this->_input->inRequest('last_date'))
		{
			$this->_getThreadModel()->markThreadRead($thread, $forum, $timeNow);
						
			return $this->responseRedirect(
				XenForo_ControllerResponse_Redirect::SUCCESS,
				XenForo_Link::buildPublicLink('posts', $post),
				new XenForo_Phrase('your_message_has_been_posted')
			);
		}
		else
		{
			return $this->responseRedirect(
				XenForo_ControllerResponse_Redirect::SUCCESS,
				XenForo_Link::buildPublicLink('posts', $post),
				new XenForo_Phrase('your_message_has_been_posted')
			);
		}
	}
}