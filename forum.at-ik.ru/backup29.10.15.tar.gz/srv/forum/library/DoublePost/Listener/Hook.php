<?php

class DoublePost_Listener_Hook
{
	// preload the templates
	public static function templateCreate($templateName, array &$params, XenForo_Template_Abstract $template)
	{
		if ($templateName == 'thread_view')
		{
			$template->preloadTemplate('doublepost_bb_code_tag');
		}
	}
}