<?php

class DoublePost_Listener_LoadClassController
{
    /**
     * Instruct the system that XenForo_ControllerPublic_Member
     * should be extended by Dev_ControllerPublic_Member
     *
     * @param string $class
     * @param array $extend
     */
    public static function loadClassController($class, array &$extend)
    {
        if ($class == 'XenForo_ControllerPublic_Thread')
        {
            $extend[] = 'DoublePost_ControllerPublic_Thread';
        }
    }
}