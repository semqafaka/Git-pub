<?php

class DoublePost_Listener_LoadClassModel
{
    /**
     * Instruct the system that XenForo_Model_X
     * should be extended by Bookmarks_Model_X
     *
     * @param string $class
     * @param array $extend
     */
    public static function loadClassModel($class, array &$extend)
    {
        if ($class == 'XenForo_Model_Post')
        {
            $extend[] = 'DoublePost_Model_Post';
        }
        else if ($class == 'XenForo_Model_ThreadWatch')
        {
            $extend[] = 'DoublePost_Model_ThreadWatch';
        }
    }
}