<?php

class DoublePost_Listener_LoadClassbbCode
{
    /**
     * Instruct the system that XenForo_Model_X
     * should be extended by Bookmarks_Model_X
     *
     * @param string $class
     * @param array $extend
     */
    public static function loadClassBbCode($class, array &$extend)
    {
        if ($class == 'XenForo_BbCode_Formatter_Base')
        {
            $extend[] = 'DoublePost_BbCode_Formatter_Base';
        }
        else if ($class == 'XenForo_BbCode_Formatter_Text')
        {
            $extend[] = 'DoublePost_BbCode_Formatter_Text';
        }
    }
}