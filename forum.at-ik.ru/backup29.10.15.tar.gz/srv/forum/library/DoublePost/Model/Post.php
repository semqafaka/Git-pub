<?php

/**
 * Model for posts.
 *
 * @package DoublePost
 */
class DoublePost_Model_Post extends XFCP_DoublePost_Model_Post
{
	/**
	 * Fetch count of attachments for a specific post.
	 *
	 * @param integer $postId 
	 * 
	 * @return integer attach_count
	 */
	public function getAttachmentCountByPostId($postId)
	{
		return $this->_getDb()->fetchOne('
			SELECT attach_count
			FROM xf_post
			WHERE post_id = ?
			LIMIT 1', $postId);
	}
	
	/**
	 * Fetch count of attachments for a specific hash.
	 *
	 * @param string $attachmentHash 
	 * 
	 * @return integer count
	 */
	public function getAttachmentCountByHash($attachmentHash)
	{
		if (empty($attachmentHash))
			return 0;
		
		return $this->_getDb()->fetchOne('
			SELECT COUNT(*)
			FROM xf_attachment
			WHERE temp_hash = ?
			LIMIT 1', $attachmentHash);
	}
}