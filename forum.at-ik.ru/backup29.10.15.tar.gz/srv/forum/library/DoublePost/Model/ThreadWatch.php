<?php

/**
 * Model for thread watch records.
 *
 * @package DoublePost
 */
class DoublePost_Model_ThreadWatch extends XFCP_DoublePost_Model_ThreadWatch 
{
	/**
	 * Send a notification to the users watching the thread.
	 *
	 * @param array $reply The reply that has been added
	 * @param integer $previousPostDate The old post date
	 * @param array|null $thread Info about the thread the reply is in; fetched if null
	 * @param array List of user ids to NOT alert (but still send email)
	 *
     * @return array Empty or keys: alerted: user ids alerted, emailed: user ids emailed
	 */
	public function sendNotificationToWatchUsersOnDoublePost(array $reply, $previousPostDate, array $thread = null, array $noAlerts = array())
	{
		$previousPostDate = intval($previousPostDate);
		
		if (!$previousPostDate || empty($reply) || $reply['message_state'] != 'visible')
			return;
								
		$threadModel = $this->_getThreadModel();
		$userModel = $this->getModelFromCache('XenForo_Model_User');
		
		if (!$thread)
		{
			$thread = $threadModel->getThreadById($reply['thread_id'], array(
				'join' => XenForo_Model_Thread::FETCH_FORUM
			));
		}
		
		if (!$thread || $thread['discussion_state'] != 'visible')
		{
			return;
		}
		
		$autoReadDate = XenForo_Application::$time - (XenForo_Application::get('options')->readMarkingDataLifetime * 86400);
		
		if (XenForo_Application::get('options')->emailWatchedThreadIncludeMessage)
		{
			$parseBbCode = true;
			$emailTemplate = 'watched_thread_reply_messagetext';
		}
		else
		{
			$parseBbCode = false;
			$emailTemplate = 'watched_thread_reply';
		}
		
		// fetch a full user record if we don't have one already
		if (!isset($reply['avatar_width']) || !isset($reply['custom_title']))
		{
			$replyUser = $this->getModelFromCache('XenForo_Model_User')->getUserById($reply['user_id']);
			if ($replyUser)
			{
				$reply = array_merge($replyUser, $reply);
			}
			else
			{
				$reply['avatar_width'] = 0;
				$reply['custom_title'] = '';
			}
		}
		
		$alerted = array();
		$emailed = array();
		
		$users = $this->getUsersWatchingThread($thread['thread_id'], $thread['node_id']);
		foreach ($users AS $user)
		{
			if ($user['user_id'] == $reply['user_id'])
			{
				continue;
			}
			
			if ($userModel->isUserIgnored($user, $reply['user_id']))
			{
				continue;
			}
			
			if ($previousPostDate < $autoReadDate)
			{
				// always alert
			}
			else if ($previousPostDate > $user['thread_read_date'])
			{
				// user hasn't read the thread since the last alert, don't send another one
				continue;
			}
			
			$permissions = XenForo_Permission::unserializePermissions($user['node_permission_cache']);
			
			if (!$threadModel->canViewThreadAndContainer($thread, $thread, $null, $permissions, $user))
			{
				continue;
			}
			
			if ($user['email_subscribe'] && $user['email'] && $user['user_state'] == 'valid')
			{
				if (!isset($reply['messageText']) && $parseBbCode)
				{
					$bbCodeParserText = new XenForo_BbCode_Parser(XenForo_BbCode_Formatter_Base::create('Text'));
					$reply['messageText'] = new XenForo_BbCode_TextWrapper($reply['message'], $bbCodeParserText);
					
					$bbCodeParserHtml = new XenForo_BbCode_Parser(XenForo_BbCode_Formatter_Base::create('HtmlEmail'));
					$reply['messageHtml'] = new XenForo_BbCode_TextWrapper($reply['message'], $bbCodeParserHtml);
				}
				
				if (!isset($thread['titleCensored']))
				{
					$thread['titleCensored'] = XenForo_Helper_String::censorString($thread['title']);
				}
				
				$mail = XenForo_Mail::create($emailTemplate, array(
					'reply' => $reply,
					'thread' => $thread,
					'forum' => $thread,
					'receiver' => $user
				), $user['language_id']);
				
				$mail->enableAllLanguagePreCache();
				$mail->queue($user['email'], $user['username']);
				
				$emailed[] = $user['user_id'];
			}
			
			if (!in_array($user['user_id'], $noAlerts))
			{
				$alertType = ($reply['attach_count'] ? 'insert_attachment' : 'insert');
				
				if (XenForo_Model_Alert::userReceivesAlert($user, 'post', $alertType))
				{
					XenForo_Model_Alert::alert(
						$user['user_id'],
						$reply['user_id'],
						$reply['username'],
						'post',
						$reply['post_id'],
						$alertType
					);
					
					$alerted[] = $user['user_id'];
				}
			}
		}
		
		return array(
			'emailed' => $emailed,
			'alerted' => $alerted
		);
	}
}