<?php

class Milano_SmileyManager_ControllerAdmin_SmilieCategory extends XFCP_Milano_SmileyManager_ControllerAdmin_SmilieCategory
{
	
}