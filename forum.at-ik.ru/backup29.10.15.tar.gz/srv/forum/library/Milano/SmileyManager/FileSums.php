<?php

class Milano_SmileyManager_FileSums
{
	public static function getHashes()
	{
		return array (
  'library\\Milano\\SmileyManager\\BbCode\\Formatter\\Base.php' => '9f900eca116a9f68f3defc52a1072eea',
  'library\\Milano\\SmileyManager\\ControllerAdmin\\Smilie.php' => '4b3ac5c3de5f9be5eefcbbe40341c9f1',
  'library\\Milano\\SmileyManager\\ControllerAdmin\\SmilieCategory.php' => 'ad3e134c8a55da85746ba8801c7d3e93',
  'library\\Milano\\SmileyManager\\ControllerPublic\\Account.php' => 'fc1d7a1c4cd741137d73f63d75859fd5',
  'library\\Milano\\SmileyManager\\DataWriter\\User.php' => '8773b5fd771f134426d6b0be00d46a79',
  'library\\Milano\\SmileyManager\\Helper\\Smilie.php' => '2e6ebcdae68ba7ac784c2834eec77703',
  'library\\Milano\\SmileyManager\\Install.php' => '01c43839099d3e571cc178a94d799f14',
  'library\\Milano\\SmileyManager\\Listener.php' => 'd8bd5b0026b2e9f4898a681c91bbcc7d',
  'library\\Milano\\SmileyManager\\ViewAdmin\\Smilie\\ImportSprite.php' => 'ef98905ef1f1794bd0b45af093c9b84f',
  'js\\Milano\\SmileyManager\\editor.js' => 'c31a9ef803f724fb8b811f50b84962a9',
  'js\\Milano\\SmileyManager\\full\\editor.js' => 'e84af75cb9ea4beb3f085d8faae948aa',
  'js\\Milano\\SmileyManager\\full\\smiley.js' => '73e9dc0033a5155f6972542df2bdd3f0',
  'js\\Milano\\SmileyManager\\smiley.js' => '6a02106b0bde06e10db6b64cc3a3aaee',
);
	}
}