<?php

/*
	
*/

class Siropu_Chat_AlertHandler extends XenForo_AlertHandler_DiscussionMessage
{
	public function getContentByIds(array $contentIds, $model, $userId, array $viewingUser)
	{
		return $model->getModelFromCache('Siropu_Chat_Model')->getMessageByIds($contentIds);
	}
}