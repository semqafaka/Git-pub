<?php

/*
	
*/

abstract class Siropu_Chat_Callback
{
	public static $chatLoaded = false;

	public static function renderMultiSelect(XenForo_View $view, $fieldPrefix, array $preparedOption, $canEdit)
    {
		$forumOpt = XenForo_Option_NodeChooser::getNodeOptions(false, false, 'Forum');
		$forumLst = $preparedOption['option_value']['selected'];
		$forumLst = is_array($forumLst) ? array_flip($forumLst) : $forumLst;
		$selected = array();

		foreach ($forumOpt as $key => $val)
		{
			if (isset($forumLst[$key]))
			{
				$forumOpt[$key]['selected'] = true;
			}
		}

		$editLink = $view->createTemplateObject('option_list_option_editlink', array(
			'preparedOption'          => $preparedOption,
			'canEditOptionDefinition' => $canEdit
		));

		return $view->createTemplateObject('siropu_chat_option_template_forum_multiselect', array(
			'fieldPrefix'     => $fieldPrefix,
			'listedFieldName' => $fieldPrefix . '_listed[]',
			'preparedOption'  => $preparedOption,
			'formatParams'    => $forumOpt,
			'editLink'        => $editLink
		));
	}
	public static function getChat($content, $params, XenForo_Template_Abstract $template)
    {
		$options = XenForo_Application::get('options');

		if ($options->siropu_chat_enabled
			&& $options->siropu_chat_display_mode == 'embed'
			&& Siropu_Chat_Helper::userHasPermission('view')
			&& !self::$chatLoaded)
		{
			$visitor = XenForo_Visitor::getInstance();
			$model   = XenForo_Model::create('Siropu_Chat_Model');

			$userID   = $visitor->user_id;
			$session  = $model->getSession($userID);
			$settings = Siropu_Chat_Helper::prepareUserSettings($session);
			$settings = $settings ? $settings : $options->siropu_chat_default_user_settings;
			$userBans = array();

			if (isset($settings['disabled']) && $settings['disabled'])
			{
				return $template->create('siropu_chat_disabled', array('displayMode' => 'embed'));
			}

			if ($session && $session['user_is_banned'])
			{
				if ($userBans = $model->getUserBans($userID))
				{
					$chatBan = false;

					foreach ($userBans as $ban)
					{
						if ($ban['ban_type'] == 'chat')
						{
							$chatBan = true;
							break;
						}
					}

					if (!$options->siropu_chat_banned_view_access && $chatBan)
					{
						return false;
					}
				}
				else
				{
					$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
					$dw->setExistingData($userID);
					$dw->set('user_is_banned', 0);
					$dw->save();

					$session['user_is_banned'] = 0;
				}
			}

			$usersRoom  = $usersAll = array();
			$changeRoom = isset($params['rooms']) ? true : false;
			$roomId     = isset($params['room_id']) ? $params['room_id'] : 0;

			if ($changeRoom)
			{
				$roomId = $session ? Siropu_Chat_Helper::getRoomId($session) : $roomId;
			}

			if ($userListRefreshInterval = $options->siropu_chat_user_list_refresh_interval)
			{
				XenForo_Helper_Cookie::setCookie('lastUserListUpdate', time());

				$usersAll  = $model->getActiveUsers(Siropu_Chat_Helper::getIgnoredUsers());
				$usersRoom = Siropu_Chat_Helper::getChatRoomUsers($usersAll, $roomId);
			}

			$viewParams = array(
				'chatClass'    => Siropu_Chat_Helper::getChatClass($settings, 'embed'),
				'chatMode'     => 'embed',
				'chatSidebar'  => isset($params['sidebar']) ? true : false,
				'chatSession'  => $session,
				'chatSettings' => $settings,
				'chatRoomId'   => $roomId,
				'chatMessages' => array(),
				'chatLastRow'  => array(),
				'chatReports'  => $model->getReportsCount(array('report_state' => 'open')),
				'chatUserBans' => Siropu_Chat_Helper::prepareUserBans($userBans, $session),
				'chatRooms'    => ($options->siropu_chat_rooms_enabled && $changeRoom) ? $model->getAllRooms() : '',
				'chatUsers'    => $usersRoom,
				'chatUsersAll' => $usersAll,
				'chatColors'   => Siropu_Chat_Helper::prepareColorList(),
				'chatNotice'   => Siropu_Chat_Helper::getNotices(),
				'chatAds'      => Siropu_Chat_Helper::getAds(),
				'changeRoom'   => $changeRoom
			);

			echo $template->create('siropu_chat', array_merge($viewParams, $template->getParams()));
			self::$chatLoaded = true;
		}
	}
}