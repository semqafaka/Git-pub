<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_ControllerPublic_Chat extends XenForo_ControllerPublic_Abstract
{
	protected function _preDispatch($action)
	{
		if (!$this->_getOptions()->siropu_chat_enabled || !$this->_getHelper()->userHasPermission('view'))
		{
			throw $this->responseException($this->responseError(new XenForo_Phrase('do_not_have_permission')));
		}
	}
	public static function getSessionActivityDetailsForList(array $activities)
    {
        return new XenForo_Phrase('siropu_chat_viewing_chat_page');
    }
	public function actionIndex()
	{
		$chatPage = $this->_getOptions()->siropu_chat_page;

		if (!$chatPage['enabled'])
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_page_disabled'));
		}

		$session       = $this->_getModel()->getSession($this->_getUID());
		$userBans      = array();
		$updateSession = true;

		if ($session && $session['user_is_banned'])
		{
			if ($userBans = $this->_getModel()->getUserBans($this->_getUID()))
			{
				$chatBan = false;

				foreach ($userBans as $ban)
				{
					if ($ban['ban_type'] == 'chat')
					{
						$chatBan = true;
						break;
					}
					else if ($ban['ban_room_id'] == $session['user_room_id'])
					{
						$updateSession = false;
					}
				}

				if (!$this->_getOptions()->siropu_chat_banned_view_access && $chatBan)
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_banned_message', array('reason' => $chatBan['ban_reason'] ? $chatBan['ban_reason'] : 'N/A', 'ends' => $chatBan['ban_end'] ? XenForo_Template_Helper_Core::dateTime($chatBan['ban_end']) : new XenForo_Phrase('never'))));
				}
			}
			else
			{
				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
				$dw->setExistingData($this->_getUID());
				$dw->set('user_is_banned', 0);
				$dw->save();

				$session['user_is_banned'] = 0;
			}
		}

		if ($this->_getOptions()->siropu_chat_display_page_visitors && $this->_getUID() && $updateSession)
		{
			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
			if ($session)
			{
				$dw->setExistingData($this->_getUID());
			}
			else
			{
				$dw->set('user_id', $this->_getUID());
			}
			$dw->set('user_last_activity', time());
			$dw->save();

			if ($session)
			{
				$session['user_last_activity'] = time();
			}
			else
			{
				$session = $this->_getModel()->getSession($this->_getUID());
			}
		}

		$settings = $this->_getHelper()->prepareUserSettings($session);
		$settings = $settings ? $settings : $this->_getOptions()->siropu_chat_default_user_settings;
		$inverse  = isset($settings['inverse']) ? $settings['inverse'] : false;
		$roomId   = $this->_getHelper()->getRoomId($session);
		$ignored  = $this->_getHelper()->getIgnoredUsers();
		$messages = $this->_getModel()->getMessages(array('room_id' => $roomId), array('page' => 1, 'perPage' => $this->_getOptions()->siropu_chat_messages_limit), $inverse, ((isset($settings['show_ignored']) && $settings['show_ignored']) ? array() : $ignored));

		$usersRoom = $usersAll = array();

		if ($this->_getOptions()->siropu_chat_user_list_enabled)
		{
			$usersAll  = $this->_getModel()->getActiveUsers($ignored);
			$usersRoom = $this->_getHelper()->getChatRoomUsers($usersAll, $roomId);
		}

		$viewParams = array(
			'chatClass'    => $this->_getHelper()->getChatClass($settings, 'page'),
			'chatSession'  => $session,
			'chatSettings' => $settings,
			'chatRoomId'   => $roomId,
			'chatMessages' => $messages,
			'chatReports'  => $this->_getModel()->getReportsCount(array('report_state' => 'open')),
			'chatUserBans' => $this->_getHelper()->prepareUserBans($userBans, $session),
			'chatRooms'    => $this->_getOptions()->siropu_chat_rooms_enabled ? $this->_getModel()->getAllRooms() : '',
			'chatLastRow'  => $this->_getHelper()->prepareLastRow($messages, array('inverse' => $inverse)),
			'chatUsers'    => $usersRoom,
			'chatUsersAll' => $usersAll,
			'chatColors'   => $this->_getHelper()->prepareColorList(),
			'chatNotice'   => $this->_getHelper()->getNotices(),
			'chatAds'      => $this->_getHelper()->getAds()
		);

		return $this->responseView('Siropu_Chat_ViewPublic_Public', 'siropu_chat', $viewParams);
	}
	public function actionRoomsGet()
	{
		$this->_assertPostOnly();

		if (!$this->_getHelper()->userHasPermission('use') && !$this->_getHelper()->userHasPermission('joinRooms'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$rooms = $this->_getModel()->getAllRooms();

		if (count($rooms) > 1)
		{
			foreach ($rooms as $key => $val)
			{
				$rooms[$key]['has_permission'] = true;
				$rooms[$key]['is_room_author'] = false;

				if (!$this->_getHelper()->checkRoomPermissions($val))
				{
					$rooms[$key]['has_permission'] = false;
				}

				if ($val['room_id'] && $val['room_user_id'] == $this->_getUID())
				{
					$rooms[$key]['is_room_author'] = true;
				}
			}
		}

		return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array(
			'rooms' => new XenForo_Template_Public('siropu_chat_rooms', array(
				'chatRooms'    => $rooms,
				'chatUsersAll' => $this->_getModel()->getActiveUsers(),
				'chatSession'  => $this->_getUID() ? $this->_getModel()->getSession($this->_getUID()) : '',
				'visitor'      => $this->_getVisitor()->toArray(),
				'xenOptions'   => $this->_getOptions()->getOptions()
			))
		));
	}
	public function actionRoomsJoin()
	{
		$this->_assertPostOnly();

		if (!$this->_getHelper()->userHasPermission('joinRooms'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$roomId   = $this->_getRoomID(false);
		$password = $this->_input->filterSingle('password', XenForo_Input::STRING);

		if ($roomId)
		{
			if ($room = $this->_getModel()->getRoomById($roomId))
			{
				if ($room['room_password'] && $room['room_password'] != $password
					&& $room['room_user_id'] != $this->_getUID()
					&& !$this->_getHelper()->userHasPermission('bypassPassword'))
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_room_invalid_password'));
				}

				if (!$this->_getHelper()->checkRoomPermissions($room))
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_room_no_permission'));
				}
			}
			else
			{
				return $this->responseError(new XenForo_Phrase('siropu_chat_room_not_found'));
			}
		}

		$session       = $this->_getModel()->getSession($this->_getUID());
		$settings      = $this->_getHelper()->prepareUserSettings($session);
		$notifications = $this->_getOptions()->siropu_chat_displayed_notifications;

		if ($bannedMessage = $this->_getBannedMessage($session, $roomId))
		{
			return $this->responseError($bannedMessage);
		}

		$user = array('name' => '[USER=' . $this->_getUID() . ']' . $this->_getVisitor()->username . '[/USER]');

		if ($notifications['join'])
		{
			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
			$dw->bulkSet(array(
				'message_room_id' => $roomId,
				'message_text'    => new Xenforo_Phrase('siropu_chat_bot_room_join', $user),
				'message_type'    => 'bot'
			));
			$dw->save();
		}

		if ($session && $session['user_room_id'] != $roomId && $notifications['left'])
		{
			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
			$dw->bulkSet(array(
				'message_room_id' => $session['user_room_id'],
				'message_text'    => new Xenforo_Phrase('siropu_chat_bot_room_left', $user),
				'message_type'    => 'bot'
			));
			$dw->save();
		}

		if ($this->_getUID())
		{
			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
			if ($session)
			{
				$dw->setExistingData($this->_getUID());
			}
			else
			{
				$dw->set('user_id', $this->_getUID());
			}
			$dw->set('user_room_id', $roomId);
			$dw->set('user_last_activity', time());
			$dw->save();
		}

		$this->_getHelper()->setRoomCookie($roomId);
		return $this->_getChat($roomId);
	}
	public function actionRoomsAdd()
	{
		$addRooms  = $this->_getHelper()->userHasPermission('addRooms');
		$roomCount = $this->_getModel()->getUserRoomCount($this->_getUID());

		if ($addRooms == 0) 
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}
		else if ($addRooms == $roomCount)
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_room_add_limit_reached'));
		}

		$viewParams = array(
			'userGroups' => $this->getModelFromCache('XenForo_Model_UserGroup')->getAllUserGroups()
		);

		return $this->responseView('', 'siropu_chat_room_edit', $viewParams);
	}
	public function actionRoomsEdit()
	{
		$roomId = $this->_getRoomID(false);

		if (!$room = $this->_getModel()->getRoomById($roomId))
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_room_not_found'));
		}

		if (($room['room_user_id'] == $this->_getUID()
			&& $this->_getHelper()->userHasPermission('addRooms'))
			|| $this->_getHelper()->userHasPermission('editRooms'))
		{
			$viewParams = array(
				'room'        => $room,
				'user'        => $this->_getUserModel()->getUserById($room['room_user_id']),
				'permissions' => unserialize($room['room_permissions']),
				'userGroups'  => $this->getModelFromCache('XenForo_Model_UserGroup')->getAllUserGroups()
			);

			return $this->responseView('', 'siropu_chat_room_edit', $viewParams);
		}

		return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
	}
	public function actionRoomsSave()
	{
		$this->_assertPostOnly();

		$roomId = $this->_getRoomID(false);
		$room   = $this->_getModel()->getRoomById($roomId);

		if (!$this->_getHelper()->userHasPermission('addRooms')
			&& ($room && $room['room_user_id'] != $this->_getUID())
			&& !$this->_getHelper()->userHasPermission('editRooms'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$data = $this->_input->filter(array(
			'room_name'        => XenForo_Input::STRING,
			'room_description' => XenForo_Input::STRING,
			'room_password'    => XenForo_Input::STRING,
			'room_permissions' => XenForo_Input::ARRAY_SIMPLE,
			'room_locked'      => XenForo_Input::UINT
		));

		if (!$data['room_name'])
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_room_name_is_required'));
		}

		if ($data['room_password'] && !$this->_getHelper()->userHasPermission('passwordRooms'))
		{
			$data['room_password'] = '';
		}

		if ($data['room_permissions'] && !$this->_getVisitor()->is_admin)
		{
			$data['room_permissions'] = array();
		}

		$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Rooms');
		if ($roomId)
		{
			$dw->setExistingData($roomId);
		}
		else
		{
			$data['room_user_id'] = $this->_getUID();
		}
		$dw->bulkSet($data);
		$dw->save();

		return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array('roomAdded' => true));
	}
	public function actionRoomsDelete()
	{
		$roomId = $this->_getRoomID(false);

		if (!$room = $this->_getModel()->getRoomById($roomId))
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_room_not_found'));
		}

		if ($room['room_user_id'] != $this->_getUID() && !$this->_getHelper()->userHasPermission('deleteRooms'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		if ($this->isConfirmedPost())
		{
			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Rooms');
			$dw->setExistingData($roomId);
			$dw->delete();

			$this->_getModel()->changeUsersRoomId($roomId);
			$this->_getModel()->deleteUsersRoomBan($roomId);
			$this->_getModel()->deleteMessagesByRoomId($roomId);

			@unlink($this->_getHelper()->getMessageActionsDataFile($roomId));

			return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array('roomId' => $roomId));
		}

		$viewParams = array(
			'room' => $room,
			'user' => $this->_getUserModel()->getUserById($room['room_user_id']),
		);

		return $this->responseView('', 'siropu_chat_room_delete', $viewParams);
	}
	public function actionTop()
	{
		$topChattersOptions = $this->_getOptions()->siropu_chat_top_chatters;

		if (!$topChattersOptions['enabled'])
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$action = $this->_input->filterSingle('action', XenForo_Input::STRING);

		if ($action == 'reset' && $this->_getVisitor()->is_admin)
		{
			if ($this->isConfirmedPost())
			{
				$this->_getModel()->resetTopChatters();

				return $this->responseRedirect(
					XenForo_ControllerResponse_Redirect::SUCCESS,
					XenForo_Link::buildPublicLink('chat/top')
				);
			}

			return $this->responseView('', 'siropu_chat_top_chatters_reset');
		}

		$viewParams = array(
			'topChatters' => $this->_getModel()->getTopChatters($topChattersOptions['limit'])
		);

		return $this->responseView('', 'siropu_chat_top_chatters', $viewParams);
	}
	public function actionArchive()
	{
		if (!$this->_getHelper()->userHasPermission('viewArchive'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$data = $this->_input->filter(array(
			'message_id' => XenForo_Input::UINT,
			'room_id'    => XenForo_Input::STRING,
			'keywords'   => XenForo_Input::STRING,
			'username'   => XenForo_Input::STRING,
			'user_id'    => XenForo_Input::STRING,
			'date_start' => XenForo_Input::DATE_TIME,
			'date_end'   => XenForo_Input::DATE_TIME,
			'page'       => XenForo_Input::UINT
		));

		$data['room_id'] = ($data['room_id'] != '') ? $data['room_id'] : 'any';

		$linkParams = $rooms = array();
		$conditions = array('room_id' => 0);

		if ($data['message_id'])
		{
			$conditions['message_id'] = $data['message_id'];
		}

		if ($this->_getHelper()->userHasPermission('searchArchive'))
		{
			$userId    = $data['user_id'];
			$dateStart = $data['date_start'];
			$dateEnd   = $data['date_end'];

			if ($this->_getOptions()->siropu_chat_rooms_enabled)
			{
				$session = $this->_getModel()->getSession($this->_getUID());
				$rooms   = $this->_getModel()->getAllRooms();

				foreach ($rooms as $key => $val)
				{
					if (!$this->_getHelper()->checkRoomPermissions($val)
						|| ($key
							&& $val['room_password']
							&& $val['room_user_id'] != $this->_getUID()
							&& $val['room_id'] != $session['user_room_id']
							&& !$this->_getHelper()->userHasPermission('bypassPassword')))
					{
						unset($rooms[$key]);
					}
				}

				if ($data['room_id'] == 'any' && ($this->_getVisitor()->is_admin || $this->_getVisitor()->is_moderator))
				{
					$roomId = 'any';
				}
				else
				{
					$roomId = isset($rooms[$data['room_id']]) ? $rooms[$data['room_id']]['room_id'] : 0;
				}

				$linkParams['room_id'] = $conditions['room_id'] = $roomId;
			}

			if ($data['keywords'])
			{
				$linkParams['keywords'] = $conditions['keywords'] = $data['keywords'];
			}

			if ($username = array_filter(explode(',', $data['username'])))
			{
				if (!$userId)
				{
					$userIds = array();

					if ($users = $this->_getUserModel()->getUsersByNames($username))
					{
						foreach ($users as $user)
						{
							$userIds[] = $user['user_id'];
						}
					}

					if ($userIds)
					{
						$userId = implode(',', $userIds);
					}
				}
			}
			if ($userId)
			{
				$linkParams['user_id'] = $conditions['user_id'] = $userId;
			}
			if ($dateStart)
			{
				$linkParams['date_start'] = $conditions['date_start'] = $dateStart;

				if (!$dateEnd)
				{
					$dateEnd = time();
				}
			}
			if ($dateEnd)
			{
				$linkParams['date_end'] = $conditions['date_end'] = $dateEnd;
			}
		}

		$viewParams = array(
			'rooms'        => $rooms,
			'chatMessages' => $this->_getModel()->getMessages($conditions, array('page' => $data['page'], 'perPage' => 50), true),
			'search'       => $data,
			'linkParams'   => $linkParams,
			'total'        => $this->_getModel()->getMessagesCount($conditions),
			'page'         => $data['page'],
			'perPage'      => 50,
		);

		return $this->responseView('Siropu_Chat_ViewPublic_Public', 'siropu_chat_archive', $viewParams);
	}
	public function actionReports()
	{
		if (!$this->_getHelper()->userHasPermission('manageReports'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$data = $this->_input->filter(array(
			'report_id'         => XenForo_Input::UINT,
			'report_message_id' => XenForo_Input::UINT,
			'report_user_id'    => XenForo_Input::UINT,
			'report_state'      => XenForo_Input::STRING,
			'save'              => XenForo_Input::STRING,
			'page'              => XenForo_Input::UINT,
		));

		if ($data['report_id'] && ($report = $this->_getModel()->getReportByIdComplete($data['report_id'])))
		{
			if ($data['save'])
			{
				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Reports');
				$dw->setExistingData($data['report_id']);
				$dw->bulkSet(array(
					'report_state'           => $data['report_state'],
					'report_update_date'     => time(),
					'report_update_user_id'  => $this->_getUID(),
					'report_update_username' => $this->_getVisitor()->username,
				));
				$dw->save();

				return $this->responseRedirect(
					XenForo_ControllerResponse_Redirect::SUCCESS,
					XenForo_Link::buildPublicLink('chat/reports')
				);
			}

			$viewParams = array(
				'report'       => $report,
				'bbCodeParser' => XenForo_BbCode_Parser::create(XenForo_BbCode_Formatter_Base::create())
			);

			return $this->responseView('', 'siropu_chat_report_view', $viewParams);
		}

		if (!$data['report_state'])
		{
			$data['report_state'] = 'open';
		}

		$conditions['report_state'] = $linkParams['report_state'] = $data['report_state'];

		$viewParams = array(
			'chatReports' => $this->_getModel()->getReports($conditions, array('page' => $data['page'], 'perPage' => 25)),
			'state'       => $data['report_state'],
			'linkParams'  => $linkParams,
			'total'       => $this->_getModel()->getReportsCount($conditions),
			'page'        => $data['page'],
			'perPage'     => 25,
		);

		return $this->responseView('', 'siropu_chat_reports', $viewParams);
	}
	public function actionBan()
	{
		if (!$this->_getHelper()->userHasPermission('ban'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$input = $this->_input->filter(array(
			'username'      => XenForo_Input::STRING,
			'room_id'       => XenForo_Input::ARRAY_SIMPLE,
			'ban_type'      => XenForo_Input::UINT,
			'length_type'   => XenForo_Input::STRING,
			'length_value'  => XenForo_Input::UINT,
			'length_option' => XenForo_Input::STRING,
			'end_date'      => XenForo_Input::DATE_TIME
		));

		$data = $this->_input->filter(array(
			'ban_reason'  => XenForo_Input::STRING,
			'ban_type'    => XenForo_Input::STRING,
			'ban_end'     => XenForo_Input::UINT
		));

		if (!$data['ban_type'])
		{
			$data['ban_type'] = 'chat';
		}

		if ($this->isConfirmedPost())
		{
			$this->_assertPostOnly();
			$notifications = $this->_getOptions()->siropu_chat_displayed_notifications;

			if ($input['length_type'] == 'temporary')
			{
				if ($length = $input['length_value'])
				{
					$data['ban_end'] = strtotime("+{$length} {$input['length_option']}");
				}
				else if ($endDate = $input['end_date'])
				{
					$data['ban_end'] = $endDate;
				}

				if (!$data['ban_end'])
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_ban_length_required'));
				}
			}

			$data['ban_author'] = $this->_getUID();

			if (($usernames = array_map('trim', explode(',', $input['username'])))
				&& ($users = $this->_getUserModel()->getUsersByNames($usernames)))
			{
				$exclude = array();

				foreach ($users as $user)
				{
					if ($userSession = $this->_getModel()->getSession($user['user_id']))
					{
						if (!$user['is_admin'] && !$user['is_moderator'])
						{
							$userBans  = $this->_getModel()->getUserBans($user['user_id']);
							$updateBan = array();

							if ($userBans)
							{
								foreach ($userBans as $ban)
								{
									if (($data['ban_type'] == 'chat' && $ban['ban_type'] == 'chat')
										|| ($data['ban_type'] == 'room' && $ban['ban_type'] == 'room'
											&& in_array($ban['ban_room_id'], $input['room_id'])))
									{
										$updateBan[] = $ban;
									}
								}
							}

							if ($updateBan)
							{
								foreach ($updateBan as $ban)
								{
									$data['ban_room_id'] = $ban['ban_room_id'];

									$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Bans');
									$dw->setExistingData($ban['ban_id']);
									$dw->bulkSet($data);
									$dw->save();
								}
							}
							else
							{
								if ($data['ban_type'] == 'chat' && $input['length_type'] == 'permanent' && $userBans)
								{
									$this->_getModel()->deleteUserBans($user['user_id']);
								}

								$data['ban_user_id'] = $user['user_id'];

								if (empty($input['room_id']))
								{
									$input['room_id'][] = 0;
								}

								foreach ($input['room_id'] as $roomId)
								{
									$data['ban_room_id'] = $roomId;

									$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Bans');
									$dw->bulkSet($data);
									$dw->save();
								}

								$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
								$dw->setExistingData($user['user_id']);
								$dw->set('user_is_banned', 1);
								$dw->set('user_last_activity', 0);
								$dw->save();

								if ($notifications['ban'])
								{
									$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
									$dw->bulkSet(array(
										'message_room_id' => $userSession['user_room_id'],
										'message_text'    => new XenForo_Phrase((($data['ban_type'] == 'chat') ? 'siropu_chat_bot_user_banned' : 'siropu_chat_bot_user_room_banned'), array('user' => '[USER=' . $user['user_id'] . ']' . $user['username'] . '[/USER]', 'mod'  => '[USER=' . $this->_getUID() . ']' . $this->_getVisitor()->username . '[/USER]')),
										'message_type'    => 'bot'
									));
									$dw->save();
								}
							}
						}
						else
						{
							$exclude[] = $user['username'];
						}
					}
					else
					{
						$exclude[] = $user['username'];
					}
				}

				if ($exclude)
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_cannot_be_banned', array('users' => implode(', ', $exclude))));
				}
				else
				{
					return $this->responseRedirect(
						XenForo_ControllerResponse_Redirect::SUCCESS,
						XenForo_Link::buildPublicLink('chat/banned')
					);
				}
			}
			else
			{
				return $this->responseError(new XenForo_Phrase('requested_user_not_found'));
			}
		}

		$viewParams = array(
			'rooms' => $this->_getModel()->getAllRooms()
		);

		return $this->responseView('', 'siropu_chat_ban_alt', $viewParams);
	}
	public function actionBanned()
	{
		if (!$this->_getHelper()->userHasPermission('viewBanned'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$data = $this->_input->filter(array(
			'username' => XenForo_Input::STRING,
			'user_id'  => XenForo_Input::STRING,
			'page'     => XenForo_Input::UINT,
		));

		$conditions = $linkParams = array();
		$userId     = $data['user_id'];

		if ($username = array_filter(explode(',', $data['username'])))
		{
			if (!$userId)
			{
				$userIds = array();

				if ($users = $this->_getUserModel()->getUsersByNames($username))
				{
					foreach ($users as $user)
					{
						$userIds[] = $user['user_id'];
					}
				}

				if ($userIds)
				{
					$userId = implode(',', $userIds);
				}
			}
		}

		if ($userId)
		{
			$linkParams['user_id'] = $conditions['user_id'] = $userId;
		}

		$viewParams = array(
			'chatBanned' => $this->_getModel()->getBannedUsers($conditions, array('page' => $data['page'], 'perPage' => 50)),
			'linkParams' => $linkParams,
			'total'      => $this->_getModel()->getBannedUsersCount(),
			'page'       => $data['page'],
			'search'     => $data,
			'perPage'    => 50,
		);

		return $this->responseView('', 'siropu_chat_banned', $viewParams);
	}
	public function actionSettings()
	{
		$this->_assertPostOnly();

		if (!$this->_getUID())
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_settings_guest_info'));
		}

		$data = $this->_input->filter(array(
			'sound'         => XenForo_Input::UINT,
			'maximized'     => XenForo_Input::UINT,
			'inverse'       => XenForo_Input::UINT,
			'editor_on_top' => XenForo_Input::UINT,
			'hide_chatters' => XenForo_Input::UINT,
			'show_ignored'  => XenForo_Input::UINT,
			'display_mode'  => XenForo_Input::STRING,
			'color'         => XenForo_Input::STRING,
			'disabled'      => XenForo_Input::UINT
		));

		if (($displayMode = $data['display_mode']) && !$this->_getHelper()->userHasPermission('chooseDisplayMode'))
		{
			$data['display_mode'] = '';
		}

		$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
		if ($session = $this->_getModel()->getSession($this->_getUID()))
		{
			$dw->setExistingData($this->_getUID());
		}
		else
		{
			$dw->set('user_id', $this->_getUID());
			$dw->set('user_last_activity', 0);
		}
		$dw->set('user_settings', $this->_getHelper()->setSessionSettings($session, $data));
		$dw->save();

		return $this->responseView('Siropu_Chat_ViewPublic_Ajax');
	}
	public function actionSubmit()
	{
		$this->_assertPostOnly();

		if (!$this->_getHelper()->userHasPermission('use'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$message  = $this->_input->filterSingle('message', XenForo_Input::STRING);
		$options  = XenForo_Application::get('options');

		if ($maxLength = $options->siropu_chat_message_max_length)
		{
			$message = XenForo_Helper_String::wholeWordTrim($message, $maxLength);
		}

		$message = XenForo_Helper_String::censorString($message);

		if ($options->siropu_chat_disable_all_bbcodes)
		{
			$message = XenForo_Helper_String::bbCodeStrip($message);
		}

		if (strlen(XenForo_Helper_String::bbCodeStrip($message)) > 0)
		{
			$visitor  = XenForo_Visitor::getInstance();
			$userId   = $visitor->user_id;
			$username = $visitor->username;
			$session  = $this->_getModel()->getSession($userId);
			$settings = $this->_getHelper()->prepareUserSettings($session);
			$roomId   = $this->_getRoomID();

			if ($bannedMessage = $this->_getBannedMessage($session, $this->_getRoomID()))
			{
				return $this->responseError($bannedMessage);
			}

			$data = array(
				'message_room_id' => $roomId,
				'message_user_id' => $userId,
				'message_text'    => $message,
				'message_type'    => 'chat'
			);

			if (preg_match('/^\/me\s[^ ]/i', XenForo_Helper_String::bbCodeStrip($message))
				&& $options->siropu_chat_me_command_enabled
				&& $this->_getHelper()->userHasPermission('meCommand'))
			{
				$message = '[USER=' . $userId . ']' . $username . '[/USER] ' . trim(str_ireplace('/me', '', $message));

				$data['message_text'] = $message;
				$data['message_type'] = 'me';
			}

			if (preg_match('/^\/whisper\s\[(.+?)\](.+?)$/i', $message, $matches)
				&& $options->siropu_chat_whisper_command_enabled
				&& $this->_getHelper()->userHasPermission('whisperCommand'))
			{
				if (preg_match('/' . preg_quote($username) . '/', $matches[1]))
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_whisper_self_error'));
				}

				if ($users = $this->_getUserModel()->getUsersByNames(array_filter(explode(',', $matches[1]))))
				{
					$recipients = array($userId => $username);

					foreach ($users as $user)
					{
						$recipients[$user['user_id']] = $user['username'];
					}

					$data['message_recipients'] = serialize($recipients);
					$data['message_text']       = $this->_getHelper()->getMessageColor($matches[2], $settings, $options);
					$data['message_type']       = 'whisper';
				}
			}

			$data['message_text'] = $this->_getHelper()->getMessageColor($data['message_text'], $settings, $options);

			if (!$options->siropu_chat_disable_all_bbcodes)
			{
				$data['message_text'] = $this->_getHelper()->stripDisallowedBBCodes($data['message_text']);
			}

			$tagged = $this->getModelFromCache('XenForo_Model_UserTagging')->getTaggedUsersInMessage($data['message_text'], $newMessage, $options->siropu_chat_link_tagged_users ? 'bb' : '');

			if (isset($tagged[$userId]))
			{
				unset($tagged[$userId]);
			}

			if ($tagged)
			{
				$data['message_text']   = $newMessage;
				$data['message_tagged'] = $this->_getHelper()->prepareTaggedUsers($tagged);
			}

			$quit = false;

			if (preg_match('/^\/quit/i', $message)
				&& $options->siropu_chat_quit_command_enabled
				&& $this->_getHelper()->userHasPermission('quitCommand'))
			{
				$quit = true;
			}

			if ($quit)
			{
				if ($session && $session['user_last_activity'])
				{
					$user    = '[USER=' . $userId . ']' . $username . '[/USER]';
					$message = trim(str_ireplace('/quit', '', $message));

					$data['message_text'] = new XenForo_Phrase($message ? 'siropu_chat_quit_message' : 'siropu_chat_quit',
						array('name' => $user, 'message' => $message ? $message : ''));
					$data['message_type'] = 'quit';

					$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
					$dw->setExistingData($this->_getUID());
					$dw->set('user_last_activity', 0);
					$dw->save();
				}
				else
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_quit_error'));
				}
			}

			$kickCommand = $options->siropu_chat_kick_command;
			$kick        = false;

			if (preg_match('/^\/kick\s(.+?)$/i', $message, $matches)
				&& $kickCommand['enabled']
				&& ($this->_getHelper()->userHasPermission('kickCommand')
					|| ($this->_getHelper()->userHasPermission('kickCommandRoom')
						&& $this->_getModel()->getRoomByIdAndUserId($roomId, $userId))))
			{
				if (!$kickUser = $this->_getUserModel()->getUserByName($matches[1]))
				{
					return $this->responseError(new XenForo_Phrase('requested_user_not_found'));
				}

				$kickUserId = $kickUser['user_id'];

				if ($kickUser['username'] == $username)
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_kick_error_self'));
				}

				if ($kickUser['is_admin'] || $kickUser['is_moderator'])
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_kick_error_staff'));
				}

				if ((!$kickSess = $this->_getModel()->getSession($kickUserId)) || !$kickSess['user_last_activity'])
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_kick_no_chat_session'));
				}

				if ($kickSess['user_room_id'] != $session['user_room_id'])
				{
					return $this->responseError(new XenForo_Phrase('siropu_chat_kick_error_room'));
				}

				$this->_kickUser($kickSess, $kickCommand['length']);
				$notifications = $this->_getOptions()->siropu_chat_displayed_notifications;

				if (!$notifications['kick'])
				{
					return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array('kick' => $kickUserId));
				}

				$data['message_text'] = new XenForo_Phrase('siropu_chat_bot_user_kicked', array(
						'user' => '[USER=' . $kickUserId . ']' . $kickUser['username'] . '[/USER]',
						'mod'  => '[USER=' . $userId . ']' . $username . '[/USER]'));
				$data['message_type'] = 'bot';

				$kick = $kickUserId;
			}

			$prune = false;

			if (preg_match('/^\/prune/i', $message) && $this->_getHelper()->userHasPermission('deleteAll'))
			{
				if (preg_match('/^\/prune\s(.+?)$/i', trim($message), $matches))
				{
					if ($matches[1] == 'all')
					{
						$this->_deleteAllRoomsMessages();
						$prune = 'all';
					}
					else if ($user = $this->_getUserModel()->getUserByName($matches[1]))
					{
						$this->_getModel()->deleteMessagesByUserId($user['user_id'], $roomId);
						$prune = $user['username'];
					}
				}
				else
				{
					$this->_getModel()->deleteMessagesByRoomId($roomId);
					$this->_addMessageDeleteAll($roomId);
					$prune = 'all';
				}
			}
			else
			{
				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
				$dw->bulkSet($data);
				$dw->save();
			}

			if ($tagged && $options->siropu_chat_tag_alert_enabled && $data['message_type'] != 'whisper')
			{
				$room  = $this->_getModel()->getRoomById($roomId);
				$users = $this->_getUserModel()->getUsersByIds(array_keys($tagged),
					array('join' => XenForo_Model_User::FETCH_USER_PERMISSIONS));

				foreach ($users as $user)
				{
					$permissions = XenForo_Permission::unserializePermissions($user['global_permission_cache']);

					if (!$this->_getHelper()->checkRoomPermissions($room, $user)
						|| ($room
							&& $room['room_password']
							&& $room['room_user_id'] != $user['user_id']
							&& !XenForo_Permission::hasPermission($permissions, 'siropu_chat', 'bypassPassword')))
					{
						unset($tagged[$user['user_id']]);
					}
				}

				if ($tagged)
				{
					foreach ($tagged as $tag)
					{
						XenForo_Model_Alert::alert(
							$tag['user_id'],
							$userId,
							$username,
							'siropu_chat',
							$dw->get('message_id'),
							'tag'
						);
					}
				}
			}

			$updateSession = true;
			$messageCount  = 0;

			if ($sessionUpdateInterval = $options->siropu_chat_session_update_interval)
			{
				if (($lastSessionUpdate = XenForo_Helper_Cookie::getCookie('lastSessionUpdate'))
					&& $lastSessionUpdate >= time() - $sessionUpdateInterval)
				{
					$updateSession = false;
				}
				else
				{
					XenForo_Helper_Cookie::setCookie('lastSessionUpdate', time(), time() + $sessionUpdateInterval);
				}

				if ($options->siropu_chat_top_chatters)
				{
					$messageCount = XenForo_Helper_Cookie::getCookie('messageCount');
					XenForo_Helper_Cookie::setCookie('messageCount', $updateSession ? 0 : $messageCount + 1, 86400 * 365);
				}
			}

			if ($userId && $updateSession && !$quit)
			{
				$messageCount = $messageCount ? $messageCount + $session['user_message_count'] : $session['user_message_count'];
				
				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
				if ($session)
				{
					$dw->setExistingData($userId);
				}
				else
				{
					$dw->set('user_id', $userId);
				}
				if ($options->siropu_chat_top_chatters)
				{
					$dw->set('user_message_count', ($session ? $messageCount + 1 : 1));
				}
				if ($session && $session['user_room_id'] != $roomId)
				{
					$dw->set('user_room_id', $roomId);
					$this->_getHelper()->setRoomCookie($roomId);
				}
				$dw->set('user_last_activity', time());
				$dw->save();
			}

			return $this->_getChat($this->_getRoomID(), array(
				'action' => 'submit',
				'kick'   => $kick,
				'prune'  => $prune
			));
		}

		$errors[] = new XenForo_Phrase('siropu_chat_submit_no_message');

		if ($options->siropu_chat_disable_all_bbcodes)
		{
			$errors[] = new XenForo_Phrase('siropu_chat_bbcodes_disabled');
		}

		return $this->responseError($errors);
	}
	public function actionRefresh()
	{
		return $this->_getChat($this->_getRoomID());
	}
	public function actionMedia()
	{
		$type = $this->_input->filterSingle('type', XenForo_Input::STRING);

		$viewParams = array(
			'templateHtml' => new XenForo_Template_Public('siropu_chat_media', array(
				'type'  => $type,
				'sites' => ($type == 'media') ? $this->getModelFromCache('XenForo_Model_BbCode')->getAllBbCodeMediaSites() : '',
			)
		));

		return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', $viewParams);
	}
	public function actionEdit()
	{
		$message = $this->_getMessageOrError();

		if ($this->_getHelper()->userHasPermission('editAny')
			|| ($this->_getHelper()->userHasPermission('editOwn') && $message['message_user_id'] == $this->_getUID()))
		{
			$viewParams = array(
				'message' => $message,
				'user'    => $this->_getUserModel()->getUserById($message['message_user_id'])
			);

			if ($this->isConfirmedPost())
			{
				$text = $this->_input->filterSingle('message', XenForo_Input::STRING);

				if ($this->_getOptions()->siropu_chat_disable_all_bbcodes)
				{
					$text = XenForo_Helper_String::bbCodeStrip($text);
				}
				else
				{
					$text = Siropu_Chat_Helper::stripDisallowedBBCodes($text);
				}

				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
				$dw->setExistingData($this->_getMessageID());
				$dw->set('message_text', $text);
				$dw->save();

				return $this->responseView('Siropu_Chat_ViewPublic_Edit', '', array(
					'message' => $this->_getMessageOrError())
				);
			}

			return $this->responseView('', 'siropu_chat_message_edit', $viewParams);
		}

		return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
	}
	public function actionDelete()
	{
		$message = $this->_getMessageOrError();

		if ($this->_getHelper()->userHasPermission('deleteAny')
			|| ($this->_getHelper()->userHasPermission('deleteOwn') && $message['message_user_id'] == $this->_getUID()))
		{
			$viewParams = array(
				'message' => $message,
				'user'    => $this->_getUserModel()->getUserById($message['message_user_id'])
			);

			if ($this->isConfirmedPost())
			{
				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
				$dw->setExistingData($this->_getMessageID());
				$dw->delete();

				if ($this->_getOptions()->siropu_chat_delete_messages_delete_reports
					&& ($report = $this->_getModel()->getReportByMessageId($this->_getMessageID())))
				{
					$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Reports');
					$dw->setExistingData($report['report_id']);
					$dw->delete();
				}

				$this->_getHelper()->saveMessageAction($message, 'delete');

				return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array(
					'messageId' => $this->_getMessageID()
				));
			}

			return $this->responseView('', 'siropu_chat_message_delete', $viewParams);
		}

		return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
	}
	public function actionQuote()
	{
		if (!$message = $this->_getModel()->getMessageByIdJoinUsers($this->_getMessageID()))
		{
			$this->responseError(new XenForo_Phrase('siropu_chat_message_not_found'));
		}

		return $this->responseView('Siropu_Chat_ViewPublic_Quote', '', array('message' => $message));
	}
	public function actionReport()
	{
		if ($this->_getModel()->getReportByMessageId($this->_input->filterSingle('message_id', XenForo_Input::UINT)))
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_message_already_reported'));
		}

		$message = $this->_getMessageOrError();

		if ($this->_getHelper()->userHasPermission('report'))
		{
			$message['message_text'] = XenForo_Helper_String::bbCodeStrip($message['message_text']);

			$viewParams = array(
				'message' => $message,
				'user'    => $this->_getUserModel()->getUserById($message['message_user_id'])
			);

			if ($this->isConfirmedPost())
			{
				if (!$reason = $this->_input->filterSingle('report_reason', XenForo_Input::STRING))
				{
					return $this->responseError(new XenForo_Phrase('please_enter_reason_for_reporting_this_message'));
				}

				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Reports');
				$dw->bulkSet(array(
					'report_message_id' => $message['message_id'],
					'report_room_id'    => $message['message_room_id'],
					'report_user_id'    => $this->_getUID(),
					'report_reason'     => $reason
				));
				$dw->save();

				return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array(
					'messageId' => $message['message_id']
				));
			}

			return $this->responseView('', 'siropu_chat_message_report', $viewParams);
		}

		return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
	}
	public function actionDeleteAll()
	{
		if (!$this->_getHelper()->userHasPermission('deleteAll'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		if ($this->isConfirmedPost())
		{
			if ($roomIds = $this->_input->filterSingle('room_id', XenForo_Input::ARRAY_SIMPLE))
			{
				foreach ($roomIds as $id)
				{
					$this->_getModel()->deleteMessagesByRoomId($id);
					$this->_addMessageDeleteAll($id);
				}
			}
			else
			{
				$this->_deleteAllRoomsMessages();
			}

			return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array('deleteSuccess' => true));
		}

		return $this->responseView('', 'siropu_chat_messages_delete', array(
			'rooms' => $this->_getModel()->getAllRooms())
		);
	}
	public function actionModerator()
	{
		$user = $this->_getUserOrError();

		$info = $this->_input->filter(array(
			'action'        => XenForo_Input::STRING,
			'room_id'       => XenForo_Input::UINT,
			'ban_id'        => XenForo_Input::UINT,
			'length_type'   => XenForo_Input::STRING,
			'length_value'  => XenForo_Input::UINT,
			'length_option' => XenForo_Input::STRING,
			'end_date'      => XenForo_Input::DATE_TIME
		));

		$data = $this->_input->filter(array(
			'ban_user_id' => XenForo_Input::UINT,
			'ban_room_id' => XenForo_Input::UINT,
			'ban_reason'  => XenForo_Input::STRING,
			'ban_type'    => XenForo_Input::STRING
		));

		if (!$data['ban_type'])
		{
			$data['ban_type'] = 'chat';
		}

		if (!$this->_getHelper()->userHasPermission('ban')
			|| ($this->_getHelper()->userHasPermission('ban')
				&& ($user['is_moderator'] || $user['is_admin'] || $user['is_staff'])))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$banData = ($info['action'] == 'unban') ? $this->_getModel()->getBanById($info['ban_id']) : '';
		$roomId  = $info['room_id'] ? $info['room_id'] : $user['user_room_id'];

		$viewParams = array(
			'user' => $user,
			'room' => ($roomId && $info['action'] == 'ban') ? $this->_getModel()->getRoomById($roomId) : 0,
			'ban'  => $banData
		);

		if ($this->isConfirmedPost())
		{
			$notifications = $this->_getOptions()->siropu_chat_displayed_notifications;
			$phraseData    = array(
				'user' => '[USER=' . $user['user_id'] . ']' . $user['username'] . '[/USER]',
				'mod'  => '[USER=' . $this->_getUID() . ']' . $this->_getVisitor()->username . '[/USER]',
			);

			switch ($info['action'])
			{
				case 'ban':

					if ($info['length_type'] == 'temporary')
					{
						if ($length = $info['length_value'])
						{
							$data['ban_end'] = strtotime("+{$length} {$info['length_option']}");
						}
						else if ($endDate = $info['end_date'])
						{
							$data['ban_end'] = $endDate;
						}

						if (!isset($data['ban_end']))
						{
							return $this->responseError(new XenForo_Phrase('siropu_chat_ban_length_required'));
						}
					}

					$data['ban_author'] = $this->_getUID();

					$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Bans');
					$dw->bulkSet($data);
					$dw->save();

					$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
					$dw->setExistingData($user['user_id']);
					$dw->set('user_is_banned', 1);
					$dw->set('user_last_activity', 0);
					$dw->save();

					if ($notifications['ban'])
					{
						$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
						$dw->bulkSet(array(
							'message_room_id' => $user['user_room_id'],
							'message_text'    => new XenForo_Phrase((($data['ban_type'] == 'chat' || !$data['ban_type']) ? 'siropu_chat_bot_user_banned' : 'siropu_chat_bot_user_room_banned'), $phraseData),
							'message_type'    => 'bot'
						));
						$dw->save();
					}

					break;
				case 'unban':

					if ($banData)
					{
						$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Bans');
						$dw->setExistingData($info['ban_id']);
						$dw->delete();
					}

					$userBans = $this->_getModel()->getUserBans($user['user_id']);

					if (!$userBans)
					{
						$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
						$dw->setExistingData($user['user_id']);
						$dw->set('user_is_banned', 0);
						$dw->save();
					}

					if ($notifications['unban'])
					{
						$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
						$dw->bulkSet(array(
							'message_room_id' => $user['user_room_id'],
							'message_text'    => new XenForo_Phrase((($banData['ban_type'] == 'chat') ? 'siropu_chat_bot_user_unbanned' : 'siropu_chat_bot_user_room_unbanned'), $phraseData),
							'message_type'    => 'bot'
						));
						$dw->save();
					}

					break;
			}

			return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array(
				'actionSuccess' => $user['user_id'],
				'banId'         => $info['ban_id']
			));
		}

		return $this->responseView('', ($info['action'] == 'ban') ? 'siropu_chat_ban' : 'siropu_chat_unban', $viewParams);
	}
	public function actionRules()
	{
		return $this->responseView('', 'siropu_chat_rules');
	}
	public function actionHelp()
	{
		$roomAuthor = false;

		if ($session = $this->_getModel()->getSession($this->_getUID()))
		{
			$roomAuthor = $this->_getModel()->getRoomByIdAndUserId($session['user_room_id'], $this->_getUID());
		}

		return $this->responseView('', 'siropu_chat_help', array('roomAuthor' => $roomAuthor));
	}
	public function actionKick()
	{
		$this->_assertPostOnly();

		$kickCommand = $this->_getOptions()->siropu_chat_kick_command;

		if (!$kickCommand['enabled'] && !$this->_getHelper()->userHasPermission('kickCommand'))
		{
			return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
		}

		$kickUser = $this->_getUserOrError();

		if ($kickUser['is_admin'] || $kickUser['is_moderator'])
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_kick_error_staff'));
		}

		$session = $this->_getModel()->getSession($this->_getUID());
		$roomId  = $kickUser['user_room_id'];

		if (!$session['user_last_activity'])
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_kick_no_chat_session'));
		}

		if ($roomId != $session['user_room_id'])
		{
			return $this->responseError(new XenForo_Phrase('siropu_chat_kick_error_room'));
		}

		$this->_kickUser($kickUser, $kickCommand['length']);
		$notifications = $this->_getOptions()->siropu_chat_displayed_notifications;

		if ($notifications['kick'])
		{
			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
			$dw->bulkSet(array(
				'message_room_id' => $roomId,
				'message_text'    => new XenForo_Phrase('siropu_chat_bot_user_kicked', array(
					'user' => '[USER=' . $kickUser['user_id'] . ']' . $kickUser['username'] . '[/USER]',
					'mod'  => '[USER=' . $this->_getUID() . ']' . $this->_getVisitor()->username . '[/USER]')),
				'message_type'    => 'bot'
			));
			$dw->save();
		}

		return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array('kicked' => $kickUser['user_id']));
	}
	public function actionLogout()
	{
		if ($session = $this->_getModel()->getSession($this->_getUID()))
		{
			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
			$dw->setExistingData($this->_getUID());
			$dw->set('user_last_activity', 0);
			$dw->save();

			return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', array('loggedOut' => $this->_getUID()));
		}

		return $this->responseError(new XenForo_Phrase('do_not_have_permission'));
	}
	public function actionEnable()
	{
		$this->_assertPostOnly();

		$viewParams = array();

		if ($session = $this->_getModel()->getSession($this->_getUID()))
		{
			$settings = unserialize($session['user_settings']);
			$settings['disabled'] = 0;

			$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
			$dw->setExistingData($this->_getUID());
			$dw->set('user_settings', serialize($settings));
			$dw->save();

			$viewParams['enabled'] = true;
		}

		return $this->responseView('Siropu_Chat_ViewPublic_Ajax', '', $viewParams);
	}
	protected function _kickUser($user, $length)
	{
		$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Bans');
		$dw->bulkSet(array(
			'ban_user_id' => $user['user_id'],
			'ban_room_id' => $user['user_room_id'],
			'ban_author'  => $this->_getUID(),
			'ban_end'     => strtotime("+{$length} hours"),
			'ban_type'    => 'kick'
		));
		$dw->save();

		$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
		$dw->setExistingData($user['user_id']);
		$dw->bulkSet(array(
			'user_is_banned'     => 1,
			'user_last_activity' => 0
		));
		$dw->save();
	}
	protected function _getChat($roomId, $return = array())
	{
		$data = $this->_input->filter(array(
			'room_id'      => XenForo_Input::UINT,
			'last_id'      => XenForo_Input::UINT,
			'inverse'      => XenForo_Input::UINT,
			'show_ignored' => XenForo_Input::UINT,
			'no_users'     => XenForo_Input::UINT,
			'all_pages'    => XenForo_Input::UINT,
			'embedded'     => XenForo_Input::UINT
		));

		$ignored         = $this->_getHelper()->getIgnoredUsers();
		$refreshUserList = true;

		if ($userListRefreshInterval = $this->_getOptions()->siropu_chat_user_list_refresh_interval)
		{
			if (($lastUserListUpdate = XenForo_Helper_Cookie::getCookie('lastUserListUpdate'))
				&& $lastUserListUpdate >= time() - $userListRefreshInterval)
			{
				$refreshUserList = false;
			}
			else
			{
				XenForo_Helper_Cookie::setCookie('lastUserListUpdate', time());
			}
		}

		$data = array_merge($data, $return, array(
			'room_id'         => $roomId,
			'refreshUserList' => $refreshUserList
		));

		$viewParams = array(
			'messages' => $this->_getModel()->getMessages(array('last_id' => $data['last_id'], 'room_id' => $data['room_id']), array('page' => 1, 'perPage'  => $this->_getOptions()->siropu_chat_messages_limit), $data['inverse'], ($data['show_ignored'] ? array() : $ignored)),
			'users'    => ($this->_getOptions()->siropu_chat_user_list_enabled && $refreshUserList) ? $this->_getModel()->getActiveUsers($ignored) : array(),
			'data'     => $data
		);

		return $this->responseView('Siropu_Chat_ViewPublic_Public', 'siropu_chat_messages', $viewParams);
	}
	protected function _getBannedMessage($session, $roomId)
	{
		if ($session && $session['user_is_banned'] && ($userBans = $this->_getModel()->getUserBans($this->_getUID())))
		{
			$banData = '';

			foreach ($userBans as $ban)
			{
				if ($ban['ban_room_id'] == $roomId || $ban['ban_type'] == 'chat')
				{
					$banData = $ban;
					break;
				}
			}

			if ($banData)
			{
				$phraseData = array('reason' => $banData['ban_reason'] ? $banData['ban_reason'] : 'N/A', 'ends' => $banData['ban_end'] ? XenForo_Locale::dateTime($banData['ban_end']) : new XenForo_Phrase('never'));

				if ($banData['ban_end'] && $banData['ban_end'] < time())
				{
					return false;
				}

				switch ($banData['ban_type'])
				{
					case 'room':
						return new XenForo_Phrase('siropu_chat_banned_room_message', $phraseData);
						break;
					case 'chat':
						return new XenForo_Phrase('siropu_chat_banned_message', $phraseData);
						break;
					case 'kick':
						return new XenForo_Phrase('siropu_chat_kicked_message',
							array('date' => XenForo_Locale::dateTime($banData['ban_end'])));
						break;
				}
			}
		}
	}
	protected function _deleteAllRoomsMessages()
	{
		$rooms = $this->_getModel()->getAllRooms();

		if (!$rooms)
		{
			$rooms[]['room_id'] = 0;
		}

		foreach ($rooms as $room)
		{
			$this->_getModel()->deleteMessagesByRoomId($room['room_id']);
			$this->_addMessageDeleteAll($room['room_id']);
		}
	}
	protected function _addMessageDeleteAll($roomId = 0)
	{
		$dwData = array(
			'message_room_id' => $roomId,
			'message_user_id' => $this->_getUID(),
			'message_text'    => new XenForo_Phrase('siropu_chat_all_messages_deleted', array('name' => '[USER=' . $this->_getUID() . ']' . $this->_getVisitor()->username . '[/USER]')),
			'message_type'    => 'bot',
		);

		$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
		$dw->bulkSet($dwData);
		$dw->save();

		$dwData['message_id'] = $dw->get('message_id');
		$this->_getHelper()->saveMessageAction($dwData, 'prune');
	}
	protected function _getMessageOrError($id = null)
	{
		if (!$id)
		{
			$id = $this->_getMessageID();
		}

		if ($data = $this->_getModel()->getMessageById($id))
		{
			return $data;
		}

		throw $this->responseException($this->responseError(new XenForo_Phrase('siropu_chat_message_not_found'), 404));
	}
	protected function _getUserOrError($id = null)
	{
		if (!$id)
		{
			$id = $this->_input->filterSingle('user_id', XenForo_Input::UINT);
			$id = $id ? $id : $this->_input->filterSingle('ban_user_id', XenForo_Input::UINT);
		}

		if ($data = $this->_getModel()->getSessionJoinUser($id))
		{
			return $data;
		}

		throw $this->responseException($this->responseError(new XenForo_Phrase('requested_user_not_found'), 404));
	}
	protected function _getModel()
	{
		return $this->getModelFromCache('Siropu_Chat_Model');
	}
	protected function _getUserModel()
	{
		return $this->getModelFromCache('XenForo_Model_User');
	}
	protected function _getHelper()
	{
		return $this->getHelper('Siropu_Chat_Helper');
	}
	protected function _getOptions()
	{
		return XenForo_Application::get('options');
	}
	protected function _getVisitor()
	{
		return XenForo_Visitor::getInstance();
	}
	protected function _getUID()
	{
		return $this->_getVisitor()->user_id;
	}
	protected function _getMessageID()
	{
		return $this->_input->filterSingle('message_id', XenForo_Input::UINT);
	}
	protected function _getRoomID($validate = true)
	{
		$roomId = $this->_input->filterSingle('room_id', XenForo_Input::UINT);

		if ($this->_input->filterSingle('embedded', XenForo_Input::UINT))
		{
			return $roomId;
		}

		if ($validate && $roomId)
		{
			if ($roomIdCookie = XenForo_Helper_Cookie::getCookie('chatRoom'))
			{
				if ($roomIdCookie != $roomId)
				{
					$roomId = $roomIdCookie;
				}
			}
			else if ($session = $this->_getModel()->getSession($this->_getUID()))
			{
				$roomId = $session['user_room_id'];
				$this->_getHelper()->setRoomCookie($roomId);
			}
		}

		return $roomId;
	}
}