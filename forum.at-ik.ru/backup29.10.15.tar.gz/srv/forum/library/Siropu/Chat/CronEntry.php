<?php 

/*
	
*/

class Siropu_Chat_CronEntry
{
	public static function daily()
    {
		if (self::_getOptions()->siropu_chat_enabled)
		{
			self::deleteOlderMessages();
			self::deleteOlderReports();
			self::deleteInactiveSessions();
		}
	}
	public static function deleteOlderMessages()
    {
		if ($days = self::_getOptions()->siropu_chat_delete_old_messages)
		{
			self::_getModel()->deleteOlderMessages(strtotime("-{$days} Days"));
		}
	}
	public static function deleteOlderReports()
    {
		if ($days = self::_getOptions()->siropu_chat_delete_old_reports)
		{
			self::_getModel()->deleteOlderReports(strtotime("-{$days} Days"));
		}
	}
	public static function deleteInactiveSessions()
    {
		self::_getModel()->deleteInactiveSessions();
	}
	public static function deleteExpiredBans()
	{
		self::_getModel()->deleteExpiredBans();
	}
	protected static function _getModel()
	{
		return XenForo_Model::create('Siropu_Chat_Model');
	}
	protected static function _getOptions()
	{
		return XenForo_Application::get('options');
	}
}