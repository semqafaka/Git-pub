<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_DataWriter_Extend_Thread extends XFCP_Siropu_Chat_DataWriter_Extend_Thread
{
	protected function _postSaveAfterTransaction()
	{
		$options = XenForo_Application::get('options');
		$forumId = $this->get('node_id');

		if ($this->isInsert()
			&& $options->siropu_chat_forum_activity_threads
			&& Siropu_Chat_Helper::checkForSelectedForums($forumId))
		{
			$forum    = $this->_getForumData();
			$threadId = $this->get('thread_id');
			$title    = $this->get('title');
			$username = $this->get('username');

			$message = new Xenforo_Phrase('siropu_chat_bot_new_thread', array('user' => '[USER=' . $this->get('user_id') . ']' . $username . '[/USER]', 'thread' => '[URL=' . XenForo_Link::buildPublicLink('full:threads', array('thread_id' => $threadId, 'title' => $title)) . ']' . $title . '[/URL]', 'forum' => '[URL=' . XenForo_Link::buildPublicLink('full:forums', array('node_id' => $forumId, 'title' => $forum['title'])) . ']' . $forum['title'] . '[/URL]'), false);

			$displayContent = $options->siropu_chat_forum_activity_content;

			if ($displayContent['enabled'])
			{
				$post = $this->_getLastMessageInDiscussion();

				if ($limit = $displayContent['limit'])
				{
					$post['message'] = XenForo_Template_Helper_Core::helperSnippet($post['message'], $limit);
				}

				$message .= ' [QUOTE="' . $username . '"]' . $post['message'] . '[QUOTE]';
			}

			$writer = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
			$writer->bulkSet(array(
				'message_text' => $message,
				'message_type' => 'activity'
			));
			$writer->save();
		}

		return parent::_postSaveAfterTransaction();
	}
}