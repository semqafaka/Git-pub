<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_DataWriter_Extend_User extends XFCP_Siropu_Chat_DataWriter_Extend_User
{
	protected function _postSave()
	{
		$options = XenForo_Application::get('options');
		$displayedNotification = $options->siropu_chat_displayed_notifications;

		if ($displayedNotification['welcome']
			&& ($this->isInsert() && $this->get('user_state') == 'valid'
				|| ($this->isUpdate()
					&& $this->isChanged('user_state')
					&& $this->getExisting('user_state') == 'email_confirm'
					&& $this->get('user_state') == 'valid')))
		{
			$writer = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Messages');
			$writer->bulkSet(array(
				'message_text' => new Xenforo_Phrase('siropu_chat_bot_new_user', array('name' => '[USER=' . $this->get('user_id') . ']' . $this->get('username') . '[/USER]')),
				'message_type' => 'bot'
			));
			$writer->save();
		}

		return parent::_postSave();
	}
}