<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_Helper
{
	public static function userHasPermission($permission)
	{
		$permissions = XenForo_Visitor::getInstance()->getPermissions();
		return XenForo_Permission::hasPermission($permissions, 'siropu_chat', $permission);
	}
	public static function getRoomId($session)
	{
		if (self::_getOptions()->siropu_chat_rooms_enabled && isset($session['user_room_id']))
		{
			return $session['user_room_id'];
		}

		return 0;
	}
	public static function setRoomCookie($roomId)
	{
		XenForo_Helper_Cookie::setCookie('chatRoom', $roomId, 86400 * 365);
	}
	public static function getChatClass($settings, $forceMode = false)
	{
		$displayMode = self::_getOptions()->siropu_chat_display_mode;

		if ($settings && isset($settings['display_mode']) && $settings['display_mode'])
		{
			$displayMode = $settings['display_mode'];
		}

		$class = array();

		switch ($forceMode)
		{
			case 'page':
				$displayMode = 'chat';
				break;
			case 'embed':
				$displayMode = 'embed';
				break;
		}

		switch ($displayMode)
		{
			case 'all':
				$class[] = 'siropuChatAllPages';
				break;
			case 'above_forums_list':
			case 'below_forums_list':
				$class[] = 'siropuChatForumsList';
				break;
			case 'sidebar_below_visitor_panel':
			case 'sidebar_bottom':
				$class[] = 'siropuChatSidebar';
				break;
			case 'chat':
				$class[] = 'siropuChatPage';
				break;
			case 'embed':
				$class[] = 'siropuChatEmbedded';
				break;
		}

		if (isset($settings['maximized']) && $settings['maximized'])
		{
			$class[] = 'siropuChatMaximized';
		}
		if (isset($settings['hide_chatters']) && $settings['hide_chatters']
			|| !self::_getOptions()->siropu_chat_user_list_enabled)
		{
			$class[] = 'siropuChatNoUsers';
		}

		if ($class)
		{
			return implode(' ', $class);
		}
	}
	public static function getChatRoomUsers($users, $roomId)
	{
		if (isset($users['data'][$roomId]))
		{
			return $users['data'][$roomId];
		}
	}
	public static function setSessionSettings($session = array(), $settings)
	{
		if ($session)
		{
			$session = unserialize($session['user_settings']);
		}

		foreach ($settings as $key => $val)
		{
			$session[$key] = $val;
		}

		return serialize($session);
	}
	public static function getNotices()
	{
		if ($notices = array_filter(explode('<--NOTICE-->', self::_getOptions()->siropu_chat_notices)))
		{
			shuffle($notices);
			return $notices[0];
		}
	}
	public static function getAds()
	{
		$ads = array();

		if ($aboveMessages = array_filter(explode('<--AD-->', self::_getOptions()->siropu_chat_ads_above_messages)))
		{
			shuffle($aboveMessages);
			$ads['aboveMessages'] = $aboveMessages[0];
		}
		if ($belowMessages = array_filter(explode('<--AD-->', self::_getOptions()->siropu_chat_ads_below_messages)))
		{
			shuffle($belowMessages);
			$ads['belowMessages'] = $belowMessages[0];
		}
		if ($belowEditor = array_filter(explode('<--AD-->', self::_getOptions()->siropu_chat_ads_below_editor)))
		{
			shuffle($belowEditor);
			$ads['belowEditor'] = $belowEditor[0];
		}

		return $ads;
	}
	public static function prepareLastRow($messages, $data)
	{
		$lastMessage = array();

		if ($messages)
		{
			$lastMessage = $data['inverse'] ? current($messages) : end($messages);
			$lastMessage['message_text'] = XenForo_Helper_String::bbCodeStrip($lastMessage['message_text']);
		}

		return $lastMessage;
	}
	public static function prepareUserSettings($session)
	{
		if ($session)
		{
			return unserialize($session['user_settings']);
		}

		return array();
	}
	public static function prepareColorList()
	{
		$list = array();
		foreach (XenForo_Helper_Color::$colors as $key => $val)
		{
			$list[$val] = ucfirst($key);
		}
		return $list;
	}
	public static function checkForSelectedForums($forumId)
	{
		$forums = self::_getOptions()->siropu_chat_forum_activity_select['selected'];

		if (empty($forums) || in_array($forumId, $forums))
		{
			return true;
		}
	}
	public static function checkRoomPermissions($room, $user = array())
	{
		if ($room['room_id'] && ($permissions = unserialize($room['room_permissions'])) && $permissions['in_group_ids'])
		{
			$user       = $user ? $user : XenForo_Visitor::getInstance()->toArray();
			$userGroups = explode(',', $user['secondary_group_ids']);
			array_unshift($userGroups, $user['user_group_id']);
			$inGroup    = false;

			foreach ($userGroups as $id)
			{
				if (in_array($id, $permissions['in_group_ids']))
				{
					$inGroup = true;
				}
			}

			return $inGroup;
		}

		return true;
	}
	public static function stripDisallowedBBCodes($message)
	{
		$standardBBCodes = array(
			'B'       => array('B' => '$1'),
			'I'       => array('I' => '$1'),
			'U'       => array('U' => '$1'),
			'S'       => array('S' => '$1'),
			'URL'     => array('URL' => '$1', 'URL\=(.+?)' => '$1'),
			'IMG'     => array('IMG' => '$1'),
			'FONT'    => array('FONT\=(.+?)' => '$2'),
			'SIZE'    => array('SIZE\=(.+?)' => '$2'),
			'COLOR'   => array('COLOR\=(.+?)' => '$2'),
			'MEDIA'   => array('MEDIA\=(.+?)' => false),
			'QUOTE'   => array('(QUOTE|QUOTE\=(.+?))' => false),
			'SPOILER' => array('SPOILER\=(.+?)' => false),
			'CODE'    => array('CODE\=(.+?)' => false)
		);

		if ($disallowedBBCodes = array_filter(explode("\n", self::_getOptions()->siropu_chat_disallowed_bbcodes)))
		{
			$message = XenForo_Helper_String::autoLinkBbCode($message, in_array('MEDIA', $disallowedBBCodes) ? false : true);

			foreach ($disallowedBBCodes as $BBCode)
			{
				$BBCode = strtoupper(trim($BBCode));

				if (!isset($standardBBCodes[$BBCode]))
				{
					$standardBBCodes[$BBCode] = array("({$BBCode}|{$BBCode}=(.+?))" => false);
				}

				foreach ($standardBBCodes[$BBCode] as $tag => $content)
				{
					$regex = '/\[' . $tag . '\](.+?)\[\/' . $BBCode . '\]/i';

					if (preg_match($regex, $message))
					{
						$message = preg_replace($regex, ($content ? $content : new XenForo_Phrase('siropu_chat_bbcode_disallowed', array('name' => $BBCode))), $message);
					}
				}
			}

			return $message;
		}

		return XenForo_Helper_String::autoLinkBbCode($message);
	}
	public static function prepareUserBans($bans, $session)
	{
		if ($bans)
		{
			$banType = array(
				'chat' => '',
				'room' => '',
				'kick' => ''
			);

			foreach ($bans as $ban)
			{
				if ($ban['ban_type'] == 'chat')
				{
					$banType['chat'] = $ban;
				}
				else if ($session && $session['user_room_id'] == $ban['ban_room_id'])
				{
					if ($ban['ban_type'] == 'kick')
					{
						$banType['kick'] = $ban;
					}
					else
					{
						$banType['room'] = $ban;
					}
				}
			}

			return $banType;
		}

		return $bans;
	}
	public static function getIgnoredUsers()
	{
		$visitor = XenForo_Visitor::getInstance();
		return (!empty($visitor['ignored']) ? unserialize($visitor['ignored']) : array());
	}
	public static function getMessageColor($message, $settings)
	{
		if (self::_getOptions()->siropu_chat_colored_messages_enabled
			&& self::userHasPermission('useColor')
			&& isset($settings['color'])
			&& $settings['color']
			&& !preg_match('/\[COLOR\=/i', $message))
		{
			return "[COLOR=#{$settings['color']}]{$message}[/COLOR]";
		}

		return preg_replace('/\[COLOR\=(.+?)\](.+?)\[\/COLOR\]/', '$2', $message);
	}
	public static function prepareTaggedUsers($tagged)
	{
		$users = array();

		foreach ($tagged as $user)
		{
			$users[$user['user_id']] = $user['username'];
		}

		return serialize($users);
	}
	public static function getMessageActionsDataFile($roomId = 0)
	{
		return XenForo_Helper_File::getExternalDataPath() . "/Siropu/Chat/Actions/{$roomId}.json";
	}
	public static function saveMessageAction($message, $action)
	{
		$file = self::getMessageActionsDataFile($message['message_room_id']);

		if ($action != 'prune')
		{
			$data = (array) json_decode(@file_get_contents($file), true);

			foreach ($data as $key => $val)
			{
				if ($val['date'] <= time() - self::_getOptions()->siropu_chat_refresh_rate_inactive_visible + 5)
				{
					unset($data[$key]);
				}
			}

			if ($message['message_type'] == 'whisper')
			{
				$message['message_text'] = '<i class="siropuChatWhisperAction">' . new XenForo_Phrase('siropu_chat_whisper') . '</i> ' . $message['message_text'];
			}
		}

		$data[$message['message_id']] = array(
			'author'     => self::_getVisitor()->user_id,
			'action'     => $action,
			'date'       => time(),
			'message'    => ($action == 'edit') ? $message['message_text'] : '',
			'recipients' => ($action == 'edit') ? unserialize($message['message_recipients']) : ''
		);

		@file_put_contents($file, json_encode($data));
	}
	public static function getMessageActions($roomId = 0)
	{
		$data = json_decode(@file_get_contents(self::getMessageActionsDataFile($roomId)), true);

		if ($data)
		{
			$userId = self::_getVisitor()->user_id;

			foreach ($data as $key => $val)
			{
				if (($val['recipients'] && !isset($val['recipients'][$userId]))
					|| ($val['date'] <= time() - self::_getOptions()->siropu_chat_refresh_rate_inactive_visible + 5)
					|| ($val['author'] == $userId))
				{
					unset($data[$key]);
				}
			}
		}

		return json_encode($data);
	}
	public static function refreshRoomsCache()
	{
		XenForo_Application::setSimpleCacheData('chatRooms', '');
		XenForo_Model::create('Siropu_Chat_Model')->getAllRooms();
	}
	protected static function _getOptions()
	{
		return XenForo_Application::get('options');
	}
	protected static function _getVisitor()
	{
		return XenForo_Visitor::getInstance();
	}
}