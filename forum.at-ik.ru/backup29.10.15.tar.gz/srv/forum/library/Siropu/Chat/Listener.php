<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_Listener
{
	public static $chatSession  = array();
	public static $chatSettings = array();

	public static function load_class_datawriter($class, &$extend)
	{
		switch ($class)
		{
			case 'XenForo_DataWriter_User':
				$extend[] = 'Siropu_Chat_DataWriter_Extend_User';
				break;
			case 'XenForo_DataWriter_Discussion_Thread':
				$extend[] = 'Siropu_Chat_DataWriter_Extend_Thread';
				break;
			case 'XenForo_DataWriter_DiscussionMessage_Post':
				$extend[] = 'Siropu_Chat_DataWriter_Extend_Post';
				break;
		}
	}
	public static function template_create(&$templateName, array &$params, XenForo_Template_Abstract $template)
	{
		if ($templateName == 'PAGE_CONTAINER')
        {
            $template->preloadTemplate('siropu_chat');
			$template->preloadTemplate('siropu_chat_disabled');
        }
	}
	public static function navigation_tabs(array &$extraTabs, $selectedTabId)
	{
		$options   = XenForo_Application::get('options');
		$chatPage  = $options->siropu_chat_page;
		$userCount = $options->siropu_chat_display_tab_chatters_count;

		if ($options->siropu_chat_enabled
			&& $chatPage['enabled']
			&& $chatPage['position']
			&& (Siropu_Chat_Helper::userHasPermission('view') || Siropu_Chat_Helper::userHasPermission('use')))
		{
			$extraTabs['chat' . (!$userCount ? ' no-chatters-count' : '')] = array(
				'href'          => XenForo_Link::buildPublicLink('chat'),
				'title'         => new XenForo_Phrase('siropu_chat'),
				'position'      => $chatPage['position'],
				'selected'      => ($selectedTabId == 'chat') ? true : false,
				'linksTemplate' => (Siropu_Chat_Helper::userHasPermission('viewArchive') || Siropu_Chat_Helper::userHasPermission('viewBanned')) ? 'siropu_chat_tab_links' : '',
				'counter'       => $userCount ? self::_getModel()->getActiveUsersCount() : 0
			);
		}
	}
	public static function template_hook($hookName, &$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$hookList = array('forum_list_nodes', 'footer', 'ad_sidebar_below_visitor_panel', 'ad_sidebar_bottom');

		if (in_array($hookName, $hookList) && self::_getOptions()->siropu_chat_enabled)
		{
			$displayMode    = self::_getOptions()->siropu_chat_display_mode;
			$templateParams = $template->getParams();

			if ($displayMode != 'embed'
				&& (Siropu_Chat_Helper::userHasPermission('view') || Siropu_Chat_Helper::userHasPermission('use'))
				&& $templateParams['controllerName'] != 'Siropu_Chat_ControllerPublic_Chat')
			{
				if (!self::$chatSession)
				{
					self::$chatSession  = self::_getModel()->getSession(self::_getVisitor()->user_id);
					self::$chatSettings = Siropu_Chat_Helper::prepareUserSettings(self::$chatSession);
				}

				if (isset(self::$chatSettings['display_mode'])
					&& ($userDisplayMode = self::$chatSettings['display_mode'])
					&& Siropu_Chat_Helper::userHasPermission('chooseDisplayMode'))
				{
					$displayMode = $userDisplayMode;
				}

				if ($displayMode == 'above_forums_list' && $hookName == 'forum_list_nodes')
				{
					$contents = self::_getChat($template, $templateParams, $displayMode) . $contents;
				}
				else if ($displayMode == 'below_forums_list' && $hookName == 'forum_list_nodes')
				{
					$contents .= self::_getChat($template, $templateParams, $displayMode);
				}
				else if ($displayMode == 'sidebar_below_visitor_panel' && $hookName == 'ad_sidebar_below_visitor_panel')
				{
					$contents .= self::_getChat($template, $templateParams, $displayMode);
				}
				else if ($displayMode == 'sidebar_bottom' && $hookName == 'ad_sidebar_bottom')
				{
					$contents .= self::_getChat($template, $templateParams, $displayMode);
				}
				else if ($displayMode == 'all' && $hookName == 'footer')
				{
					$contents .= self::_getChat($template, $templateParams);
				}
			}
		}
	}
	protected static function _getChat($template, $templateParams, $displayMode = 'all')
	{
		$userID   = self::_getVisitor()->user_id;
		$session  = self::$chatSession;
		$settings = self::$chatSettings;
		$settings = $settings ? $settings : self::_getOptions()->siropu_chat_default_user_settings;
		$userBans = array();

		if (isset($settings['disabled']) && $settings['disabled'])
		{
			return $template->create('siropu_chat_disabled', array('displayMode' => $displayMode));
		}

		if ($session && $session['user_is_banned'])
		{
			if ($userBans = self::_getModel()->getUserBans($userID))
			{
				foreach ($userBans as $ban)
				{
					if ($ban['ban_type'] == 'chat' && !self::_getOptions()->siropu_chat_banned_view_access)
					{
						return false;
					}
				}
			}
			else
			{
				$dw = XenForo_DataWriter::create('Siropu_Chat_DataWriter_Sessions');
				$dw->setExistingData($userID);
				$dw->set('user_is_banned', 0);
				$dw->save();

				$session['user_is_banned'] = 0;
			}
		}

		$usersRoom = $usersAll = array();
		$roomId = Siropu_Chat_Helper::getRoomId($session);

		if ($userListRefreshInterval = self::_getOptions()->siropu_chat_user_list_refresh_interval)
		{
			XenForo_Helper_Cookie::setCookie('lastUserListUpdate', time());

			$usersAll  = self::_getModel()->getActiveUsers(Siropu_Chat_Helper::getIgnoredUsers());
			$usersRoom = Siropu_Chat_Helper::getChatRoomUsers($usersAll, $roomId);
		}

		$viewParams = array(
			'chatClass'    => Siropu_Chat_Helper::getChatClass($settings),
			'chatSidebar'  => preg_match('/sidebar_/', $displayMode) ? true : false,
			'chatMode'     => $displayMode,
			'chatSession'  => $session,
			'chatSettings' => $settings,
			'chatRoomId'   => $roomId,
			'chatMessages' => array(),
			'chatLastRow'  => array(),
			'chatReports'  => self::_getModel()->getReportsCount(array('report_state' => 'open')),
			'chatUserBans' => Siropu_Chat_Helper::prepareUserBans($userBans, $session),
			'chatRooms'    => self::_getOptions()->siropu_chat_rooms_enabled ? self::_getModel()->getAllRooms() : '',
			'chatUsers'    => $usersRoom,
			'chatUsersAll' => $usersAll,
			'chatColors'   => Siropu_Chat_Helper::prepareColorList(),
			'chatNotice'   => Siropu_Chat_Helper::getNotices(),
			'chatAds'      => Siropu_Chat_Helper::getAds()
		);

		return $template->create('siropu_chat', array_merge($viewParams, $templateParams));
	}
	protected static function _getVisitor()
	{
		return XenForo_Visitor::getInstance();
	}
	protected static function _getOptions()
	{
		return XenForo_Application::get('options');
	}
	protected static function _getModel()
	{
		return XenForo_Model::create('Siropu_Chat_Model');
	}
}