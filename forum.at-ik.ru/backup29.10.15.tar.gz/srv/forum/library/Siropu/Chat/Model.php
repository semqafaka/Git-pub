<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_Model extends Xenforo_Model
{
	public function getSession($userID)
	{
		if ($userID)
		{
			return $this->_getDb()->fetchRow('
				SELECT *
				FROM xf_siropu_chat_sessions
				WHERE user_id = ?
			', $userID);
		}
	}
	public function getSessionJoinUser($userID)
	{
		return $this->_getDb()->fetchRow('
			SELECT s.*, u.username, u.is_moderator, u.is_admin, u.is_staff
			FROM xf_siropu_chat_sessions AS s
			LEFT JOIN xf_user AS u ON u.user_id = s.user_id
			WHERE s.user_id = ?
		', $userID);
	}
	public function getMessages($conditions = array(), $fetchOptions = array(), $inverse = false, $ignored = array())
	{
		$db = $this->_getDb();
		$limitOptions = $this->prepareLimitFetchOptions($fetchOptions);

		$where = '';

		if ($conditions)
		{
			if (isset($conditions['last_id']) && $conditions['last_id'])
			{
				$where .= ' WHERE message_id > ' . $db->quote($conditions['last_id']);
			}
			if (isset($conditions['message_id']) && $conditions['message_id'])
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_id = ' . $db->quote($conditions['message_id']);
			}
			if (isset($conditions['room_id']) && $conditions['room_id'] !== 'any')
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_room_id = ' . $db->quote($conditions['room_id']);
			}
			if (isset($conditions['keywords']))
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_text LIKE ' . $db->quote('%' . $conditions['keywords'] . '%');
			}
			if (isset($conditions['user_id']))
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_user_id IN (' . $this->_prepareUserIds($conditions['user_id']) . ')';
			}
			if (isset($conditions['date_start']))
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_date BETWEEN ' . $db->quote($conditions['date_start']) . ' AND ' . $db->quote($conditions['date_end']);
			}
		}

		$resultArray = $db->fetchAll($this->limitQueryResults('
			SELECT
				m.message_id,
				m.message_room_id,
				m.message_user_id AS user_id,
				m.message_recipients,
				m.message_tagged,
				m.message_text,
				m.message_text AS message,
				m.message_type,
				m.message_date,
				u.username,
				u.display_style_group_id,
				u.avatar_date,
				u.gravatar
			FROM xf_siropu_chat_messages AS m
			LEFT JOIN xf_user AS u ON u.user_id = m.message_user_id
			' . $where . '
			ORDER BY m.message_id DESC
		', $limitOptions['limit'], $limitOptions['offset']));

		$visitor = XenForo_Visitor::getInstance();
		$userId  = $visitor->user_id;

		foreach ($resultArray as $key => $val)
		{
			$recipients = unserialize($val['message_recipients']);

			if (($ignored && isset($ignored[$val['user_id']])) || ($recipients && !isset($recipients[$userId])))
			{
				unset($resultArray[$key]);
				$recipients = null;
			}
			else
			{
				if ($recipients)
				{
					unset($recipients[$userId]);
					$resultArray[$key]['message_recipients'] = implode(', ', $recipients);
				}

				$tagged = unserialize($val['message_tagged']);
				$resultArray[$key]['message_tagged'] = $tagged ? $tagged : array();

				switch ($val['message_type'])
				{
					case 'bot':
					case 'activity':
						$resultArray[$key]['class'] = 'siropuChatBot';
						break;
					case 'me':
						$resultArray[$key]['class'] = 'siropuChatMe';
						break;
					case 'quit':
						$resultArray[$key]['class'] = 'siropuChatQuit';
						break;
					case 'whisper':
						$resultArray[$key]['class'] = 'siropuChatWhisper';
						break;
				}

				if (in_array($val['message_type'], array('me', 'quit'))
						&& !$this->_getOptions()->siropu_chat_display_commands_by_bot)
				{
					$resultArray[$key]['hideAuthor'] = true;
				}
			}
		}

		if (empty($resultArray))
		{
			return array();
		}

		return $inverse ? $resultArray : array_reverse($resultArray);
	}
	public function getMessagesCount($conditions = array())
	{
		$db = $this->_getDb();
		$where = 'WHERE message_type NOT IN ("whisper")';

		if ($conditions)
		{
			if (isset($conditions['last_id']) && $conditions['last_id'])
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_id > ' . $db->quote($conditions['last_id']);
			}
			if (isset($conditions['message_id']) && $conditions['message_id'])
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_id = ' . $db->quote($conditions['message_id']);
			}
			if (isset($conditions['room_id']) && $conditions['room_id'] !== 'any')
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_room_id = ' . $db->quote($conditions['room_id']);
			}
			if (isset($conditions['keywords']))
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_text LIKE ' . $db->quote('%' . $conditions['keywords'] . '%');
			}
			if (isset($conditions['user_id']))
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_user_id IN (' . $this->_prepareUserIds($conditions['user_id']) . ')';
			}
			if (isset($conditions['date_start']))
			{
				$where .= ($where ? ' AND ' : ' WHERE ') . 'message_date BETWEEN ' . $db->quote($conditions['date_start']) . ' AND ' . $db->quote($conditions['date_end']);
			}
		}

		$result = $db->fetchRow('
			SELECT COUNT(*) AS count
			FROM xf_siropu_chat_messages
			' . $where
		);

		return $result['count'];
	}
	public function getMessageByIds($ids)
	{
		return $this->fetchAllKeyed('
			SELECT *
			FROM xf_siropu_chat_messages
			WHERE message_id IN (' . implode(',', $ids) . ')
		', 'message_id');
	}
	public function getMessageById($id)
	{
		return $this->_getDb()->fetchRow('
			SELECT *
			FROM xf_siropu_chat_messages
			WHERE message_id = ?
		', $id);
	}
	public function getMessageByIdJoinUsers($id)
	{
		return $this->_getDb()->fetchRow('
			SELECT
				m.*,
				u.user_id,
				u.username
			FROM xf_siropu_chat_messages AS m
			LEFT JOIN xf_user AS u ON u.user_id = m.message_user_id
			WHERE m.message_id = ?
		', $id);
	}
	public function getAllRooms()
	{
		if ($resultArray = XenForo_Application::getSimpleCacheData('chatRooms'))
		{
			return $resultArray;
		}

		$resultArray = $this->fetchAllKeyed('
			SELECT *
			FROM xf_siropu_chat_rooms
			ORDER BY room_id ASC
		', 'room_id');

		if ($resultArray)
		{
			$resultArray[0] = array(
				'room_id'          => 0,
				'room_name'        => new Xenforo_Phrase('siropu_chat_room_general_name'),
				'room_description' => new Xenforo_Phrase('siropu_chat_room_general_description')
			);

			ksort($resultArray);
		}

		XenForo_Application::setSimpleCacheData('chatRooms', $resultArray ? $resultArray : array(0));
		return $resultArray;
	}
	public function getRoomById($id)
	{
		return $this->_getDb()->fetchRow('
			SELECT *
			FROM xf_siropu_chat_rooms
			WHERE room_id = ?
		', $id);
	}
	public function getRoomByIdAndUserId($roomId, $userId)
	{
		$db = $this->_getDb();
		return $db->fetchRow('
			SELECT *
			FROM xf_siropu_chat_rooms
			WHERE room_id = ' . $db->quote($roomId) . '
			AND room_user_id = ' . $db->quote($userId)
		);
	}
	public function getActiveUsers($ignored = array())
	{
		$resultArray = $this->_getDb()->fetchAll('
			SELECT
				s.user_id,
				s.user_room_id,
				s.user_last_activity,
				u.username,
				u.display_style_group_id,
				u.avatar_date,
				u.gravatar,
				u.is_admin,
				u.is_moderator
			FROM xf_siropu_chat_sessions AS s
			LEFT JOIN xf_user AS u ON u.user_id = s.user_id
			WHERE s.user_last_activity >= ' . strtotime('-' . XenForo_Application::get('options')->siropu_chat_last_activity_minutes . ' Minutes') . '
			ORDER BY s.user_last_activity DESC
		');

		$data = array(
			'count' => count($resultArray),
			'data'  => array(),
			'users' => array()
		);

		foreach ($resultArray as $row)
		{
			if ($ignored && isset($ignored[$row['user_id']]))
			{
				$row['is_ignored'] = true;
			}

			$data['data'][$row['user_room_id']][] = $row;
			$data['users'][$row['user_room_id']][] = $row['username'];
		}

		foreach ($data['users'] as $key => $val)
		{
			$data['users'][$key] = implode(', ', $val);
		}

		return $data;
	}
	public function getActiveUsersCount()
	{
		$result = $this->_getDb()->fetchRow('
			SELECT COUNT(*) AS count
			FROM xf_siropu_chat_sessions AS s
			WHERE s.user_last_activity >= ' . strtotime('-' . XenForo_Application::get('options')->siropu_chat_last_activity_minutes . ' Minutes') . '
		');

		return $result['count'];
	}
	public function getTopChatters($limit = 10)
	{
		return $this->_getDb()->fetchAll('
			SELECT
				s.user_message_count,
				u.user_id,
				u.username,
				u.display_style_group_id,
				u.avatar_date,
				u.gravatar
			FROM xf_siropu_chat_sessions AS s
			LEFT JOIN xf_user AS u ON u.user_id = s.user_id
			WHERE s.user_message_count <> 0
			ORDER BY s.user_message_count DESC
			LIMIT ' . $limit
		);
	}
	public function getBannedUsers($conditions = array(), $fetchOptions = array())
	{
		$limitOptions = $this->prepareLimitFetchOptions($fetchOptions);

		$where = '';

		if (isset($conditions['user_id']))
		{
			$where .= ' WHERE b.ban_user_id IN (' . $this->_prepareUserIds($conditions['user_id']) . ')';
		}

		return $this->_getDb()->fetchAll($this->limitQueryResults('
			SELECT
				b.*,
				r.room_name,
				u1.user_id,
				u1.username,
				u1.display_style_group_id,
				u1.avatar_date,
				u1.gravatar,
				u2.user_id AS mod_user_id,
				u2.username AS mod_username
			FROM xf_siropu_chat_bans AS b
			LEFT JOIN xf_siropu_chat_rooms AS r ON r.room_id = b.ban_room_id
			LEFT JOIN xf_user AS u1 ON u1.user_id = b.ban_user_id
			LEFT JOIN xf_user AS u2 ON u2.user_id = b.ban_author
			' . $where . '
			ORDER BY b.ban_id DESC
		', $limitOptions['limit'], $limitOptions['offset']));
	}
	public function getBannedUsersCount($conditions = array())
	{
		$where = '';

		if (isset($conditions['user_id']))
		{
			$where .= ' WHERE user_id IN (' . $this->_prepareUserIds($conditions['user_id']) . ')';
		}

		$result = $this->_getDb()->fetchRow('
			SELECT COUNT(*) AS count
			FROM xf_siropu_chat_bans
			' . $where
		);

		return $result['count'];
	}
	public function getUserBans($userID)
	{
		return $this->_getDb()->fetchAll('
			SELECT *
			FROM xf_siropu_chat_bans
			WHERE ban_user_id = ?
		', $userID);
	}
	public function getBanById($banID)
	{
		return $this->_getDb()->fetchRow('
			SELECT *
			FROM xf_siropu_chat_bans
			WHERE ban_id = ?
		', $banID);
	}
	public function getReports($conditions = array(), $fetchOptions = array())
	{
		$db = $this->_getDb();
		$limitOptions = $this->prepareLimitFetchOptions($fetchOptions);

		$where = '';

		if ($conditions)
		{
			if (isset($conditions['report_state']))
			{
				$where .= ' WHERE report_state = ' . $db->quote($conditions['report_state']);
			}
		}

		return $db->fetchAll($this->limitQueryResults('
			SELECT
				r.*,
				m.message_text,
				m.message_date,
				rm.room_name,
				u.user_id,
				u.username
			FROM xf_siropu_chat_reports AS r
			LEFT JOIN xf_siropu_chat_messages AS m ON m.message_id = r.report_message_id
			LEFT JOIN xf_siropu_chat_rooms AS rm ON rm.room_id = r.report_room_id
			LEFT JOIN xf_user AS u ON u.user_id = m.message_user_id
			' . $where . '
			ORDER BY report_id DESC
		', $limitOptions['limit'], $limitOptions['offset']));
	}
	public function getReportsCount($conditions = array())
	{
		if (!Siropu_Chat_Helper::userHasPermission('manageReports'))
		{
			return false;
		}

		$db    = $this->_getDb();
		$where = '';

		if ($conditions)
		{
			if (isset($conditions['report_state']))
			{
				$where .= ' WHERE report_state = ' . $db->quote($conditions['report_state']);
			}
		}

		$result = $db->fetchRow('
			SELECT COUNT(*) AS count
			FROM xf_siropu_chat_reports
			' . $where
		);

		return $result['count'];
	}
	public function getReportById($id)
	{
		return $this->_getDb()->fetchRow('
			SELECT *
			FROM xf_siropu_chat_reports
			WHERE report_id = ?
		', $id);
	}
	public function getReportByIdComplete($id)
	{
		return $this->_getDb()->fetchRow('
			SELECT
				r.*,
				m.message_text,
				m.message_date,
				rm.room_name,
				u1.user_id,
				u1.username,
				u2.username AS r_username
			FROM xf_siropu_chat_reports AS r
			LEFT JOIN xf_siropu_chat_messages AS m ON m.message_id = r.report_message_id
			LEFT JOIN xf_siropu_chat_rooms AS rm ON rm.room_id = r.report_room_id
			LEFT JOIN xf_user AS u1 ON u1.user_id = m.message_user_id
			LEFT JOIN xf_user AS u2 ON u2.user_id = r.report_user_id
			WHERE r.report_id = ?
		', $id);
	}
	public function getReportByMessageId($id)
	{
		return $this->_getDb()->fetchRow('
			SELECT *
			FROM xf_siropu_chat_reports
			WHERE report_message_id = ?
		', $id);
	}
	public function changeUsersRoomId($roomId)
	{
		$db = $this->_getDb();
		$db->update('xf_siropu_chat_sessions', array('user_room_id' => 0), 'user_room_id = ' . $db->quote($roomId));
	}
	public function getUserRoomCount($userID)
	{
		$result = $this->_getDb()->fetchRow('
			SELECT COUNT(*) AS count
			FROM xf_siropu_chat_rooms
			WHERE room_user_id = ?
		', $userID);

		return $result['count'];
	}
	public function deleteUsersRoomBan($roomId)
	{
		$db = $this->_getDb();
		$db->delete('xf_siropu_chat_bans', 'ban_room_id = ' . $db->quote($roomId));
	}
	public function resetTopChatters()
	{
		$this->_getDb()->update('xf_siropu_chat_sessions', array('user_message_count' => 0), 'user_message_count > 0');
	}
	public function deleteUserBans($userId)
	{
		$db = $this->_getDb();
		$db->delete('xf_siropu_chat_bans', 'ban_user_id = ' . $db->quote($userId));
	}
	public function deleteExpiredBans()
	{
		$this->_getDb()->delete('xf_siropu_chat_bans', 'ban_end > 0 AND  ban_end <=' . time());
	}
	public function deleteOlderMessages($date)
	{
		$db = $this->_getDb();
		$db->delete('xf_siropu_chat_messages', 'message_date <= ' . $db->quote($date));
	}
	public function deleteOlderReports($date)
	{
		$db = $this->_getDb();
		$db->delete('xf_siropu_chat_reports', 'report_date <= ' . $db->quote($date));
	}
	public function deleteInactiveSessions()
	{
		$db = $this->_getDb();
		$db->delete('xf_siropu_chat_sessions', 'user_is_banned = 0 AND user_last_activity <= ' . $db->quote(strtotime('-30 Days')));
	}
	public function deleteMessagesByRoomId($id)
	{
		$db = $this->_getDb();
		$db->delete('xf_siropu_chat_messages', 'message_room_id = ' . $db->quote($id));

		if ($this->_getOptions()->siropu_chat_delete_messages_delete_reports)
		{
			$db->delete('xf_siropu_chat_reports', 'report_room_id = ' . $db->quote($id));
		}
	}
	public function deleteMessagesByUserId($userId, $roomId = 0)
	{
		$db = $this->_getDb();
		$where = 'message_user_id = ' . $db->quote($userId) . ' AND message_room_id = ' . $db->quote($roomId);

		$resultArray = $db->fetchAll('
			SELECT *
			FROM xf_siropu_chat_messages
			WHERE ' . $where . ' 
			AND message_date >= ' . (time() - 3600) . '
			ORDER BY message_date DESC
			LIMIT ' . $this->_getOptions()->siropu_chat_messages_limit
		);

		foreach ($resultArray as $row)
		{
			Siropu_Chat_Helper::saveMessageAction($row, 'delete');
		}

		$db->delete('xf_siropu_chat_messages', $where);
	}
	public function deleteAllMessages()
	{
		$this->_getDb()->query('TRUNCATE xf_siropu_chat_messages');

		if ($this->_getOptions()->siropu_chat_delete_messages_delete_reports)
		{
			$this->_getDb()->query('TRUNCATE xf_siropu_chat_reports');
		}
	}
	protected function _prepareUserIds($ids)
	{
		$list = array();

		foreach (array_filter(explode(',', $ids)) as $id)
		{
			$list[] = (int) $id;
		}

		return implode(',', $list);
	}
	protected function _getOptions()
	{
		return XenForo_Application::get('options');
	}
}