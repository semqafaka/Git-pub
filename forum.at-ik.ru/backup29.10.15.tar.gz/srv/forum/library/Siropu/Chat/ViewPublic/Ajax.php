<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_ViewPublic_Ajax extends XenForo_ViewPublic_Base
{
	public function renderJson()
	{
		return Xenforo_ViewRenderer_Json::jsonEncodeForOutput($this->_params);
	}
}