<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_ViewPublic_Edit extends XenForo_ViewPublic_Base
{
	public function renderJson()
	{
		$bbCodeParser = XenForo_BbCode_Parser::create(XenForo_BbCode_Formatter_Base::create('Base', array('view' => $this)));
		$message      = $bbCodeParser->render($this->_params['message']['message_text']);

		$this->_params['message']['message_text'] = $message;
		Siropu_Chat_Helper::saveMessageAction($this->_params['message'], 'edit');

		return Xenforo_ViewRenderer_Json::jsonEncodeForOutput(array(
			'messageEdited' => (($this->_params['message']['message_type'] == 'whisper') ? '<i class="siropuChatWhisperAction">' . new XenForo_Phrase('siropu_chat_whisper') . '</i> ' : '') . $message,
			'messageId'     => $this->_params['message']['message_id']
		));
	}
}