<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_ViewPublic_Public extends XenForo_ViewPublic_Base
{
	public function renderHtml()
    {
        $bbCodeParser = XenForo_BbCode_Parser::create(XenForo_BbCode_Formatter_Base::create('Base', array('view' => $this)));

        XenForo_ViewPublic_Helper_Message::bbCodeWrapMessages($this->_params['chatMessages'], $bbCodeParser);
    }
	public function renderJson()
	{
		$bbCodeParser = XenForo_BbCode_Parser::create(XenForo_BbCode_Formatter_Base::create('Base', array('view' => $this)));
		XenForo_ViewPublic_Helper_Message::bbCodeWrapMessages($this->_params['messages'], $bbCodeParser);

		$messages = $this->_params['messages'];
		$data     = $this->_params['data'];
		$lastRow  = Siropu_Chat_Helper::prepareLastRow($messages, $data);

		$action   = isset($data['action']) ? $data['action'] : false;
		$prune    = isset($data['prune']) ? $data['prune'] : false;

		return Xenforo_ViewRenderer_Json::jsonEncodeForOutput(array(
			'messages' => $messages ? $this->createTemplateObject('siropu_chat_messages', array(
				'chatMessages' => $messages,
				'bbCodeParser' => $bbCodeParser,
			))->render() : '',
			'users'    => $data['refreshUserList'] ? $this->createTemplateObject('siropu_chat_users', array(
				'chatUsers'    => Siropu_Chat_Helper::getChatRoomUsers($this->_params['users'], $data['room_id']),
				'chatSettings' => array('show_ignored' => $data['show_ignored'])
			))->render() : '',
			'lastRow'  => ($lastRow && $data['all_pages']) ? $this->createTemplateObject('siropu_chat_last_row', array(
				'chatLastRow' => $lastRow
			))->render() : '',
			'userCount'       => isset($this->_params['users']['count']) ? $this->_params['users']['count'] : false,
			'lastId'          => isset($lastRow['message_id']) ? $lastRow['message_id'] : 0,
			'refreshUserList' => $data['refreshUserList'],
			'messageActions'  => !$action ? Siropu_Chat_Helper::getMessageActions($data['room_id']) : '',
			'prune'           => isset($data['prune']) ? $data['prune'] : false,
			'kick'            => isset($data['kick']) ? $data['kick'] : false,
		));
	}
}