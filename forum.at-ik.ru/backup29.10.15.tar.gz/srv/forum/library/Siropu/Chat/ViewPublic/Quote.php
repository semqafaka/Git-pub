<?php

/*
	
	

	
	Null
	
	
*/

class Siropu_Chat_ViewPublic_Quote extends XenForo_ViewPublic_Base
{
	public function renderJson()
	{
		return Xenforo_ViewRenderer_Json::jsonEncodeForOutput(array(
			'quotedMessage' => '[QUOTE=' . $this->_params['message']['username'] . ']' . $this->_params['message']['message_text'] . '[/QUOTE]'
		));
	}
}