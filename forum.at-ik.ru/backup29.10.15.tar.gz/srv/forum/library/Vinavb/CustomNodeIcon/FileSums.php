<?php

class Vinavb_CustomNodeIcon_FileSums
{
	public static function getHashes()
	{
		return array (
  'library/Vinavb/CustomNodeIcon/DataWriter/Helper.php' => '324972d200e82fd872614cc7c77b385a',
  'library/Vinavb/CustomNodeIcon/Icon.php' => 'a49d7b4fc51c0ae75d4af0742484584d',
  'library/Vinavb/CustomNodeIcon/Listener.php' => 'a7e19e37f6db5a615b34b8f330fce2b9',
  'library/Vinavb/CustomNodeIcon/Option.php' => '4a22dce6c6f15920d58c0093b666d383',
  'library/Vinavb/CustomNodeIcon/XenForo/ControllerAdmin/Forum.php' => 'c04fe61ffb156c72736a1009f59a0114',
  'library/Vinavb/CustomNodeIcon/XenForo/ControllerAdmin/Page.php' => '60139b04186c3aee0428c163b19fed14',
  'library/Vinavb/CustomNodeIcon/XenForo/ControllerPublic/Misc.php' => '60bdc54e591fd08d714a949c84df079f',
  'library/Vinavb/CustomNodeIcon/XenForo/DataWriter/Forum.php' => '24c2b3a12bbca5124b75d953912d8177',
  'library/Vinavb/CustomNodeIcon/XenForo/DataWriter/Page.php' => 'ca8fba9ff1d09a7ce497df737de2eee2',
);
	}
}