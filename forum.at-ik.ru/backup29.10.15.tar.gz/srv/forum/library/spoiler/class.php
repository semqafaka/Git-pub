<?php

class spoiler_class
{
	public static function listen($class, array &$extend)
	{
		if ($class == 'XenForo_BbCode_Formatter_Base')
		{
			$extend[] = 'spoiler_spoiler';
		}
	}
}