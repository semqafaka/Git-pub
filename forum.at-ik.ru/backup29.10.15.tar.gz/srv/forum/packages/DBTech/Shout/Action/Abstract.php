<?php
abstract class DBTech_Shout_Action_Abstract
{
	public static function actionIndex() {}
}
?>