<?php
abstract class DBTech_Shout_Action_Admin_Abstract extends DBTech_Shout_Action_Abstract
{
	public static function _init()
	{
		switch (DBTech_Shout_Core_Admin::getSystem())
		{
			case 'XenForo':
				require_once('./packages/DBTech/Shout/adminfunctions_xenforo.php');
				break;

			case 'vBulletin':
				require_once('./packages/DBTech/Shout/adminfunctions_vbulletin.php');
				break;
		}
	}
}
?>