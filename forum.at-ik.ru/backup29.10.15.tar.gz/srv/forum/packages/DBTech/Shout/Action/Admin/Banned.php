<?php
class DBTech_Shout_Action_Admin_Banned extends DBTech_Shout_Action_Admin_Abstract
{
	public static function actionIndex()
	{
		print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_ban_management'));

		// ###########################################################
		$users = DBTech_Shout_Core_Admin::$db->fetchAll('
			SELECT
				commandlog.comment,
				commandlog.userid AS banneruserid,
				commandlog.dateline,
				commandlog.username AS cmdusername,
				banneduser.' . DBTech_Shout_Core_Admin::$db->lookup('user', 'userid') . ' AS userid,
				banneduser.dbtech_vbshout_shouts AS shouts,
				banneduser.username,
				banneruser.username AS bannerusername
			FROM $dbtech_vbshout_log AS commandlog
			LEFT JOIN $user AS banneduser ON(banneduser.' . DBTech_Shout_Core_Admin::$db->lookup('user', 'userid') . ' = commandlog.comment)
			LEFT JOIN $user AS banneruser ON(banneruser.' . DBTech_Shout_Core_Admin::$db->lookup('user', 'userid') . ' = commandlog.userid)
			WHERE commandlog.command = ?
				AND banneduser.dbtech_vbshout_banned = 1
			ORDER BY banneduser.username ASC
		', array(
			'ban'
		));

		if (count($users))
		{
			// Begin ugly hack
			$loguser = array();
			foreach ($users as $user)
			{
				if (!isset($loguser[$user['userid']]) OR $loguser[$user['userid']]['dateline'] < $user['dateline'])
				{
					// Overwrite array as needed
					$loguser[$user['userid']] = $user;
				}
			}
			$numusers = count($loguser);
			// End ugly hack

			$headings = array(
				'<input type="checkbox" name="allbox" ' . (DBTech_Shout_Core_Admin::getSystem() == 'vBulletin' ? 'onclick="js_check_all(this.form)" ' : '') . 'title="' . DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_check_all') . '" /> ' . DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_userid'),
				DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_username'),
				DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_banned_by'),
				DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_banned_on'),
				DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_shout_count'),
			);

			print_form_header('vbshout', 'banned');
			construct_hidden_code('action', 'update');
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_showing_users_x_to_y_of_z', array('param1' => 1, 'param2' => $numusers, 'param3' => $numusers)), count($headings), false, ' ');
			print_cells_row($headings, true);

			foreach ($loguser as $user)
			{
				$cell = array();
				$cell[] = "<input type=\"checkbox\" name=\"users[$user[userid]]\" value=\"1\" tabindex=\"1\" /> " . $user['userid'];
				$cell[] = $user['username'];
				$cell[] = $user['bannerusername'];
				$cell[] = DBTech_Shout_Core_Admin::dateTime($user['dateline']);
				$cell[] = DBTech_Shout_Core_Admin::numberFormat($user['shouts']);
				print_cells_row($cell);
			}
			print_cells_row(false);
			print_submit_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_lift_ban'), false, 6);
		}
		else
		{
			print_stop_message('dbtech_vbshout_no_users_matched_your_query');
		}
	}

	public static function actionUpdate()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		// Fetch the list of users
		$cleanedInput = DBTech_Shout_Core_Admin::filter(array('users' => TYPE_ARRAY));

		if (!count($cleanedInput['users']))
		{
			// We weren't unbanning anything
			print_stop_message('dbtech_vbshout_nothing_to_do');
		}

		// Grab all the userids
		$users = array_keys($cleanedInput['users']);

		// Unban all the users
		DBTech_Shout_Core_Admin::$db->update('user', array(
			'dbtech_vbshout_banned' => 0
		), 'WHERE ' . DBTech_Shout_Core_Admin::$db->lookup('user', 'userid') . ' ' . DBTech_Shout_Core_Admin::$db->queryList($users));

		foreach ($users as $userid)
		{
			// Log the unbanning
			DBTech_Shout_Shoutbox::logCommand('unban', $userid);
		}

		foreach ($instanceCache as $instanceid => $instance)
		{
			// We've changed shit
			DBTech_Shout_Shoutbox::setAop('shouts', 		$instanceid, false);
			DBTech_Shout_Shoutbox::setAop('shoutnotifs', 	$instanceid, false, true);
		}

		define('CP_REDIRECT', 'vbshout.php?do=banned');
		print_stop_message('dbtech_vbshout_users_unbanned');
	}
}
?>