<?php
class DBTech_Shout_Action_Admin_Chatroom extends DBTech_Shout_Action_Admin_Abstract
{
	public static function actionIndex()
	{
		// Init this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$chatroomsByInstance = array();
		foreach ($chatroomCache as $chatroomid => $chatroom)
		{
			if (!$chatroom['membergroupids'])
			{
				// This is an on-the-fly chatroom
				continue;
			}

			if (!isset($chatroomsByInstance[$chatroom['instanceid']]))
			{
				// init this
				$chatroomsByInstance[$chatroom['instanceid']] = array();
			}

			$chatroomsByInstance[$chatroom['instanceid']][$chatroomid] = $chatroom;
		}

		print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom_management'));

		// Table header
		$headings = array();
		$headings[] = DBTech_Shout_Core_Admin::phrase('title');
		$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_usergroups');
		$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance');
		$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_active');
		$headings[] = DBTech_Shout_Core_Admin::phrase('edit');

		if (count($chatroomsByInstance))
		{
			print_form_header('vbshout', 'chatroom');
			construct_hidden_code('action', 'massupdate');
			foreach ($chatroomsByInstance as $instanceid => $chatrooms)
			{
				print_table_header($instanceid ? $instanceCache[$instanceid]['name'] : DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_all_instances'), count($headings));
				print_cells_row($headings, true);

				foreach ($chatrooms as $chatroomid => $chatroom)
				{
					$usergroups = array();

					$memberGroupIds = explode(',', $chatroom['membergroupids']);
					if (in_array(-1, $memberGroupIds))
					{
						$usergroups[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_all_usergroups');
					}
					else
					{
						foreach($memberGroupIds as $usergroupid)
						{
							// Usergroup cache
							$usergroups[] = DBTech_Shout_Core_Admin::$usergroupcache[$usergroupid]['title'];
						}
					}

					// Table data
					$cell = array();
					$cell[] = $chatroom['title'];
					$cell[] = implode(', ', $usergroups);
					$cell[] = ($chatroom['instanceid'] ? $instanceCache[$chatroom['instanceid']]['name'] : DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_all_instances'));
					$cell[] = "<input type=\"hidden\" name=\"chatroom[$chatroomid][active]\" value=\"0\" /><input type=\"checkbox\" class=\"bginput\" name=\"chatroom[$chatroomid][active]\" value=\"1\"" . ($chatroom['active'] ? ' checked="checked"' : '') . " tabindex=\"1\" title=\"" . DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_active') . "\" />";
					$cell[] = construct_link_code(DBTech_Shout_Core_Admin::phrase('edit'), 'vbshout.php?do=chatroom&action=modify&chatroomid=' . $chatroomid);

					// Print the data
					print_cells_row($cell, false, false, -5, 'middle', false, true);
				}
				print_cells_row(false);
			}
			print_submit_row(DBTech_Shout_Core_Admin::phrase('save'), false, count($headings), false, construct_button_code(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_chatroom'), DBTech_Shout_Core_Admin::link('vbshout.php?do=chatroom&action=modify')));
		}
		else
		{
			print_form_header('vbshout', 'chatroom');
			construct_hidden_code('action', 'modify');
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom_management'), count($headings));
			print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_no_chatrooms'), false, count($headings));
			print_submit_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_chatroom'), false, count($headings));
		}
	}

	public static function actionModify()
	{
		// Init this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$instances = array();
		$instances[0] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_all_instances');
		
		asort($instances);

		// Fetch the list of users
		$cleanedInput = DBTech_Shout_Core_Admin::filter(array('chatroomid' => TYPE_UINT));

		$chatroomid = $cleanedInput['chatroomid'];
		$chatroom = ($chatroomid ? $chatroomCache[$chatroomid] : false);

		if (!is_array($chatroom))
		{
			// Non-existing chatroom
			$chatroomid = 0;
		}

		$defaults = array(
			'title' 			=> 'Example Chatroom',
			'active' 			=> 1,
			'image' 			=> '',
			'membergroupids' 	=> '-1',
			'instanceid' 		=> 0,
		);

		if ($chatroomid)
		{
			// Edit
			print_cp_header(strip_tags(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_editing_x_y', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'), 'param2' => $chatroom['title']))));
			print_form_header('vbshout', 'chatroom');
			construct_hidden_code('action', 'update');
			construct_hidden_code('chatroomid', $chatroomid);
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_editing_x_y', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'), 'param2' => $chatroom['title'])));
		}
		else
		{
			// Add
			print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_chatroom'));
			print_form_header('vbshout', 'chatroom');
			construct_hidden_code('action', 'update');
			construct_hidden_code('chatroom[creator]', DBTech_Shout_Core_Admin::$userinfo['userid']);
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_chatroom'));

			$chatroom = $defaults;
		}

		$memberGroupIds = explode(',', $chatroom['membergroupids']);
		if (in_array(-1, $memberGroupIds))
		{
			// Ensure only this is checked
			$chatroom['membergroupids'] = $defaults['membergroupids'];
		}

		print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_main_settings'), false, 2, 'optiontitle');
		print_input_row(DBTech_Shout_Core_Admin::phrase('title'), 							'chatroom[title]', 					$chatroom['title']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_active'),			'chatroom[active]',					$chatroom['active']);
		print_membergroup_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_usergroups'), 'chatroom[membergroupids]', 2, 		$chatroom);
		print_select_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), 		'chatroom[instanceid]', $instances,	$chatroom['instanceid']);

		print_submit_row(($chatroomid ? DBTech_Shout_Core_Admin::phrase('save') : DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_chatroom')));
	}

	public static function actionUpdate()
	{
		// Init this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'chatroomid' 		=> TYPE_UINT,
			'chatroom' 			=> TYPE_ARRAY,
		));

		if (!count($cleanedInput['chatroom']['membergroupids']) OR in_array(-1, $cleanedInput['chatroom']['membergroupids']))
		{
			// Ensure only this is checked
			$cleanedInput['chatroom']['membergroupids'] = '-1';
		}

		// init data manager
		$chatroomDm = new DBTech_Shout_DataManager_Chatroom(DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['chatroomid'])
		{
			if (!$existing = $chatroomCache[$cleanedInput['chatroomid']])
			{
				// Couldn't find the chatroom
				print_stop_message('dbtech_vbshout_invalid_x', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'), $cleanedInput['chatroomid']);
			}

			// Set existing
			$chatroomDm->setExistingData($existing);

			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$chatroomDm->bulkSet($cleanedInput['chatroom']);

		// Save! Hopefully.
		$chatroomDm->save();

		define('CP_REDIRECT', 'vbshout.php?do=chatroom');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'), $phrase);
	}

	public static function actionMassupdate()
	{
		// Init this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'chatroom' => TYPE_ARRAY
		));

		foreach ($cleanedInput['chatroom'] as $chatroomid => $chatroom)
		{
			if (!$existing = $chatroomCache[$chatroomid])
			{
				// Couldn't find the chatroom
				continue;
			}

			// init data manager
			$chatroomDm = new DBTech_Shout_DataManager_Chatroom(DBTech_Shout_DataManager::ERROR_EXCEPTION);
				$chatroomDm->setExistingData($existing);
				$chatroomDm->bulkSet($chatroom);
			$chatroomDm->save();
			unset($chatroomDm);
		}

		define('CP_REDIRECT', 'vbshout.php?do=chatroom');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'), DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited'));
	}

	public static function actionDelete()
	{
		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'chatroomid' => TYPE_UINT,
		));

		print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_delete_x', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'))));
		print_delete_confirmation('dbtech_vbshout_chatroom', $cleanedInput['chatroomid'], 'vbshout', 'chatroom', 'dbtech_vbshout_chatroom', array('action' => 'kill'), '', 'title');
		print_cp_footer();
	}

	public static function actionKill()
	{
		// Init this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'chatroomid' => TYPE_UINT,
			'kill' 		 => TYPE_BOOL
		));

		if (!$existing = $chatroomCache[$cleanedInput['chatroomid']])
		{
			// Couldn't find the chatroom
			print_stop_message('dbtech_vbshout_invalid_x', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'), $cleanedInput['chatroomid']);
		}

		// init data manager
		$chatroomDm = new DBTech_Shout_DataManager_Chatroom(DBTech_Shout_DataManager::ERROR_EXCEPTION);
			$chatroomDm->setExistingData($existing);
		$chatroomDm->delete();

		define('CP_REDIRECT', 'vbshout.php?do=chatroom');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_chatroom'), DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_deleted'));
	}
}
?>