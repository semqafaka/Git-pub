<?php
class DBTech_Shout_Action_Admin_Instance extends DBTech_Shout_Action_Admin_Abstract
{
	// Store the bitfield defs we need
	protected static $bitfields = array(
		'logging' 			=> 'nocache|dbtech_vbshout_commands',
		'editors' 			=> 'nocache|dbtech_vbshout_editors',
		'notices' 			=> 'nocache|dbtech_vbshout_notices',
		'shoutboxtabs' 		=> 'nocache|dbtech_vbshout_shoutboxtabs',
		
	);

	public static function actionIndex()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$displays = array(
			0 => DBTech_Shout_Core_Admin::phrase('disabled'),
			1 => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_after_navbar'),
			2 => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_above_footer')
		);

		print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance_management'));

//		print_table_start();
//		print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_additional_functions'));
//		print_description_row("<b>
//			<a href=\"vbshout.php?do=instance&action=permissions\">" . DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_view_instance_permissions') . "</a>"
			
//		. "</b>", 0, 2, '', 'center');
//		print_table_footer();

		// Table header
		$headings = array();
		$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_varname_short');
		$headings[] = DBTech_Shout_Core_Admin::phrase('title');
		//$headings[] = DBTech_Shout_Core_Admin::phrase('description');
		$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_active');
		$headings[] = DBTech_Shout_Core_Admin::phrase('display_order');
		//$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_sticky');
		$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_auto_display');
		$headings[] = DBTech_Shout_Core_Admin::phrase('edit');
		$headings[] = DBTech_Shout_Core_Admin::phrase('delete');

		if (count($instanceCache))
		{
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'massupdate');
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance_management'), count($headings), false, '', 'center', false);

			print_cells_row($headings, true);
			foreach ($instanceCache as $instanceid => $instance)
			{
				// Table data
				$cell = array();
				$cell[] = $instance['varname'];
				$cell[] = $instance['name'];
				//$cell[] = $instance['description'];
				$cell[] = "<input type=\"hidden\" name=\"instance[$instanceid][active]\" value=\"0\" /><input type=\"checkbox\" class=\"bginput\" name=\"instance[$instanceid][active]\" value=\"1\"" . ($instance['active'] ? ' checked="checked"' : '') . " tabindex=\"1\" title=\"" . DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_active') . "\" />";
				$cell[] = "<input type=\"text\" class=\"bginput\" name=\"instances[$instanceid][displayorder]\" value=\"$instance[displayorder]\" tabindex=\"1\" size=\"3\" title=\"" . DBTech_Shout_Core_Admin::phrase('edit_display_order') . "\" />";
				//$cell[] = $instance['sticky'];
				$cell[] = $displays[$instance['autodisplay']];
				$cell[] = construct_link_code(DBTech_Shout_Core_Admin::phrase('edit'), 'vbshout.php?do=instance&action=modify&instanceid=' . $instanceid);
				$cell[] = ($instanceid != 1 ? construct_link_code(DBTech_Shout_Core_Admin::phrase('delete'), 'vbshout.php?do=instance&action=delete&instanceid=' . $instanceid) : '[N/A]');

				// Print the data
				print_cells_row($cell, false, false, -5, 'middle', false, true);
			}
			print_cells_row(false);
			print_submit_row(DBTech_Shout_Core_Admin::phrase('save'), false, count($headings), false, construct_button_code(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance'), DBTech_Shout_Core_Admin::link('vbshout.php?do=instance&action=modify')));
		}
		else
		{
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'modify');
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance_management'), count($headings));
			print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_no_instances'), false, count($headings));
			print_submit_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance'), false, count($headings));
		}
	}

	public static function actionModify()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'instanceid' => TYPE_UINT,
		));

		$instanceid = $cleanedInput['instanceid'];
		$instance = ($instanceid ? $instanceCache["$instanceid"] : false);

		if (!is_array($instance))
		{
			// Non-existing instance
			$instanceid = 0;
		}

		$permissions = array();
		$bbcodepermissions = array();

		foreach (DBTech_Shout_Core_Admin::$usergroupcache as $usergroupid => $usergroup)
		{
			$bit = 10300;
			$bit2 = 67;
			if (DBTech_Shout_Core_Admin::getSystem() == 'vBulletin')
			{
				if ($usergroup['adminpermissions'] & $vbulletin->bf_ugp_adminpermissions['cancontrolpanel'])
				{
					// Admin
					$bit = 61436;
				}
				else if ($usergroup['adminpermissions'] & $vbulletin->bf_ugp_adminpermissions['ismoderator'])
				{
					// SMod
					$bit = 61436;
				}
				else if ($usergroupid == 5)
				{
					$bit = 61308;
				}
				else if (!($usergroup['genericoptions'] & $vbulletin->bf_ugp_genericoptions['isnotbannedgroup']) OR in_array($usergroupid, array(1, 3, 4)))
				{
					// Banned, guest, email conf, COPPA
					$bit 	= 0;
					$bit2 	= 0;
				}
			}

			$permissions[$usergroupid] 			= $bit;
			$bbcodepermissions[$usergroupid] 	= $bit2;
		}

		$defaults = array(
			'varname' 			=> 'shoutbox',
			'name' 				=> 'Shoutbox',
			'description' 		=> 'A shoutbox instance.',
			'active' 			=> 1,
			'displayorder' 		=> 10,
			'sticky_raw' 		=> 'The default sticky note.',
			'autodisplay'		=> 1,
			'permissions'		=> $permissions,
			'bbcodepermissions'	=> $bbcodepermissions,
			'options'			=> array(),
		);

		$displays = array(
			0 => DBTech_Shout_Core_Admin::phrase('disabled'),
			1 => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_after_navbar'),
			2 => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_above_footer'),
		);

		$hasSuhosin = false;
		/*
		if (extension_loaded('suhosin') AND (ini_get('suhosin.post.max_vars') > 0) AND (ini_get('suhosin.post.max_vars') < 2048))
		{
			$hasSuhosin = '
				You appear to have <strong>Suhosin</strong> installed on your server and configured to be too restrictive for DragonByte Shout to work correctly.<br />
				<br />
				Please note that if you have a large number of usergroups, certain parts of this page may not work as intended.<br />
				<br />
				If you encounter this issue, you can work around this by adding the following code to your .htaccess file:<br />
				<br />
	<pre>php_flag suhosin.cookie.encrypt Off
	php_value suhosin.request.max_vars 2048
	php_value suhosin.get.max_vars 2048
	php_value suhosin.post.max_vars 2048</pre>
				<br />
				These are the values vBulletin Support Staff suggest.';
		}
		if (version_compare(PHP_VERSION, '5.3.9') >= 0 AND ini_get('max_input_vars') < 10000)
		{
			$hasSuhosin = '
				You appear to have <strong>PHP 5.3.9</strong> or higher installed on your server and configured to be too restrictive for DragonByte Shout to work correctly.<br />
				<br />
				Please note that if you have a large number of usergroups, certain parts of this page may not work as intended.<br />
				<br />
				If you encounter this issue, you may be able to work around this by adding the following code to your .htaccess file:<br />
				<br />
	<pre>php_value max_input_vars 10000</pre>
				<br />
				or altering your php.ini file to increase max_input_vars to 10000.';
		}
		*/

		if ($instanceid)
		{
			// Edit
			print_cp_header(strip_tags(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_editing_x_y', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), 'param2' => $instance['name']))));
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'update');
			construct_hidden_code('instanceid', $instanceid);
			if ($hasSuhosin)
			{
				print_table_start();
				print_description_row($hasSuhosin);
				print_table_break();
			}
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_editing_x_y', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), 'param2' => $instance['name'])));
		}
		else
		{
			// Add
			print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance'));
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'update');
			if ($hasSuhosin)
			{
				print_table_start();
				print_description_row($hasSuhosin);
				print_table_break();
			}
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance'));

			$instance = $defaults;

			// Ensure we always have the default options
			DBTech_Shout_Shoutbox::loadDefaultInstanceOptions($instance);
		}

		print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_main_settings'), false, 2, 'optiontitle');
		if ($instanceid)
		{
			print_label_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_varname'), 																										$instance['varname']);
		}
		else
		{
			print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_varname'), 					'instance[varname]', 																$instance['varname']);
		}
		print_input_row(DBTech_Shout_Core_Admin::phrase('title'), 										'instance[name]', 																	$instance['name']);
		print_textarea_row(DBTech_Shout_Core_Admin::phrase('description'),								'instance[description]',															$instance['description']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_active'),						'instance[active]',																	$instance['active']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('display_order'),								'instance[displayorder]',															$instance['displayorder']);
		print_textarea_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_sticky'),					'instance[sticky_raw]',																$instance['sticky_raw']);
		print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_display_settings'), false, 2, 'optiontitle');
		print_select_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_auto_display_descr'),			'instance[autodisplay]', 					$displays, 								$instance['autodisplay']);
		print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_sound_settings'), false, 2, 'optiontitle');
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_enable_shout_sound'),			'instance[options][enableshoutsound]', 												$instance['options']['enableshoutsound']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_enable_invite_sound'),			'instance[options][enableinvitesound]', 											$instance['options']['enableinvitesound']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_enable_pm_sound'),				'instance[options][enablepmsound]', 												$instance['options']['enablepmsound']);
		print_description_row(DBTech_Shout_Core_Admin::phrase('options'), false, 2, 'optiontitle');
		print_bitfield_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_logging_descr'), 			'instance[options][logging]', 				self::$bitfields['logging'], 			$instance['options']['logging']);
		print_bitfield_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_editors_descr'), 			'instance[options][editors]', 				self::$bitfields['editors'], 			$instance['options']['editors']);
		print_bitfield_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_notices_descr'), 			'instance[options][notices]', 				self::$bitfields['notices'], 			$instance['options']['notices']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_optimisation_descr'), 			'instance[options][optimisation]', 													$instance['options']['optimisation']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_allowsmilies_descr'), 			'instance[options][allowsmilies]', 													$instance['options']['allowsmilies']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_activeusers_descr'), 			'instance[options][activeusers]', 													$instance['options']['activeusers']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_sounds_descr'), 				'instance[options][sounds]', 														$instance['options']['sounds']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_altshouts_descr'), 			'instance[options][altshouts]', 													$instance['options']['altshouts']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_enableaccess_descr'), 			'instance[options][enableaccess]', 													$instance['options']['enableaccess']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_anonymise_descr'), 			'instance[options][anonymise]', 													$instance['options']['anonymise']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_allcaps_descr'), 				'instance[options][allcaps]', 														$instance['options']['allcaps']);
		print_yes_no_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_invis_descr'), 				'instance[options][invis]', 														$instance['options']['invis']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_maxshouts_descr'), 				'instance[options][maxshouts]', 													$instance['options']['maxshouts']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_maxarchiveshouts_descr'), 		'instance[options][maxarchiveshouts]', 												$instance['options']['maxarchiveshouts']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_height_descr'), 				'instance[options][height]', 														$instance['options']['height']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_floodchecktime_descr'), 		'instance[options][floodchecktime]', 												$instance['options']['floodchecktime']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_maxchars_descr'), 				'instance[options][maxchars]', 														$instance['options']['maxchars']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_maximages_descr'), 				'instance[options][maximages]', 													$instance['options']['maximages']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_idletimeout_descr'), 			'instance[options][idletimeout]', 													$instance['options']['idletimeout']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_refresh_descr'), 				'instance[options][refresh]', 														$instance['options']['refresh']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_maxchats_descr'), 				'instance[options][maxchats]', 														$instance['options']['maxchats']);
		print_select_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_shoutarea_descr'),				'instance[options][shoutarea]', 			array(
																											'above' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_above_shouts'),
																											'below' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_below_shouts'),
																										),																					$instance['options']['shoutarea']);
		print_select_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_shoutorder_descr'),			'instance[options][shoutorder]', 			array(
																											'DESC' 	=> DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_newest_first'),
																											'ASC' 	=> DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_oldest_first')
																										),																					$instance['options']['shoutorder']);
		print_select_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_maxsize_descr'),				'instance[options][maxsize]', 				array(
																											3 => 3,
																											4 => 4,
																											5 => 5,
																											6 => 6,
																											7 => 7
																										),																					$instance['options']['maxsize']);
		print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_forum_milestones'), false, 2, 'optiontitle');
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_postping_interval_descr'), 		'instance[options][postping_interval]', 											$instance['options']['postping_interval']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_threadping_interval_descr'), 	'instance[options][threadping_interval]', 											$instance['options']['threadping_interval']);
		print_input_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_memberping_interval_descr'), 	'instance[options][memberping_interval]', 											$instance['options']['memberping_interval']);

		

		if ($hasSuhosin)
		{
			print_submit_row(($instanceid ? DBTech_Shout_Core_Admin::phrase('save') : DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance')), false, count($headings));
		}
		else
		{
			print_table_break();
		}

		if ($instanceid OR !$hasSuhosin)
		{
			// Bitfields
			$permissions = DBTech_Shout_Core_Admin::fetchBitfield('nocache|dbtech_vbshoutpermissions');

			// Table header
			$headings = array();
			$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_usergroup');
			foreach ((array)$permissions as $permissionname => $bit)
			{
				$headings[] = DBTech_Shout_Core_Admin::phrase("dbtech_vbshout_permission_{$permissionname}");
			}

			if ($hasSuhosin)
			{
				print_form_header('vbshout', 'instance');
				construct_hidden_code('action', 'updateinstancepermissions');
				construct_hidden_code('instanceid', $instanceid);
			}
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance_permissions'), count($headings));
			print_cells_row($headings, true);

			foreach (DBTech_Shout_Core_Admin::$usergroupcache as $usergroupid => $usergroup)
			{
				// Table data
				$cell = array();
				$cell[] = $usergroup['title'];
				foreach ((array)$permissions as $permissionname => $bit)
				{
					$cell[] = '<center>
						<input type="hidden" name="permissions[' . $usergroupid . '][' . $permissionname . ']" value="0" />
						<input type="checkbox" name="permissions[' . $usergroupid . '][' . $permissionname . ']" value="1"' . ($instance['permissions']["$usergroupid"] & $bit ? ' checked="checked"' : '') . ' title="name=&quot;permissions[' . $usergroupid . '][' . $permissionname . ']&quot;"' . '/>
					</center>';
				}

				// Print the data
				print_cells_row($cell, false, false, -5, 'middle', false, true);
			}
			print_cells_row(false);
			if ($hasSuhosin)
			{
				print_submit_row(($instanceid ? DBTech_Shout_Core_Admin::phrase('save') : DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance')), false, count($headings));
			}
			else
			{
				print_table_break();
			}

			if (DBTech_Shout_Core_Admin::getSystem() == 'vBulletin')
			{
				// Bitfields
				$permissions = DBTech_Shout_Core_Admin::fetchBitfield('nocache|allowedbbcodesfull');

				// Table header
				$headings = array();
				$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_usergroup');
				foreach ((array)$permissions as $permissionname => $bit)
				{
					$headings[] = DBTech_Shout_Core_Admin::phrase("{$permissionname}");
				}

				if ($hasSuhosin)
				{
					print_form_header('vbshout', 'instance');
					construct_hidden_code('action', 'updatebbcodepermissions');
					construct_hidden_code('instanceid', $instanceid);
				}
				print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_bbcode_permissions'), count($headings));
				print_cells_row($headings, true);

				foreach (DBTech_Shout_Core_Admin::$usergroupcache as $usergroupid => $usergroup)
				{
					// Table data
					$cell = array();
					$cell[] = $usergroup['title'];
					foreach ((array)$permissions as $permissionname => $bit)
					{
						$cell[] = '<center>
							<input type="hidden" name="bbcodepermissions[' . $usergroupid . '][' . $permissionname . ']" value="0" />
							<input type="checkbox" name="bbcodepermissions[' . $usergroupid . '][' . $permissionname . ']" value="1"' . ($instance['bbcodepermissions']["$usergroupid"] & $bit ? ' checked="checked"' : '') . ' title="name=&quot;bbcodepermissions[' . $usergroupid . '][' . $permissionname . ']&quot;"' . '/>
						</center>';
					}

					// Print the data
					print_cells_row($cell, false, false, -5, 'middle', false, true);
				}
				print_cells_row(false);
				if ($hasSuhosin)
				{
					print_submit_row(($instanceid ? DBTech_Shout_Core_Admin::phrase('save') : DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance')), false, count($headings));
				}
				else
				{
					print_table_break();
				}
			}
		}

		if (!$hasSuhosin)
		{
			print_submit_row(($instanceid ? DBTech_Shout_Core_Admin::phrase('save') : DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance')), false);
		}
	}

	public static function actionUpdate()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'instanceid' 		=> TYPE_UINT,
			'instance' 			=> TYPE_ARRAY,
			'permissions' 		=> TYPE_ARRAY,
			'bbcodepermissions' => TYPE_ARRAY,
		));

		// Protect admins from themselves
		$cleanedInput['instance']['options']['shoutping_interval'] = $cleanedInput['instance']['options']['shoutping_interval'] == 1 ? 2 : $cleanedInput['instance']['options']['shoutping_interval'];

		// Store raw sticky
		$sticky_raw = $cleanedInput['instance']['sticky'] = $cleanedInput['instance']['sticky_raw'];

		if (DBTech_Shout_Core_Admin::getSystem() == 'vBulletin')
		{
			// Ensure we got BBCode Parser
			require_once(DIR . '/includes/class_bbcode.php');
			if (!function_exists('convert_url_to_bbcode'))
			{
				require_once(DIR . '/includes/functions_newpost.php');
			}


			// Initialise the parser (use proper BBCode)
			$parser = new vB_BbCodeParser($vbulletin, fetch_tag_list());

			// BBCode parsing
			$cleanedInput['instance']['sticky'] = $parser->parse(convert_url_to_bbcode($cleanedInput['instance']['sticky_raw']), 'nonforum');
			unset($parser);
		}
		else
		{
			// @TODO:
		}

		foreach (self::$bitfields as $key => $fieldname)
		{
			$bit = 0;

			if (isset($cleanedInput['instance']['options'][$key]) AND is_array($cleanedInput['instance']['options'][$key]))
			{
				foreach ($cleanedInput['instance']['options'][$key] as $value)
				{
					// Update the options array
					$bit += $value;
				}
			}

			$cleanedInput['instance']['options'][$key] = $bit;
		}

		$bitfields = DBTech_Shout_Core_Admin::fetchBitfield('nocache|dbtech_vbshoutpermissions');
		if (DBTech_Shout_Core_Admin::getSystem() == 'vBulletin')
		{
			$bitfields2 = DBTech_Shout_Core_Admin::fetchBitfield('nocache|allowedbbcodesfull');

			if (count($cleanedInput['bbcodepermissions']))
			{
				$permarray = array();
				foreach ($cleanedInput['bbcodepermissions'] as $usergroupid => $permvalues)
				{
					$permarray[$usergroupid] = 0;
					foreach ($permvalues as $bitfield => $bit)
					{
						// Update the permissions array
						$permarray[$usergroupid] += ($bit ? $bitfields2[$bitfield] : 0);
					}
				}

				// Set the perm array
				$cleanedInput['instance']['bbcodepermissions'] = $permarray;
			}
		}

		if (count($cleanedInput['permissions']))
		{
			$permarray = array();
			foreach ($cleanedInput['permissions'] as $usergroupid => $permvalues)
			{
				$permarray[$usergroupid] = 0;
				foreach ($permvalues as $bitfield => $bit)
				{
					// Update the permissions array
					$permarray[$usergroupid] += ($bit ? $bitfields[$bitfield] : 0);
				}
			}

			// Set the perm array
			$cleanedInput['instance']['permissions'] = $permarray;
		}

		// init data manager
		$instanceDm = new DBTech_Shout_DataManager_Instance(DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['instanceid'])
		{
			if (!$existing = $instanceCache[$cleanedInput['instanceid']])
			{
				// Couldn't find the instance
				print_stop_message('dbtech_vbshout_invalid_x', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
			}

			// Set existing
			$instanceDm->setExistingData($existing);

			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$instanceDm->bulkSet($cleanedInput['instance']);

		// Save! Hopefully.
		$instanceDm->save();

		define('CP_REDIRECT', 'vbshout.php?do=instance');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), $phrase);
	}

	public static function actionMassupdate()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'instance' => TYPE_ARRAY
		));

		foreach ($cleanedInput['instance'] as $instanceid => $instance)
		{
			if (!$existing = $instanceCache[$instanceid])
			{
				// Couldn't find the instance
				continue;
			}

			// init data manager
			$instanceDm = new DBTech_Shout_DataManager_Instance(DBTech_Shout_DataManager::ERROR_EXCEPTION);
				$instanceDm->setExistingData($existing);
				$instanceDm->bulkSet($instance);
			$instanceDm->save();
			unset($instanceDm);
		}

		define('CP_REDIRECT', 'vbshout.php?do=instance');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited'));
	}

	public static function actionDelete()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'instanceid' => TYPE_UINT,
		));

		print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_delete_x', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'))));
		print_delete_confirmation('dbtech_vbshout_instance', $cleanedInput['instanceid'], 'vbshout', 'instance', 'dbtech_vbshout_instance', array('action' => 'kill'), '', 'name');
		print_cp_footer();
	}

	public static function actionKill()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'instanceid' => TYPE_UINT,
			'kill' 		 => TYPE_BOOL
		));

		if (!$existing = $instanceCache[$cleanedInput['instanceid']])
		{
			// Couldn't find the instance
			print_stop_message('dbtech_vbshout_invalid_x', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
		}

		// init data manager
		$instanceDm = new DBTech_Shout_DataManager_Instance(DBTech_Shout_DataManager::ERROR_EXCEPTION);
			$instanceDm->setExistingData($existing);
		$instanceDm->delete();

		define('CP_REDIRECT', 'vbshout.php?do=instance');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_deleted'));
	}

	public static function actionUpdateinstancepermissions()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'instanceid'		=> TYPE_UINT,
			'permissions' 		=> TYPE_ARRAY,
		));

		$bitfields = DBTech_Shout_Core_Admin::fetchBitfield('nocache|dbtech_vbshoutpermissions');

		$permarray = array();
		foreach ((array)$cleanedInput['permissions'] as $usergroupid => $permvalues)
		{

			$permarray["$usergroupid"] = 0;
			foreach ((array)$permvalues as $bitfield => $bit)
			{
				// Update the permissions array
				$permarray["$usergroupid"] += ($bit ? $bitfields["$bitfield"] : 0);
			}
		}

		// Set the perm array
		$cleanedInput['instance']['permissions'] = $permarray;

		// init data manager
		$instanceDm = new DBTech_Shout_DataManager_Instance(DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['instanceid'])
		{
			if (!$existing = $instanceCache["{$cleanedInput[instanceid]}"])
			{
				// Couldn't find the instance
				print_stop_message('dbtech_vbshout_invalid_x', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
			}

			// Set existing
			$instanceDm->setExistingData($existing);

			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$instanceDm->bulkSet($cleanedInput['instance']);

		// Save! Hopefully.
		$instanceDm->save();

		define('CP_REDIRECT', 'vbshout.php?do=instance');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited'));
	}

	public static function actionUpdatebbcodepermissions()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'instanceid'		=> TYPE_UINT,
			'bbcodepermissions' => TYPE_ARRAY,
		));

		// Ensure we can fetch bitfields
		$bitfields = DBTech_Shout_Core_Admin::fetchBitfield('nocache|allowedbbcodesfull');

		$permarray = array();
		foreach ((array)$cleanedInput['bbcodepermissions'] as $usergroupid => $permvalues)
		{
			$permarray["$usergroupid"] = 0;
			foreach ((array)$permvalues as $bitfield => $bit)
			{
				// Update the permissions array
				$permarray["$usergroupid"] += ($bit ? $bitfields["$bitfield"] : 0);
			}
		}

		// Set the perm array
		$cleanedInput['instance']['bbcodepermissions'] = $permarray;

		// init data manager
		$instanceDm = new DBTech_Shout_DataManager_Instance(DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['instanceid'])
		{
			if (!$existing = $instanceCache[$cleanedInput['instanceid']])
			{
				// Couldn't find the instance
				print_stop_message('dbtech_vbshout_invalid_x', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
			}

			// Set existing
			$instanceDm->setExistingData($existing);

			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$instanceDm->bulkSet($cleanedInput['instance']);

		// Save! Hopefully.
		$instanceDm->save();

		define('CP_REDIRECT', 'vbshout.php?do=instance');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'), DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited'));
	}

	public static function actionPermissions()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$permissions = DBTech_Shout_Core_Admin::fetchBitfield('nocache|dbtech_vbshoutpermissions');

		print_cp_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance_permissions'));

		// Table header
		$headings = array();
		$headings[] = DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_usergroup');
		foreach ((array)$permissions as $permissionname => $bit)
		{
			$headings[] = DBTech_Shout_Core_Admin::phrase("dbtech_vbshout_permission_{$permissionname}");
		}
		$headings[] = DBTech_Shout_Core_Admin::phrase('edit');

		if (count($instanceCache))
		{
			print_table_start();
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance_permissions'), count($headings));
			print_cells_row($headings, true);

			foreach ($instanceCache as $instanceid => $instance)
			{
				print_description_row($instance['name'] . ' - ' . $instance['description'], false, count($headings), 'optiontitle');

				foreach (DBTech_Shout_Core_Admin::$usergroupcache as $usergroupid => $usergroup)
				{
					// Table data
					$cell = array();
					$cell[] = $usergroup['title'];
					foreach ((array)$permissions as $permissionname => $bit)
					{
						$cell[] = ($instance['permissions']["$usergroupid"] & $bit ? DBTech_Shout_Core_Admin::phrase('yes') : '<span class="col-i"><strong>' . DBTech_Shout_Core_Admin::phrase('no') . '</strong></span>');
					}
					$cell[] = construct_link_code(DBTech_Shout_Core_Admin::phrase('edit'), 'vbshout.php?do=instance&action=modify&instanceid=' . $instanceid);

					// Print the data
					print_cells_row($cell, false, false, -5, 'middle', false, true);
				}
			}
			print_cells_row(false);
			print_table_footer();
		}
		else
		{
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'modify');
			print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance_management'), count($headings));
			print_description_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_no_instances'), false, count($headings));
			print_submit_row(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_add_new_instance'), false, count($headings));
		}
	}

	
}
?>