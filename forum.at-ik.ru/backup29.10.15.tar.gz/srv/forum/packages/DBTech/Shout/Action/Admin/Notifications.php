<?php
class DBTech_Shout_Action_Admin_Notifications extends DBTech_Shout_Action_Admin_Abstract
{
	public static function actionIndex()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$forumids = array();
		foreach ((array)DBTech_Shout_Core_Admin::$forumcache as $forumid => $forum)
		{
			/*DBTECH_LITE_START
			switch (DBTech_Shout_Core_Admin::getSystem())
			{
				case 'XenForo':
					if ($forum['depth'] != 0)
					{
						// This forum isn't a parent forum
						continue;
					}
					break;

				case 'vBulletin':
					if ($forum['parentid'] != -1)
					{
						// This forum isn't a parent forum
						continue;
					}
					break;
			}
			DBTECH_LITE_END*/

			$forumids[] = $forumid;
		}


		$headings = array();
		$headings[] = DBTech_Shout_Core_Admin::phrase('forum');
		foreach ($instanceCache as $instanceid => $instance)
		{
			$headings[] = $instance['name'];
		}

		print_cp_header(strip_tags(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_editing_x_y', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_notifications'), 'param2' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance')))));
		print_form_header('vbshout', 'notifications');
		construct_hidden_code('action', 'update');
		print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_editing_x_y', array('param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_notifications'), 'param2' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_instance'))), count($headings));
		print_cells_row($headings, true);

		foreach ($forumids as $forumid)
		{
			// Shorthand
			$forum = DBTech_Shout_Core_Admin::$forumcache[$forumid];
			$cell = array();
			$cell[] = construct_depth_mark($forum['depth'],'- - ') . $forum['title'];
			foreach ($instanceCache as $instanceid => $instance)
			{
				$cell[] = '
					<center>
						<input type="hidden" name="forum[' . $instanceid . '][' . $forumid . '][newthread]" value="0" />
						<label for="cb_forum_' . $instanceid . '_' . $forumid . '_newthread">
							<input type="checkbox" name="forum[' . $instanceid . '][' . $forumid . '][newthread]" id="cb_forum_' . $instanceid . '_' . $forumid . '_newthread" value="1"' . ((isset($instance['notices'][$forumid]) AND ($instance['notices'][$forumid] & 1)) ? ' checked="checked"' : '') . '/>
							' . DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_new_thread') . '
						</label>

						<input type="hidden" name="forum[' . $instanceid . '][' . $forumid . '][newreply]" value="0" />
						<label for="cb_forum_' . $instanceid . '_' . $forumid . '_newreply">
							<input type="checkbox" name="forum[' . $instanceid . '][' . $forumid . '][newreply]" id="cb_forum_' . $instanceid . '_' . $forumid . '_newreply" value="2"' . ((isset($instance['notices'][$forumid]) AND ($instance['notices'][$forumid] & 2)) ? ' checked="checked"' : '') . '/>
							' . DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_new_reply') . '
						</label>
					</center>
				';
			}
			print_cells_row($cell, false, false, -5, 'middle', false, true);
		}
		print_cells_row(false);
		print_submit_row(DBTech_Shout_Core_Admin::phrase('save'), false, count($headings));
	}

	public static function actionUpdate()
	{
		// Grab stuff
		$cleanedInput = DBTech_Shout_Core_Admin::filter(array(
			'forum' 	=> TYPE_ARRAY,
		));

		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		foreach ($cleanedInput['forum'] as $instanceid => $forum)
		{
			if (!$existing = $instanceCache[$instanceid])
			{
				// Invalid isntance
				continue;
			}

			$SQL = array();
			foreach ($forum as $forumid => $config)
			{
				if (!isset($SQL[$forumid]))
				{
					// Ensure this is set
					$SQL[$forumid] = 0;
				}

				foreach ($config as $val)
				{
					// Notice flag
					$SQL[$forumid] += $val;
				}
			}

			// init data manager
			$instanceDm = new DBTech_Shout_DataManager_Instance(DBTech_Shout_DataManager::ERROR_EXCEPTION);
				$instanceDm->setExistingData($existing);
				$instanceDm->set('notices', $SQL);
			$instanceDm->save();
			unset($instanceDm);
		}

		define('CP_REDIRECT', 'vbshout.php?do=notifications');
		print_stop_message('dbtech_vbshout_x_y', DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_notifications'), DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_edited'));
	}
}
?>