<?php
class DBTech_Shout_Action_Admin_Options extends DBTech_Shout_Action_Admin_Abstract
{
	public static function actionIndex() {}

	public static function actionUpdate() {}
}
?>