<?php
class DBTech_Shout_Action_Admin_Repaircache extends DBTech_Shout_Action_Admin_Abstract
{
	public static function actionIndex()
	{
		DBTech_Shout_Cache::buildAll();

		DBTech_Shout_Core_Admin::redirect(
			DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_x_y', array(
				'param1' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_cache'),
				'param2' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_rebuilt')
			)),
			'vbshout.php?do=instance'
		);
	}
}
?>