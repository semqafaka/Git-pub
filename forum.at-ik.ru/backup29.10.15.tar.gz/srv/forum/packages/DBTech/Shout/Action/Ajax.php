<?php
class DBTech_Shout_Action_Ajax extends DBTech_Shout_Action_Abstract
{
	public static function actionIndex()
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');

		// Fetch the list of users
		$cleanedInput = DBTech_Shout_Core::filter(array(
			'instanceid' 	=> TYPE_UINT,
			'chatroomid' 	=> TYPE_UINT,
			'detached' 		=> TYPE_BOOL,
			'shoutid' 		=> TYPE_UINT,
			'type' 			=> TYPE_NOHTML
		));

		if (!$instance = $instanceCache[$cleanedInput['instanceid']])
		{
			// Wrong instance
			DBTech_Shout_Shoutbox::$fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			self::outputXML(DBTech_Shout_Shoutbox::$fetched);
		}

		if (!$instance['active'])
		{
			// Inactive instance
			DBTech_Shout_Shoutbox::$fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			self::outputXML(DBTech_Shout_Shoutbox::$fetched);
		}

		if (isset(DBTech_Shout_Core::$userinfo['dbtech_vbshout_banned']) AND DBTech_Shout_Core::$userinfo['dbtech_vbshout_banned'])
		{
			// Banz!
			DBTech_Shout_Shoutbox::$fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			self::outputXML(DBTech_Shout_Shoutbox::$fetched);
		}

		if (!$instance['permissions_parsed']['canviewshoutbox'])
		{
			// Can't view this instance
			DBTech_Shout_Shoutbox::$fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			self::outputXML(DBTech_Shout_Shoutbox::$fetched);
		}

		if ((int)DBTech_Shout_Core::$userinfo[DBTech_Shout_Core::$db->lookup('user', 'posts')] < $instance['options']['minposts'] AND !DBTech_Shout_Core::usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
		{
			// Too few posts
			DBTech_Shout_Shoutbox::$fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			self::outputXML(DBTech_Shout_Shoutbox::$fetched);
		}

		// Do posts per day
		$jointime = (DBTech_Shout_Core::getTime() - DBTech_Shout_Core::$userinfo[DBTech_Shout_Core::$db->lookup('user', 'joindate')]) / 86400;
		$postsperday = ($jointime <= 1 ? DBTech_Shout_Core::$userinfo[DBTech_Shout_Core::$db->lookup('user', 'posts')] : round(DBTech_Shout_Core::$userinfo[DBTech_Shout_Core::$db->lookup('user', 'posts')] / $jointime, 2));

		if ((int)$postsperday < $instance['options']['minpostsperday'] AND !DBTech_Shout_Core::usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
		{
			// Too few posts
			DBTech_Shout_Shoutbox::$fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			self::outputXML(DBTech_Shout_Shoutbox::$fetched);
		}

		// Set this
		$class = get_called_class();
		$tmp = explode('_', $class);

		// Strip non-valid characters
		$do = preg_replace('/[^\w-]/i', '', array_pop($tmp));

		// Any additional arguments we may be having to the fetching of shouts
		$args['instanceid'] = $cleanedInput['instanceid'];

		// Fetch the list of users
		if ($cleanedInput['chatroomid'])
		{
			// Check if the chatroom is active
			$chatroom = $chatroomCache[$cleanedInput['chatroomid']];

			if ($do != 'joinchat')
			{
				if (!$chatroom OR !$chatroom['active'])
				{
					// Wrong chatroom
					DBTech_Shout_Shoutbox::$fetched['error'] = 'disband_' . $cleanedInput['chatroomid'];
				}

				if (!$chatroom['membergroupids'])
				{
					// This is not a members-only group
					if (!isset($chatroom['members'][DBTech_Shout_Core::$userinfo[DBTech_Shout_Core::$db->lookup('user', 'userid')]]))
					{
						// We're not a member
						DBTech_Shout_Shoutbox::$fetched['error'] = 'disband_' . $cleanedInput['chatroomid'];
					}
				}
				else
				{
					if ($chatroom['membergroupids'] != '-1' AND !DBTech_Shout_Core::isMemberOf(DBTech_Shout_Core::$userinfo, explode(',', $chatroom['membergroupids'])))
					{
						// Usergroup no longer a member
						DBTech_Shout_Shoutbox::$fetched['error'] = 'disband_' . $cleanedInput['chatroomid'];
					}
				}
			}
		}
		else
		{
			// Default value
			$chatroom = array();
		}

		

		if (isset(DBTech_Shout_Shoutbox::$fetched['error']) AND DBTech_Shout_Shoutbox::$fetched['error'])
		{
			// We had errors, don't bother

			// Prints the XML for reading by the AJAX script
			self::outputXML(DBTech_Shout_Shoutbox::$fetched);
		}

		// Run the action
		$class::__handle($instance, $chatroom, $args);

		if (isset(DBTech_Shout_Shoutbox::$fetched['error']) AND !DBTech_Shout_Shoutbox::$fetched['error'])
		{
			// Bugfix
			unset(DBTech_Shout_Shoutbox::$fetched['error']);
		}

		// Prints the XML for reading by the AJAX script
		self::outputXML(DBTech_Shout_Shoutbox::$fetched);
	}

	/**
	* Outputs an XML string to the browser
	*
	* @param	mixed	array to output
	*/
	public static function outputXml($arr)
	{
		$document = new DOMDocument('1.0', 'utf-8');
		$document->formatOutput = true;

		$rootNode = $document->createElement('vbshout');

		foreach (array(
			'aoptimes',
			'chatrooms',
			'shouts',
		) as $key)
		{
			if (!isset(DBTech_Shout_Shoutbox::$fetched[$key]) OR !is_array(DBTech_Shout_Shoutbox::$fetched[$key]))
			{
				// Skip this
				continue;
			}

			// Array values
			$node = $document->createElement($key);
			foreach (DBTech_Shout_Shoutbox::$fetched[$key] as $key2 => $arr)
			{
				$node2 = $document->createElement(substr($key, 0, -1));
				foreach ($arr as $key3 => $val)
				{
					$node3 = $document->createElement($key3);
						$node3->appendChild($document->createCDATASection($val));
					$node2->appendChild($node3);
				}
				$node->appendChild($node2);
			}
			$rootNode->appendChild($node);
		}

		foreach (array(
			'ajax',
			'activereports',
			'content',
			'editor',
			'error',
			'menucode',
			'pmtime',
			'pmuserid',
			'sticky',
		) as $key)
		{
			if (!isset(DBTech_Shout_Shoutbox::$fetched[$key]))
			{
				continue;
			}

			// Singular values
			$node = $document->createElement($key);
				$node->appendChild($document->createCDATASection(DBTech_Shout_Shoutbox::$fetched[$key]));
			$rootNode->appendChild($node);
		}

		if (isset(DBTech_Shout_Shoutbox::$fetched['activeusers']['usernames']))
		{
			// Create the attribute
			$attribute = $document->createAttribute('count');
			$attribute->value = DBTech_Shout_Shoutbox::$fetched['activeusers']['count'];

			// Singular values
			$node = $document->createElement('activeusers');
				$node->appendChild($document->createCDATASection(DBTech_Shout_Shoutbox::$fetched['activeusers']['usernames']));
				$node->appendChild($attribute);
			$rootNode->appendChild($node);
		}

		if (isset(DBTech_Shout_Shoutbox::$fetched['chatroom']))
		{
			// Create the attribute
			$attribute = $document->createAttribute('chatroomid');
			$attribute->value = DBTech_Shout_Shoutbox::$fetched['chatroom']['chatroomid'];

			// Singular values
			$node = $document->createElement('chatroom');
				$node->appendChild($document->createCDATASection(DBTech_Shout_Shoutbox::$fetched['chatroom']['title']));
				$node->appendChild($attribute);
			$rootNode->appendChild($node);
		}

		$document->appendChild($rootNode);

		header("Content-Type: application/xml; charset=UTF-8");
		echo $document->saveXML();
		die();
	}
}