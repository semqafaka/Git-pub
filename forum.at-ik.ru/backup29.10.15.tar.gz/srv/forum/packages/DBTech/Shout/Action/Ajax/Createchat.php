<?php
class DBTech_Shout_Action_Ajax_Createchat extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 1))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		$cleanedInput = DBTech_Shout_Core::filter(array(
			'title' => TYPE_NOHTML
		));

		// Init the Shout DM
		$shoutDm = new DBTech_Shout_DataManager_Shout(DBTech_Shout_DataManager::ERROR_ARRAY);
			$shoutDm->setInfo('instance', $instance);
			$shoutDm->bulkSet(array(
				'instanceid' => $instance['instanceid'],
				'message' => '/createchat ' . $cleanedInput['title'],
			));
		$shoutDm->save();
	}
}