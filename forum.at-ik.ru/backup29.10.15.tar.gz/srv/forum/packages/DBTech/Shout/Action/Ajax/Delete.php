<?php
class DBTech_Shout_Action_Ajax_Delete extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 2))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		$cleanedInput = DBTech_Shout_Core::filter(array(
			'shoutid' 		=> TYPE_UINT,
		));

		if (!$cleanedInput['shoutid'])
		{
			// Invalid Shout ID
			return false;
		}

		if (!$existing = DBTech_Shout_Core::$db->fetchRow('
			SELECT *
			FROM $dbtech_vbshout_shout AS vbshout
			WHERE shoutid = ?
		', array(
			$cleanedInput['shoutid']
		)))
		{
			// Shout didn't exist
			return false;
		}

		// Init the Shout DM
		$shoutDm = new DBTech_Shout_DataManager_Shout(DBTech_Shout_DataManager::ERROR_ARRAY);
			$shoutDm->setInfo('instance', $instance);
			$shoutDm->setExistingData($existing);
		$shoutDm->delete();

		// Fetch the file in question
		DBTech_Shout_Action_Ajax_Fetch::__handle($instance, $chatroom, $args);

		
	}
}