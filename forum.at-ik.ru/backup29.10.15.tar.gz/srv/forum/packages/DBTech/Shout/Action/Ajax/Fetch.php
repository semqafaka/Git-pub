<?php
class DBTech_Shout_Action_Ajax_Fetch extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		$cleanedInput = DBTech_Shout_Core::filter(array(
			'tabs' 		=> TYPE_ARRAY,
			'pmtime' 	=> TYPE_UINT,
			'type' 		=> TYPE_STR,
			'shoutid' 	=> TYPE_UINT
		));

		// Grab this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');

		$chatRooms = DBTech_Shout_Core::$db->fetchAllSingleKeyed('
			SELECT chatroomid, user.username
			FROM $dbtech_vbshout_chatroommember AS chatroommember
			LEFT JOIN $user AS user ON(user.' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' = chatroommember.invitedby)
			WHERE chatroommember.userid = ?
				AND status = 0
		', 'chatroomid', 'username', array(
			DBTech_Shout_Core::$userinfo['userid']
		));
		foreach ($chatRooms as $chatRoomId => $username)
		{
			if (
				!$chatroomCache[$chatRoomId]['active']
				OR (
					$chatroomCache[$chatRoomId]['instanceid'] != $instance['instanceid']
					AND $chatroomCache[$chatRoomId]['instanceid'] != 0
				)
			)
			{
				// Inactive chat room
				continue;
			}

			// Store information regarding the chatroom
			DBTech_Shout_Shoutbox::$fetched['chatrooms'][] = array(
				'chatroomid' 	=> $chatRoomId,
				'instanceid' 	=> $chatroomCache[$chatRoomId]['instanceid'],
				'title' 		=> $chatroomCache[$chatRoomId]['title'],
				'username' 		=> ($username ? $username : 'N/A')
			);
		}

		foreach ($cleanedInput['tabs'] as $tabid => $enabled)
		{
			if ($tabid == 'activeusers')
			{
				// Shouldn't happen
				continue;
			}

			if (substr($tabid, 0, 8) == 'chatroom')
			{
				// Get the chatroom id
				$chatroomid = explode('_', $tabid);
				$chatroomid = $chatroomid[1];

				// Already set
				$instanceid = '';
			}
			else if (substr($tabid, 0, 2) == 'pm')
			{
				// Already set
				$instanceid = '';
			}
			else
			{
				// Just use the normal instance id
				$instanceid = $instance['instanceid'];
			}

			// File system
			$mtime = intval(@file_get_contents(DIR . '/dbtech/vbshout/aop/markread-' . $tabid . $instanceid . '.txt'));

			if ($mtime)
			{
				// Send back AOP times
				DBTech_Shout_Shoutbox::$fetched['aoptimes'][] = array(
					'aoptime' 	=> $mtime,
					'tabid' 	=> $tabid,
					'nosound' 	=> 0,
				);
			}
		}

		if (isset(DBTech_Shout_Core::$userinfo['dbtech_vbshout_pm']) AND DBTech_Shout_Core::$userinfo['dbtech_vbshout_pm'] > $cleanedInput['pmtime'])
		{
			// Set new PM time
			DBTech_Shout_Shoutbox::$fetched['pmtime'] = DBTech_Shout_Core::$userinfo['dbtech_vbshout_pm'];
		}

		if (substr($cleanedInput['type'], 0, 2) == 'pm')
		{
			// Fetch AOP time
			DBTech_Shout_Shoutbox::fetchAop($cleanedInput['type'], '');

			// Fetch the userid from the PM type
			$userid = explode('_', $cleanedInput['type']);
			$userid = $userid[1];

			// Set shout args to only include shouts made between self and result of substr
			//$args['userids'] 	= array(DBTech_Shout_Core::$userinfo['userid'], $userid);
			$args['types']		= DBTech_Shout_Shoutbox::$shouttypes['pm'];
			$args['onlyuser']	= $userid;

			// Override type
			$cleanedInput['type'] = 'shouts';
		}

		if (substr($cleanedInput['type'], 0, 8) == 'chatroom')
		{
			// Fetch the chatroomid from the chatroom type
			$chatroomid = explode('_', $cleanedInput['type']);
			$chatroomid = $chatroomid[1];

			// Set shout args to only include shouts posted to said chat room
			$args['chatroomid']	= $chatroomid;

			if (!$chatroom = $chatroomCache[$chatroomid])
			{
				// Wrong chatroom
				DBTech_Shout_Shoutbox::$fetched['error'] = 'disband_' . $chatroomid;
				return false;
			}
			else
			{
				if (!$chatroom['membergroupids'])
				{
					$userid = DBTech_Shout_Core::$userinfo['userid'];

					// This is not a members-only group
					if (!isset($chatroom['members'][$userid]))
					{
						DBTech_Shout_Shoutbox::$fetched['error'] = 'disband_' . $chatroomid;
						unset($args['chatroomid']);
						return false;
					}
				}
				else
				{
					if ($chatroom['membergroupids'] != '-1' AND !DBTech_Shout_Core::isMemberOf(DBTech_Shout_Core::$userinfo, explode(',', $chatroom['membergroupids'])) OR !$chatroom['active'])
					{
						// Usergroup no longer a member
						DBTech_Shout_Shoutbox::$fetched['error'] = 'disband_' . $chatroomid;
						unset($args['chatroomid']);
						return false;
					}
				}
			}

			// Fetch AOP time
			DBTech_Shout_Shoutbox::fetchAop('chatroom_' . $chatroomid . '_', $chatroom['instanceid']);

			$cleanedInput['type'] = 'shouts';
		}

		if ((
			!isset($instance['options']['shoutboxtabs']) OR ($instance['options']['shoutboxtabs'] & 4)) AND
			$instance['permissions_parsed']['canmodchat']
		)
		{
			DBTech_Shout_Shoutbox::$fetched['activereports'] = DBTech_Shout_Core::$db->fetchOne('
				SELECT COUNT(*) AS numunhandled
				FROM $dbtech_vbshout_report
				WHERE handled = 0
					AND instanceid = ?
			', array(
				$instance['instanceid']
			));
		}

		if ($cleanedInput['type'] == 'shoutnotifs')
		{
			// Fetch AOP time
			DBTech_Shout_Shoutbox::fetchAop($cleanedInput['type'], $instance['instanceid']);

			$args['types']		= DBTech_Shout_Shoutbox::$shouttypes['notif'];

			// Override type
			$cleanedInput['type'] = 'shouts';
		}

		if ($cleanedInput['type'] == 'systemmsgs')
		{
			// Fetch AOP time
			DBTech_Shout_Shoutbox::fetchAop($cleanedInput['type'], $instance['instanceid']);

			$args['types']		= DBTech_Shout_Shoutbox::$shouttypes['system'];

			// Override type
			$cleanedInput['type'] = 'shouts';
		}

		if ($cleanedInput['type'] == 'shouts' OR isset(DBTech_Shout_Shoutbox::$fetched['pmtime']))
		{
			// Fetch AOP time
			DBTech_Shout_Shoutbox::fetchAop('shouts', $instance['instanceid']);

			// Fetch shouts
			DBTech_Shout_Shoutbox::fetchShouts($instance, $chatroom, $args);
		}

		if ($cleanedInput['type'] == 'shout')
		{
			// What shout we want to be editing
			if (!$existing = DBTech_Shout_Core::$db->fetchRow('
				SELECT *
				FROM $dbtech_vbshout_shout AS vbshout
				WHERE shoutid = ?
			', array(
				$cleanedInput['shoutid']
			)))
			{
				// Shout didn't exist
				DBTech_Shout_Shoutbox::$fetched['error'] = DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_shout');
				return false;
			}

			if ($exists['userid'] == DBTech_Shout_Core::$userinfo['userid'] AND !$instance['permissions_parsed']['caneditown'])
			{
				// We can't edit our own shouts
				DBTech_Shout_Shoutbox::$fetched['error'] = DBTech_Shout_Core::phrase('dbtech_vbshout_may_not_edit_own');
				return false;
			}

			if ($exists['userid'] != DBTech_Shout_Core::$userinfo['userid'] AND !$instance['permissions_parsed']['caneditothers'])
			{
				// We don't have permission to edit others' shouts
				DBTech_Shout_Shoutbox::$fetched['error'] = DBTech_Shout_Core::phrase('dbtech_vbshout_may_not_edit_others');
				return false;
			}

			// Set the editor content
			DBTech_Shout_Shoutbox::$fetched['editor'] = $exists['message'];
		}

		if ($cleanedInput['type'] == 'activeusers')
		{
			// Array of all active users
			DBTech_Shout_Shoutbox::fetchActiveUsers($instance, $chatroom, true);

			// Finally set the content
			DBTech_Shout_Shoutbox::$fetched['content'] = DBTech_Shout_Shoutbox::$fetched['activeusers']['usernames'] = (count(DBTech_Shout_Shoutbox::$activeusers) ? implode(', ', DBTech_Shout_Shoutbox::$activeusers) : DBTech_Shout_Core::phrase('dbtech_vbshout_no_active_users'));

			// Query for active users
			DBTech_Shout_Shoutbox::$fetched['activeusers']['count'] = count(DBTech_Shout_Shoutbox::$activeusers);
		}
	}
}