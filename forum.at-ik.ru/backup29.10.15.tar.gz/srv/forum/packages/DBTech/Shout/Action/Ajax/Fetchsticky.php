<?php
class DBTech_Shout_Action_Ajax_Fetchsticky extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 4))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		// Fetch sticky
		DBTech_Shout_Shoutbox::$fetched['editor'] = '/sticky ' . $instance['sticky_raw'];
	}
}