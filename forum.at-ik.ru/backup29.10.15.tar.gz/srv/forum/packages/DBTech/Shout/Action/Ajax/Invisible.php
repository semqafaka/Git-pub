<?php
class DBTech_Shout_Action_Ajax_Invisible extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if ($instance['options']['invis'] OR !$instance['permissions_parsed']['caninvisible'])
		{
			// Git oot
			return false;
		}

		if (!($instance['options']['activitytriggers'] & 2048))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		$cleanedInput = DBTech_Shout_Core::filter(array(
			'invisibility' => TYPE_BOOL,
		));

		DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings'] =
			is_array(DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings']) ?
			DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings'] :
			@unserialize(DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings'])
		;
		DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings'] =
			is_array(DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings']) ?
			DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings'] :
			array()
		;

		// Set the new invis setting
		DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings'][$instance['instanceid']] = intval($cleanedInput['invisibility']);

		// Update the user's editor styles
		DBTech_Shout_Core::$db->update('user', array(
			'dbtech_vbshout_invisiblesettings' => trim(serialize(DBTech_Shout_Core::$userinfo['dbtech_vbshout_invisiblesettings']))
		), 'WHERE ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' = ' . intval(DBTech_Shout_Core::$userinfo['userid']));

		if ($cleanedInput['invisibility'])
		{
			// We're switching to stealth mode, ensure we don't have any sessions
			DBTech_Shout_Core::$db->delete('dbtech_vbshout_session', array(
				DBTech_Shout_Core::$userinfo['userid'],
				$instance['instanceid'],
			), 'WHERE userid = ? AND instanceid = ?');
		}
	}
}