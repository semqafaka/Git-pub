<?php
class DBTech_Shout_Action_Ajax_Joinchat extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 8))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		// Chat join
		DBTech_Shout_Shoutbox::joinChatroom($chatroom, DBTech_Shout_Core::$userinfo['userid']);
	}
}