<?php
class DBTech_Shout_Action_Ajax_Leavechat extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 16))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		// Chat leave
		DBTech_Shout_Shoutbox::leaveChatroom($chatroom, DBTech_Shout_Core::$userinfo['userid']);
	}
}