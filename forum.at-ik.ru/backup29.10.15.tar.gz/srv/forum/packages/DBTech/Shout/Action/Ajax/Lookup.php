<?php
class DBTech_Shout_Action_Ajax_Lookup extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 32))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		$cleanedInput = DBTech_Shout_Core::filter(array(
			'username' => TYPE_STR,
		));

		// Do url decode
		$cleanedInput['username'] = urldecode($cleanedInput['username']);

		if (!$instance['options']['enablepms'])
		{
			DBTech_Shout_Shoutbox::$fetched['error'] = DBTech_Shout_Core::phrase('dbtech_vbshout_pms_disabled');
			return false;
		}

		if ($cleanedInput['username'] == DBTech_Shout_Core::$userinfo['username'])
		{
			DBTech_Shout_Shoutbox::$fetched['error'] = DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_username');
			return false;
		}

		if (!$userId = DBTech_Shout_Core::$db->fetchOne('
			SELECT ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . '
			FROM $user
			WHERE username = ?
		', array(
			$cleanedInput['username']
		)))
		{
			DBTech_Shout_Shoutbox::$fetched['error'] = DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_username');
			return false;
		}

		// Return the userid
		DBTech_Shout_Shoutbox::$fetched['pmuserid'] = $userId;
	}
}