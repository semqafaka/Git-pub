<?php
class DBTech_Shout_Action_Ajax_Save extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		// Un-idle us
		DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);

		// Initialise saving
		$cleanedInput = DBTech_Shout_Core::filter(array(
			'shoutid' 		=> TYPE_INT,
			'message' 		=> TYPE_NOHTML,
			'type' 			=> TYPE_STR,
			'pmuserid' 		=> TYPE_UINT,
			'chatroomid' 	=> TYPE_UINT,
			'tabid' 		=> TYPE_STR,
			'source' 		=> TYPE_STR,
		));

		// Do url decode
		$cleanedInput['message'] = urldecode($cleanedInput['message']);

		// Set tabid
		$tabid = (in_array($cleanedInput['tabid'], array('aop', 'activeusers', 'shoutnotifs', 'systemmsgs')) ? 'shouts' : $cleanedInput['tabid']) . $instance['instanceid'];

		if (substr($tabid, 0, 2) == 'pm')
		{
			// Override this type
			$cleanedInput['type'] = 'pm';
		}

		// Make sure it's set
		$shouttype = (isset(DBTech_Shout_Shoutbox::$shouttypes[$cleanedInput['type']]) ? $cleanedInput['type'] : 'shout');

		// Init the Shout DM
		$shoutDm = new DBTech_Shout_DataManager_Shout(DBTech_Shout_DataManager::ERROR_ARRAY);
			$shoutDm->setInfo('instance', $instance);

		if ($cleanedInput['shoutid'])
		{
			if (!$shoutInfo = DBTech_Shout_Core::$db->fetchRow('
				SELECT *
				FROM $dbtech_vbshout_shout AS vbshout
				WHERE shoutid = ?
			', array(
				$cleanedInput['shoutid']
			)))
			{
				// Shout didn't exist
				return false;
			}

			// Set the existing data
			$shoutDm->setExistingData($shoutInfo);

			// Only thing that's changed
			$shoutInfo['message'] = $cleanedInput['message'];
		}
		else
		{
			// Construct the shout info on the fly
			$shoutInfo = array(
				'id' 			=> $cleanedInput['pmuserid'],
				'message' 		=> $cleanedInput['message'],
				'type'			=> DBTech_Shout_Shoutbox::$shouttypes[$shouttype],
				'instanceid' 	=> $instance['instanceid'],
				'chatroomid'	=> $cleanedInput['chatroomid'],
			);
		}

		// Grab this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');

		// Shorthand
		if ($cleanedInput['chatroomid'] AND $chatroom = $chatroomCache[$cleanedInput['chatroomid']])
		{
			// Ensure the proper instance id is set
			$shoutInfo['instanceid'] = $chatroom['instanceid'];
		}

		// Set the shout info
		$shoutDm->bulkSet($shoutInfo);

		// Now finally save
		$shoutDm->save();

		if (isset(DBTech_Shout_Shoutbox::$fetched['error']) AND DBTech_Shout_Shoutbox::$fetched['error'])
		{
			// We haz error
			return false;
		}

		// Update the AOP
		DBTech_Shout_Shoutbox::setAop('shouts', $instance['instanceid'], (substr($tabid, 0, 2) != 'pm'), true);

		if ($shouttype == DBTech_Shout_Shoutbox::$shouttypes['notif'])
		{
			// Update the AOP
			DBTech_Shout_Shoutbox::setAop('shoutnotifs', $instance['instanceid'], false, true);
		}

		if ($shouttype == DBTech_Shout_Shoutbox::$shouttypes['system'])
		{
			// Update the AOP
			DBTech_Shout_Shoutbox::setAop('systemmsgs', $instance['instanceid'], false, true);
		}

		// Fetch the file in question
		DBTech_Shout_Action_Ajax_Fetch::__handle($instance, $chatroom, $args);

		
	}
}