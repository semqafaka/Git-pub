<?php
class DBTech_Shout_Action_Ajax_Sounds extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 64))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		$cleanedInput = DBTech_Shout_Core::filter(array(
			'tabs' => TYPE_ARRAY,
		));

		DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings'] =
			is_array(DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings']) ?
			DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings'] :
			@unserialize(DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings'])
		;
		DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings'] =
			is_array(DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings']) ?
			DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings'] :
			array()
		;

		DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings'][$instance['instanceid']] = $cleanedInput['tabs'];

		// Update the user's editor styles
		DBTech_Shout_Core::$db->update('user', array(
			'dbtech_vbshout_soundsettings' => trim(serialize(DBTech_Shout_Core::$userinfo['dbtech_vbshout_soundsettings']))
		), 'WHERE ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' = ' . intval(DBTech_Shout_Core::$userinfo['userid']));
	}
}