<?php
class DBTech_Shout_Action_Ajax_Styleprops extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 128))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		$cleanedInput = DBTech_Shout_Core::filter(array(
			'editor' 		=> TYPE_ARRAY,
		));

		// Set shout styles array
		$cleanedInput['editor']['color'] = preg_replace('/[^A-Za-z0-9 #(),]/', '', $cleanedInput['editor']['color']);
		DBTech_Shout_Shoutbox::$shoutstyle[$instance['instanceid']] = $cleanedInput['editor'];

		// Update the user's editor styles
		DBTech_Shout_Core::$db->update('user', array(
			'dbtech_vbshout_shoutstyle' => trim(serialize(DBTech_Shout_Shoutbox::$shoutstyle))
		), 'WHERE ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' = ' . intval(DBTech_Shout_Core::$userinfo['userid']));

		// Set the AOP
		DBTech_Shout_Shoutbox::setAop('shouts', $instance['instanceid'], false, true);

		// Fetch the shouts again
		DBTech_Shout_Shoutbox::fetchShouts($instance, $chatroom, $args);
	}
}