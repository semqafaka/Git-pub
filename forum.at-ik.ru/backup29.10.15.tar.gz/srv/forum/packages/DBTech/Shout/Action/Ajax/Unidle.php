<?php
class DBTech_Shout_Action_Ajax_Unidle extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 1024))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		DBTech_Shout_Shoutbox::fetchActiveUsers($instance, $chatroom);
		DBTech_Shout_Shoutbox::$fetched['activeusers']['count'] = count(DBTech_Shout_Shoutbox::$activeusers);

		if ($instance['options']['activeusers'])
		{
			if (isset($args['chatroomid']) AND $args['chatroomid'])
			{
				// Array of all active users
				DBTech_Shout_Shoutbox::$fetched['activeusers']['usernames'] = (count(DBTech_Shout_Shoutbox::$activeusers) ? implode('<br />', DBTech_Shout_Shoutbox::$activeusers) : DBTech_Shout_Core::phrase('dbtech_vbshout_no_chat_users'));
				if ($instance['options']['enableaccess'])
				{
					//DBTech_Shout_Shoutbox::$fetched['activeusers']['usernames'] .= '<br /><br /><a href="vbshout.php?do=chataccess&amp;instanceid=' . $instance['instanceid'] . '&amp;chatroomid=' . $args['chatroomid'] . '" target="_blank"><b>' . DBTech_Shout_Core::phrase('dbtech_vbshout_chat_access') . '</b></a>';
				}

			}
			else
			{
				// Array of all active users
				DBTech_Shout_Shoutbox::$fetched['activeusers']['usernames'] = (count(DBTech_Shout_Shoutbox::$activeusers) ? implode('<br />', DBTech_Shout_Shoutbox::$activeusers) : DBTech_Shout_Core::phrase('dbtech_vbshout_no_active_users'));
			}
		}
	}
}