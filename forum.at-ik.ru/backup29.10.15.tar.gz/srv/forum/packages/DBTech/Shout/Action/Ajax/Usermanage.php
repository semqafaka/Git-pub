<?php
class DBTech_Shout_Action_Ajax_Usermanage extends DBTech_Shout_Action_Ajax
{
	public static function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 256))
		{
			// Un-idle us
			DBTech_Shout_Shoutbox::unIdle($instance, $chatroom);
		}

		$cleanedInput = DBTech_Shout_Core::filter(array(
			'manageaction' 	=> TYPE_STR,
			'userid' 		=> TYPE_UINT,
			'type' 			=> TYPE_STR,
		));

		// Grab the username
		if (!$exists = DBTech_Shout_Core::$db->fetchRow('
			SELECT *
			FROM $user
			WHERE ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' = ?
		', array(
			$cleanedInput['userid']
		)))
		{
			// User didn't exist
			return false;
		}

		// Begin shout info
		$shoutInfo = array();

		if ($instance)
		{
			// We are in an instance
			$shoutInfo['instanceid'] = $instance['instanceid'];
		}

		if ($chatroom)
		{
			// We are in a chatroom
			$shoutInfo['chatroomid'] = $chatroom['chatroomid'];
		}

		$skip = false;
		switch ($cleanedInput['manageaction'])
		{
			case 'ignoreunignore':
				$isignored = DBTech_Shout_Core::$db->fetchRow('
					SELECT userid
					FROM $dbtech_vbshout_ignorelist
					WHERE userid = ?
						AND ignoreuserid = ?
				', array(
					DBTech_Shout_Core::$userinfo['userid'],
					$cleanedInput['userid']
				));
				$shoutInfo['message'] = ($isignored ? '/unignore ' : '/ignore ') . $exists['username'];
				break;

			case 'chatremove':
				// Remove an user from chat

				// Leave the chat room
				DBTech_Shout_Shoutbox::leaveChatroom($chatroom, $cleanedInput['userid']);

				$shoutInfo['message'] = DBTech_Shout_Core::phrase('dbtech_vbshout_x_removed_successfully', array('param1' => $exists['username']));
				$shoutInfo['userid'] = -1;
				$shoutInfo['type'] = DBTech_Shout_Shoutbox::$shouttypes['system'];
				break;

			

			default:
				$skip = true;
				break;
		}

		if (!$skip)
		{
			// Init the Shout DM
			$shoutDm = new DBTech_Shout_DataManager_Shout(DBTech_Shout_DataManager::ERROR_ARRAY);
				$shoutDm->setInfo('instance', $instance);
				$shoutDm->bulkSet($shoutInfo);
			$shoutDm->save();

			if (isset(DBTech_Shout_Shoutbox::$fetched['error']) AND DBTech_Shout_Shoutbox::$fetched['error'])
			{
				// We haz error
				return false;
			}

			// Update the AOP
			DBTech_Shout_Shoutbox::setAop('shouts', $instance['instanceid'], false, true);

			// Shout fetching args
			$args = array();
			if ($cleanedInput['type'] == 'pm')
			{
				// Fetch only PMs
				$args['types'] 		= DBTech_Shout_Shoutbox::$shouttypes['pm'];
				$args['onlyuser'] 	= $cleanedInput['userid'];
			}

			if ($chatroom)
			{
				// Fetch only from this chatroom
				$args['chatroomid'] = $chatroom['chatroomid'];
			}

			// We want to fetch shouts
			DBTech_Shout_Shoutbox::fetchShouts($instance, $chatroom, $args);
		}
		unset($shout);
	}
}