<?php
class DBTech_Shout_Action_Archive extends DBTech_Shout_Action_Abstract
{
	public static function actionIndex()
	{
		$cleanedInput = DBTech_Shout_Core::filter(array(
			'instanceid' 	=> TYPE_UINT,
			'chatroomid' 	=> TYPE_UINT,
			'page' 			=> TYPE_UINT,
			'perpage' 		=> TYPE_UINT,
			'message' 		=> TYPE_STR,
			
		));

		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		if (!$instance = $instanceCache[$cleanedInput['instanceid']])
		{
			DBTech_Shout_Core::error(DBTech_Shout_Core::phrase('vbshout_invalid_instanceid'));
		}

		if (!$instance['active'])
		{
			// Keine permissions
			DBTech_Shout_Core::error(DBTech_Shout_Core::phrase('vbshout_invalid_instanceid'));
		}

		if (!$instance['permissions_parsed']['canviewarchive'])
		{
			// Keine permissions
			DBTech_Shout_Core::error(DBTech_Shout_Core::phrase('vbshout_invalid_instanceid'));
		}

		// Ensure there's no errors or out of bounds with the page variables
		if ($cleanedInput['page'] < 1)
		{
			$cleanedInput['page'] = 1;
		}
		$page = $cleanedInput['page'];
		$perPage = (!$cleanedInput['perpage']) ? $instance['options']['maxarchiveshouts'] : ($cleanedInput['perpage'] > 250 ? 250 : $cleanedInput['perpage']);
		$startAt = ($page - 1) * $perPage;
		$pageVars = array(
			'instanceid' => $cleanedInput['instanceid']
		);
		$args  = array(
			'instanceid' => $cleanedInput['instanceid'],
			'archive' => true,
			'startat' => $startAt,
			'perpage' => $perPage
		);

		// Include chatrooms we're a member of (and no chatroom)
		$chatroomMembership = DBTech_Shout_Shoutbox::fetchChatroomMemberships(DBTech_Shout_Core::$userinfo, '1', $instance['instanceid']);
		$chatroomMembership[] = 0;

		if (!$cleanedInput['chatroomid'] OR !in_array($cleanedInput['chatroomid'], $chatroomMembership))
		{
			// @TODO: Re-enable this when we have a way of indicating what chatroom we're viewing a shout from
			//$args['chatroomids'] = $chatroomMembership;
			$cleanedInput['chatroomid'] = 0;
		}
		else
		{
			// Limit by username
			$pageVars['chatroomid'] = $cleanedInput['chatroomid'];
		}

		// Init this
		$searchParams = array();

		if ($instance['permissions_parsed']['cansearcharchive'])
		{
			// Set this straight away as it's pre-validated
			$searchParams['perpage'] = $perPage;

			if ($cleanedInput['message'])
			{
				// Limit by message
				//$hook_query_and .= " AND vbshout.message LIKE '%" . $db->escape_string($cleanedInput['message']) . "%'";
				$pageVars['message'] = $args['message'] = $cleanedInput['message'];
				$searchParams['message'] = htmlspecialchars($cleanedInput['message']);
			}

			
		}

		// Grab all the shouts
		DBTech_Shout_Shoutbox::fetchShouts($instance, array(), $args);

		// By default, we have 10 top shouters
		$maxTopShouters = 10;

		

		// Fetch all the shout info
		DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'totalshouts', DBTech_Shout_Core::numberFormat(DBTech_Shout_Core::$db->fetchOne('
			SELECT COUNT(*)
			FROM $dbtech_vbshout_shout
			WHERE userid > 0
				AND instanceid IN(-1, 0, ?)
				' . ($cleanedInput['chatroomid'] ? "AND chatroomid = " . intval($cleanedInput['chatroomid']) : '') . '
		', array($instance['instanceid']))));

		// Fetch last 24 hours
		DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'last24hrs', DBTech_Shout_Core::numberFormat(DBTech_Shout_Core::$db->fetchOne('
			SELECT COUNT(*)
			FROM $dbtech_vbshout_shout
			WHERE userid > 0
				AND instanceid IN(-1, 0, ?)
				AND dateline >= ?
				' . ($cleanedInput['chatroomid'] ? "AND chatroomid = " . intval($cleanedInput['chatroomid']) : '') . '
		', array($instance['instanceid'], (DBTech_Shout_Core::getTime() - 86400)))));

		if (DBTech_Shout_Core::$userinfo['userid'])
		{
			// Set own shouts
			DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'ownshouts', array(
				'current' => DBTech_Shout_Core::numberFormat(DBTech_Shout_Core::$userinfo['dbtech_vbshout_shouts']),
				'lifetime' => DBTech_Shout_Core::numberFormat(DBTech_Shout_Core::$userinfo['dbtech_vbshout_shouts_lifetime']),
			));
		}

		$topShouters = array(
			'current' => DBTech_Shout_Core::$db->fetchAll('SELECT *, dbtech_vbshout_shouts AS numshouts FROM $user HAVING numshouts > 0 ORDER BY numshouts DESC LIMIT ' . $maxTopShouters),
			'lifetime' => DBTech_Shout_Core::$db->fetchAll('SELECT *, dbtech_vbshout_shouts_lifetime AS numshouts FROM $user HAVING numshouts > 0 ORDER BY numshouts DESC LIMIT ' . $maxTopShouters),
		);

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				// Set top shouters
				DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'topShouters', $topShouters);

				// Set shouts
				DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'shouts', (isset(DBTech_Shout_Shoutbox::$fetched['shouts']) ? DBTech_Shout_Shoutbox::$fetched['shouts'] : array()));

				// Shorthand
				$pageNav = (string)XenForo_Template_Helper_Core::pageNav($perPage, intval(DBTech_Shout_Shoutbox::$fetched['totalshouts']), $page, 'do=archive', NULL, $pageVars);

				if (DBTech_Shout_Core::option('useFriendlyUrls'))
				{
					// Page nav URLs should be compatible with friendly URLs
					$pageNav = str_replace(
						array('do=archive', '/?'),
						array('vbshout.php?do=archive', '&'),
						$pageNav
					);
				}
				else
				{
					// We can replace index.php directly
					$pageNav = str_replace(
						array('index.php', '/&'),
						array('vbshout.php', '&'),
						$pageNav
					);
				}
				// Set page nav
				DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'pageNav', $pageNav);
				break;

			case 'vBulletin':
				$topShouters['current'] = array_map('fetch_muserinfo', $topShouters['current']);
				$topShouters['lifetime'] = array_map('fetch_muserinfo', $topShouters['lifetime']);

				$topShoutersRendered = array(
					'current' => '',
					'lifetime' => ''
				);
				foreach ($topShouters as $key => $shouters)
				{
					foreach ($shouters as $userinfo)
					{
						// Render this template
						$topShoutersRendered[$key] .= DBTech_Shout_Core::renderTemplate('dbtech_vbshout_archive_topshouter_bit', array('userinfo' => $userinfo));
					}
				}

				$shoutsRendered = '';
				foreach (DBTech_Shout_Shoutbox::$fetched['shouts'] as $shout)
				{
					// Render this template
					$shoutsRendered[$key] .= DBTech_Shout_Core::renderTemplate('dbtech_vbshout_archive_shoutbit', array('userinfo' => $userinfo));
				}

				// Finally register the shouts with the template
				DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'topShouters', $topShoutersRendered);
				DBTech_Shout_Core::setParam('dbtech_vbshout_archive', 'shouts', $shoutsRendered);
				break;
		}

		DBTech_Shout_Core::renderOutput(
			DBTech_Shout_Core::renderTemplate('dbtech_vbshout_archive', array(
				'instance' => $instance,
				'searchparams' => $searchParams
			)),
			array(
				'noVisitorPanel' => 1
			)
		);
	}
}
?>