<?php
class DBTech_Shout_Autoloader
{
	private $dir;

	public function __construct($dir = null)
	{
		if (is_null($dir))
		{
			$dir = __DIR__;
		}
		$this->dir = $dir;
	}
	/**
	 * Registers ControllerAutoloader as an SPL autoloader.
	 */
	public static function register($dir = null)
	{
		ini_set('unserialize_callback_func', 'spl_autoload_call');
		spl_autoload_register(array(new self($dir), 'autoload'));
	}

	/**
	 * Handles autoloading of classes.
	 *
	 * @param string $class A class name.
	 *
	 * @return boolean Returns true if the class has been loaded
	 */
	public function autoload($class)
	{
		if (preg_match('/[^a-z0-9_]/i', $class))
		{
			return false;
		}

		if (file_exists($file = $this->dir . '/' . str_replace(array('\\', '_'), '/', $class) . '.php'))
		{
			require($file);
		}

		if (method_exists($class, '_init'))
		{
			$class::_init();
		}

		return class_exists($class, false);
	}
}