<?php
/*======================================================================*\
|| #################################################################### ||
|| # ---------------------------------------------------------------- # ||
|| # Copyright ©2013 Fillip Hannisdal AKA Revan/NeoRevan/Belazor 	  # ||
|| # All Rights Reserved. 											  # ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ---------------------------------------------------------------- # ||
|| # You are not allowed to use this on your server unless the files  # ||
|| # you downloaded were done so with permission.					  # ||
|| # ---------------------------------------------------------------- # ||
|| #################################################################### ||
\*======================================================================*/

// #############################################################################
// cache functionality class

/**
* Class that handles keeping the database cache up to date.
*/
class DBTech_Shout_Cache
{
	// A few constants
	const PREFIX 					= 'dbtech_vbshout_';
	const TTL 						= 3600;

	/**
	* Array of cache fields
	*
	* @public	array
	*/
	public static $cache 			= array();

	/**
	* Array of DB table joins / other commands
	*
	* @protected	array
	*/
	protected static $_tables		= array(
		'button'			=> '',
		'chatroom' 			=> '',
		'command' 			=> 'ORDER BY `command` ASC',
		'instance'			=> 'ORDER BY `displayorder` ASC',
	);

	/**
	* Array of callbacks
	*
	* @protected	array
	*/
	protected static $_loadCallbacks		= array(
		'instance'			=> '_loadInstanceData',
	);

	/**
	* Array of cached items
	*
	* @public	array
	*/
	public static $unserialize		= array(
		'chatroom' => array(
			'members',
		),
		'instance' => array(
			'permissions',
			'bbcodepermissions',
			'notices',
			'options',
			'forumids',
		),
	);

	/**
	* Array of items to NOT fetch
	*
	* @protected	array
	*/
	protected static $_idColumns	= array();


	/**
	* Initialises the DataRegistry model in xenForo
	*/
	public static function _init()
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				self::$cache = XenForo_Model::create('XenForo_Model_DataRegistry');
				self::fetchFromDatastore();
				break;
		}
	}

	/**
	* Sets a cache item
	*
	* @param	string	Database table we are working with
	* @param	mixed	The data to cache
	* @param	string	(Optional) Key if writing to vB Optimise
	* @param	integer	(Optional) Time-To-Live if writing to vB Optimise
	*/
	public static function set($type, $data, $key = '', $ttl = -1)
	{
		if (!isset(self::$_tables[$type]))
		{
			// Write the cache
			self::write($data, $type, ($key ? $key : $type), $ttl);
		}

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				self::$cache->set(self::PREFIX . $type, $data);
				break;

			case 'vBulletin':
				// Set the data
				self::$cache[$type] = $data;
				break;
		}
	}

	/**
	* Gets a cache item
	*
	* @param	string	Database table we are working with
	* @param	string	(Optional) Key if reading from vB Optimise
	*/
	public static function get($type, $key = '')
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$data = self::$cache->get(self::PREFIX . $type);
				if (!is_array($data))
				{
					// This will auto set the data as well
					$data = self::build($type);
				}

				if (isset(self::$_loadCallbacks[$type]) AND is_callable('self::' . self::$_loadCallbacks[$type]))
				{
					call_user_func_array(array('self', self::$_loadCallbacks[$type]), array(&$data));
				}

				return $data;
				break;

			case 'vBulletin':
				if (!isset(self::$_tables[$type]))
				{
					// This is a vBO cache read
					return self::read($type, ($key ? $key : $type));
				}
				else if (!isset(self::$cache[$type]) OR !is_array(self::$cache[$type]))
				{
					// We need to fetch from datastore
					self::fetchFromDatastore();
				}

				// Cache is fine
				return self::$cache[$type];
				break;
		}
	}

	public static function fetchFromDatastore()
	{
		// Grab the extra cache fields
		$extracache = array();
		foreach (self::$_tables as $table => $val)
		{
			$extracache[] = self::PREFIX . $table;
		}

		if (!count($extracache))
		{
			// We don't need to do this
			return;
		}

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$cache = self::$cache->getMulti($extracache);
				foreach ($cache as $title => $data)
				{
					// Shorthand
					$type = substr($title, strlen(self::PREFIX));

					// Check if the value is set
					if (!is_array($data))
					{
						// Build datastore
						self::build($type);
					}
				}
				break;

			case 'vBulletin':
				// Do fetch from the database
				$GLOBALS['vbulletin']->datastore->fetch($extracache);

				foreach ($extracache as $title)
				{
					// Shorthand
					$type = substr($title, strlen(self::PREFIX));

					// Check if the value is set
					if (!isset($GLOBALS['vbulletin']->$title) OR !is_array($GLOBALS['vbulletin']->$title))
					{
						// Build datastore
						self::build($type);
					}
					else
					{
						// The data was valid
						$data = $GLOBALS['vbulletin']->$title;

						// Save some memory
						unset($GLOBALS['vbulletin']->title);

						// Set the cache data at last
						self::set($type, $data);
					}
				}
				break;
		}
	}

	/**
	* Builds the cache in case the datastore has been cleaned out.
	*
	* @param	string	Database table we are working with
	*/
	public static function build($type)
	{
		// Premove the prefix
		$dbtype = self::PREFIX . $type;

		// Initialise the some arrays so we can add to them quicker
		$data = array();
		$index = (isset(self::$_idColumns[$type]) ? self::$_idColumns[$type] : $type . 'id');

		$query = DBTech_Shout_Core::$db->fetchAll('
			SELECT ' . $dbtype . '.*
			FROM $' . $dbtype . ' AS ' . $dbtype . '
			' . ((isset(self::$_tables[$type]) AND self::$_tables[$type]) ? self::$_tables[$type] : '')
		);
		foreach ($query as $result)
		{
			// Store data
			$data[$result[$index]] = $result;

			foreach ($result as $key => $value)
			{
				if (
					isset(self::$unserialize[$type])
					AND is_array(self::$unserialize[$type])
					AND in_array($key, self::$unserialize[$type])
				)
				{
					// Do unserialize
					$data[$result[$index]][$key] = @unserialize(stripslashes($value));
					$data[$result[$index]][$key] = is_array($data[$result[$index]][$key]) ? $data[$result[$index]][$key] : array();
				}
			}
		}

		if (!is_array($data))
		{
			// Avoid corrupting the cache this way
			return;
		}

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'vBulletin':
				// Finally update the datastore with the new value
				build_datastore($dbtype, serialize($data), 1);
				break;
		}

		// Set the data
		self::set($type, $data);

		return $data;
	}

	/**
	* Builds the cache for all available tables.
	*/
	public static function buildAll()
	{
		foreach (self::$_tables as $type => $clauses)
		{
			// Build this cache
			self::build($type);
		}
	}

	/**
	* Reads from the vB Optimise cache
	*
	* @param	string	Referencing the vB Optimise option varname
	* @param	string	The cache key to read from
	*/
	public static function read($cacheType, $key)
	{
		if (!self::_canCache($cacheType))
		{
			// We can't cache this
			return -1;
		}

		// Fetch the vBO data
		$_data = vb_optimise::$cache->get(str_replace('_', '.', self::$prefix) . '.' . $key);

		if (is_array($_data) AND TIMENOW < $_data['time'])
		{
			// We saved some queries
			vb_optimise::stat(1);
			vb_optimise::report('Fetched ' . str_replace('_', '.', self::$prefix) . '.' . $key . ' from cache successfully.');

			return $_data['cache'];
		}

		return false;
	}

	/**
	* Writes to the vB Optimise cache
	*
	* @param	string	Database table we are working with
	* @param	string	(Optional) Any additional clauses to the query
	*/
	public static function write($data, $cacheType, $key, $ttl = -1)
	{
		global $vbulletin;

		if (!self::_canCache($cacheType))
		{
			// We can't cache this
			return false;
		}

		// By default, we want to "null out" the cache
		$_data = false;

		if ($data !== false)
		{
			// Write the vBO data
			$_data = array(
				'time'	=> (
					TIMENOW + (
						isset($vbulletin->options['vbo_cache_' . self::$prefix . $cacheType]) ?
							($vbulletin->options['vbo_cache_' . self::$prefix . $cacheType] * 3600) :
							($ttl == -1 ? self::TTL : $ttl)
					)
				),
				'cache'	=> $data,
			);
		}

		// Write the cache
		vb_optimise::$cache->set(str_replace('_', '.', self::$prefix) . '.' . $key, $_data);
		vb_optimise::report('Cached ' . str_replace('_', '.', self::$prefix) . '.' . $key . ' successfully.');

		return true;
	}

	/**
	* Writes to the vB Optimise cache
	*/
	public static function flush()
	{
		if (!self::_canCache())
		{
			// We can't cache this
			return false;
		}

		// Flush the cache
		vb_optimise::$cache->flush();

		return true;
	}

	/**
	* Tests whether we can cache something
	*
	* @param	string	Original message
	* @param	string	Overriding
	*/
	protected static function _canCache($cacheType = '')
	{
		global $vbulletin;

		if (!class_exists('vb_optimise'))
		{
			// We don't have vBO installed
			return false;
		}

		if (!isset($vbulletin->options['vbo_online']))
		{
			// vBO is turned off
			return false;
		}

		if (!is_object(vb_optimise::$cache))
		{
			// Not a valid cache object
			return false;
		}

		if (!$cacheType)
		{
			// This will be used for the flush
			return true;
		}

		if (!isset($vbulletin->options['vbo_cache_' . self::$prefix . $cacheType]))
		{
			// This cache item has no setting, so we want to cache it
			return true;
		}

		if (!$vbulletin->options['vbo_cache_' . self::$prefix . $cacheType])
		{
			// The cache time has been turned off
			return false;
		}

		return true;
	}

	protected static function _loadInstanceData(&$data)
	{
		foreach ($data as $instanceid => $instance)
		{
			// Load default options
			DBTech_Shout_Shoutbox::loadDefaultInstanceOptions($data[$instanceid]);

			// Load instance permissions
			DBTech_Shout_Shoutbox::loadInstancePermissions($data[$instanceid]);

			// Load instance permissions
			DBTech_Shout_Shoutbox::loadInstanceBbcodePermissions($data[$instanceid]);
		}
	}
}