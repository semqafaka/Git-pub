<?php
class DBTech_Shout_Core
{
	protected static $system;
	protected static $_modelCache = array();
	protected static $fc;
	protected static $hasPreRendered = false;
	protected static $HTML = array();
	protected static $params = array();
	protected static $_input;
	public static $db;
	public static $versionnumber;
	public static $userinfo = array();
	public static $usergroupcache = array();
	public static $forumcache = array();

	public static function init($isHook = false)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				$startTime = microtime(true);
				$fileDir = '.';

				if (!$isHook)
				{
					require_once($fileDir . '/library/XenForo/Autoloader.php');
					XenForo_Autoloader::getInstance()->setupAutoloader($fileDir . '/library');

					XenForo_Application::initialize($fileDir . '/library', $fileDir);
					XenForo_Application::set('page_start_time', $startTime);

					self::$fc = new XenForo_FrontController(new XenForo_Dependencies_Public());

					XenForo_Application::set('fc', self::$fc);

					self::$fc->setup();
					self::$fc->setRequestPaths();
					self::$fc->getDependencies()->preLoadData();

					if (!XenForo_Application::isRegistered('session'))
					{
						XenForo_Session::startPublicSession(self::$fc->getRequest());
					}
				}
				else
				{
					self::$fc = XenForo_Application::get('fc');
				}

				// Set the version number
				self::$versionnumber = XenForo_Application::$version;

				$visitor = XenForo_Visitor::getInstance()->toArray();
				self::$userinfo = $visitor;
				self::$userinfo['userid'] =& self::$userinfo['user_id'];
				self::$userinfo['usergroupid'] =& self::$userinfo['user_group_id'];
				self::$userinfo['membergroupids'] =& self::$userinfo['secondary_group_ids'];

				// Shorthand
				$db = XenForo_Application::getDb();

				// Pre-cache phrases
				XenForo_Phrase::setPhrases($db->fetchPairs('
					SELECT title, phrase_text
					FROM xf_phrase_compiled
					WHERE language_id = ?
						AND title LIKE \'dbtech_vbshout_%\'
				', self::$userinfo['language_id'] ? self::$userinfo['language_id'] : self::option('defaultLanguageId')));

				// Set a few required things
				XenForo_Template_Public::setStyleId(self::$userinfo['style_id'] ? self::$userinfo['style_id'] : self::option('defaultStyleId'));
				XenForo_Template_Public::setLanguageId(self::$userinfo['language_id'] ? self::$userinfo['language_id'] : self::option('defaultLanguageId'));

				// Set usergroup cache
				self::$usergroupcache = XenForo_Model::create('XenForo_Model_UserGroup')->getAllUserGroups();
				foreach (self::$usergroupcache as $key => $arr)
				{
					// Make it usable with vB code
					self::$usergroupcache[$key]['usergroupid'] =& self::$usergroupcache[$key]['user_group_id'];
				}

				// Set forum cache
				self::$forumcache = XenForo_Model::create('XenForo_Model_Node')->getAllNodes();
				foreach (self::$forumcache as $key => $arr)
				{
					// Make it usable with vB code
					self::$forumcache[$key]['forumid'] =& self::$forumcache[$key]['node_id'];
				}

				// Init DB
				self::$db = new DBTech_Shout_Database($db);

				// Ensure this is set
				self::$_input = new XenForo_Input(self::$fc->getRequest());

				// Define important constants
				define('TYPE_ARRAY', 		XenForo_Input::ARRAY_SIMPLE);
				define('TYPE_UINT', 		XenForo_Input::UINT);
				define('TYPE_INT', 			XenForo_Input::INT);
				define('TYPE_UNUM', 		XenForo_Input::UNUM);
				define('TYPE_NUM', 			XenForo_Input::NUM);
				define('TYPE_STR', 			XenForo_Input::STRING);
				define('TYPE_BOOL', 		XenForo_Input::BOOLEAN);
				define('TYPE_UNIXTIME', 	'unixtime');
				define('TYPE_NOHTML', 		'nohtml');
				break;

			case 'vBulletin':
				// Set the version number
				self::$versionnumber = $GLOBALS['vbulletin']->versionnumber;

				// Set caches
				self::$userinfo =& $GLOBALS['vbulletin']->userinfo;
				self::$usergroupcache = $GLOBALS['vbulletin']->usergroupcache;
				self::$forumcache = $GLOBALS['vbulletin']->forumcache;

				// Init DB
				self::$db = new DBTech_Shout_Database($GLOBALS['vbulletin']->db);
				break;
		}
	}

	public static function getSystem()
	{
		if (!isset(self::$system) OR !self::$system OR self::$system === NULL)
		{
			self::$system = is_dir('./library/XenForo') ? 'XenForo' : 'vBulletin';
		}

		return self::$system;
	}

	public static function runAction()
	{
		// Default value
		$class = 'abstract';

		if (isset($_POST['do']) AND !empty($_POST['do']))
		{
			// $_POST requests take priority
			$class = $_POST['do'];
		}
		else if (isset($_GET['do']) AND !empty($_GET['do']))
		{
			// We had a GET request instead
			$class = $_GET['do'];
		}

		// Strip non-valid characters
		$class = preg_replace('/[^\w-_]/i', '', implode('_', array_map('ucfirst', explode('/', strtolower($class)))));

		if (!$class)
		{
			// No request
			$class = 'abstract';
		}

		// Shorthand
		$class = 'DBTech_Shout_Action_' . $class;

		try
		{
			if (!class_exists($class))
			{
				// Action class didn't exist
				throw new Exception("Class <b>$class</b> cannot be found.");
			}

			// Default value
			$method = 'index';

			if (isset($_POST['action']) AND !empty($_POST['action']))
			{
				// $_POST requests take priority
				$method = $_POST['action'];
			}
			else if (isset($_GET['action']) AND !empty($_GET['action']))
			{
				// We had a GET request instead
				$method = $_GET['action'];
			}

			// Strip non-valid characters
			$method = preg_replace('/[^\w-]/i', '', strtolower($method));

			$reflection = new ReflectionClass($class);
			if (!$method OR $reflection->isAbstract())
			{
				// No request
				$method = 'index';
			}

			// Shorthand
			$method = 'action' . ucfirst($method);

			if (!method_exists($class, $method))
			{
				// Action class didn't exist
				throw new Exception("Method <b>$method</b> cannot be found in <b>$class</b>.");
			}

			// Shorthand
			$class::$method();
		}
		catch (Exception $e)
		{
			// Trigger error
			self::error($e->getMessage());
		}
	}

	public static function error($message)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				self::renderOutput($message);
				break;

			case 'vBulletin':
				eval(standard_error($message));
				break;
		}
	}

	public static function redirect($message, $url)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				header('Location: ' . $url);
				die();
				break;

			case 'vBulletin':
				// Set redirect URL
				$GLOBALS['vbulletin']->url = $url;
				eval(standard_redirect($message));
				break;
		}
	}

	public static function option($option)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				return XenForo_Application::get('options')->get($option);
				break;

			case 'vBulletin':
				return isset($GLOBALS['vbulletin']->options[$option]) ? $GLOBALS['vbulletin']->options[$option] : null;
				break;
		}
	}

	public static function phrase($phrase, array $params = array())
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				XenForo_Phrase::setEscapeCallback(false);
				$phrase = new XenForo_Phrase($phrase, $params);
				return $phrase->render();
				break;

			case 'vBulletin':
				return preg_replace_callback('/\{(param[a-z0-9_-]+)\}/i', function($match) use ($params)
				{
					$paramName = $match[1];

					if (!array_key_exists($paramName, $params))
					{
						return $match[0];
					}

					return $params[$paramName];
				}, $GLOBALS['vbphrase'][$phrase]);
				break;
		}
	}

	public static function getTime()
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				return XenForo_Application::$time;
				break;

			case 'vBulletin':
				return TIMENOW;
				break;
		}
	}

	public static function setParam($templateName, $key, $value)
	{
		if (!isset(self::$params[$templateName]))
		{
			// Make sure this is an array
			self::$params[$templateName] = array();
		}

		// Now set the template param
		self::$params[$templateName][$key] = $value;
	}

	public static function getParams($templateName, $key = NULL)
	{
		// Return either a single template param, or all of them belonging to a certain template
		return $key !== NULL ? (
			isset(self::$params[$templateName][$key]) ? self::$params[$templateName][$key] : ''
		) : (
			isset(self::$params[$templateName]) ? self::$params[$templateName] : array()
		);
	}

	public static function setOutput($HTML, $buffer = '_', $overwrite = false)
	{
		// Now set the template param
		if (!isset(self::$HTML[$buffer]))
		{
			// Init this
			self::$HTML[$buffer] = '';
		}

		self::$HTML[$buffer] = $overwrite ? $HTML : (self::$HTML[$buffer] . $HTML);
	}

	public static function getOutput($buffer = null)
	{
		// Return either a single template param, or all of them belonging to a certain template
		return $buffer === NULL ? implode('', self::$HTML) : (isset(self::$HTML[$buffer]) ? self::$HTML[$buffer] : '');
	}

	public static function usergroupPermission($group, $permission, array &$usergroupPermissions = NULL, array &$userInfo = NULL)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				if ($usergroupPermissions === NULL)
				{
					// Set this
					$usergroupPermissions =& self::$userinfo['permissions'];
				}
				return XenForo_Permission::hasPermission($usergroupPermissions, $group, $permission);
				break;

			case 'vBulletin':
				if ($usergroupPermissions === NULL)
				{
					// We had no predefined forum permissions
					if ($userInfo === NULL)
					{
						// We had no user info either, revert to default
						$usergroupPermissions =& self::$userinfo['permissions'];
					}
					else
					{
						if (!isset($userInfo['permissions']))
						{
							// Cache permissions
							cache_permissions($userInfo);
						}

						// Now set this
						$usergroupPermissions =& $userInfo['permissions'];
					}
				}

				$bit = $GLOBALS['vbulletin']->bf_ugp[$group][$permission];
				return (!$bit ? $usergroupPermissions[$group][$permission] : ($usergroupPermissions[$group] & $bit ? 1 : 0));
				break;
		}
	}

	public static function forumPermission($forum, $permission, array &$forumPermissions = NULL, array &$userInfo = NULL)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				$forumModel = self::createModel('XenForo_Model_Forum');
				$forumModel->standardizeViewingUserReferenceForNode($forum['node_id'], $userInfo, $forumPermissions);
				$errorPhraseKey = '';
				switch ($permission)
				{
					case 'canview':
						return $forumModel->canViewForum($forum, $errorPhraseKey, $forumPermissions, $userInfo);
						break;
					case 'canviewthreads':
						return $forumModel->canViewForumContent($forum, $errorPhraseKey, $forumPermissions, $userInfo);
						break;
					case 'canviewothers':
						return XenForo_Permission::hasContentPermission($forumPermissions, 'viewOthers');
						break;
				}
				break;

			case 'vBulletin':
				if ($forumPermissions === NULL)
				{
					// We had no predefined forum permissions
					if ($userInfo === NULL)
					{
						// We had no user info either, revert to default
						$forumPermissions =& self::$userinfo['forumpermissions'][$forum['forumid']];
					}
					else
					{
						if (!isset($userInfo['forumpermissions']))
						{
							// Cache permissions
							cache_permissions($userInfo);
						}

						// Now set this
						$forumPermissions =& $userInfo['forumpermissions'][$forum['forumid']];
					}
				}

				return ((int)$forumPermissions & (int)$GLOBALS['vbulletin']->bf_ugp_forumpermissions[$permission]);
				break;
		}
	}

	public static function date($timestamp, $format = null, $doyestoday = false, $locale = true)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				$format = $format == 'dateformat' ? null : $format;
				return XenForo_Locale::date($timestamp, $format);
				break;

			case 'vBulletin':
				$format = $format ? $format : 'dateformat';
				$format = isset($GLOBALS['vbulletin']->options[$format]) ? $GLOBALS['vbulletin']->options[$format] : $format;
				return vbdate($format, $timestamp, $doyestoday, $locale);
				break;
		}

	}

	public static function time($timestamp, $format = null)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				$format = $format == 'timeformat' ? null : $format;
				return XenForo_Locale::time($timestamp, $format);
				break;

			case 'vBulletin':
				$format = $format ? $format : 'timeformat';
				$format = isset($GLOBALS['vbulletin']->options[$format]) ? $GLOBALS['vbulletin']->options[$format] : $format;
				return vbdate($format, $timestamp);
				break;
		}

	}

	public static function dateTime($timestamp, $format = null, $logFormat = true)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				$format = $format == 'logdateformat' ? null : $format;
				return XenForo_Locale::dateTime($timestamp, $format);
				break;

			case 'vBulletin':
				if ($logFormat)
				{
					$format = $format ? $format : 'logdateformat';
					$format = isset($GLOBALS['vbulletin']->options[$format]) ? $GLOBALS['vbulletin']->options[$format] : $format;
					return vbdate($format, $timestamp);
				}
				else
				{
					return vbdate($GLOBALS['vbulletin']->options['dateformat'], $timestamp) . ' ' . vbdate($GLOBALS['vbulletin']->options['timeformat'], $timestamp);
				}
				break;
		}
	}

	public static function numberFormat($number, $precision = 0)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				return XenForo_Locale::numberFormat($number, $precision);
				break;

			case 'vBulletin':
				return vb_number_format($number, $precision);
				break;
		}
	}

	public static function filter(array $params)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				$paramsNew = $params;
				foreach ($params as $key => $val)
				{
					switch ($val)
					{
						case 'nohtml':
							$paramsNew[$key] = XenForo_Input::STRING;
							break;

						case 'unixtime':
							$paramsNew[$key] = XenForo_Input::ARRAY_SIMPLE;
							break;
					}
				}

				$retval = self::$_input->filter($paramsNew);

				foreach ($params as $key => $val)
				{
					switch ($val)
					{
						case 'nohtml':
							$retval[$key] = htmlspecialchars($retval[$key]);
							break;

						case 'unixtime':

							if (is_array($val))
							{
								if ($val['month'] AND $val['day'] AND $val['year'])
								{
									$val = mktime(intval($val['hour']), intval($val['minute']), intval($val['second']), intval($val['month']), intval($val['day']), intval($val['year']));
								}
								else
								{
									$val = 0;
								}
							}
							else
							{
								$val = ($val = intval($val)) < 0 ? 0 : $val;
							}

							$retval[$key] = $val;
							break;
					}
				}

				return $retval;
				break;

			case 'vBulletin':
				$cleaned = array();

				$GLOBALS['vbulletin']->input->clean_array_gpc('r', $params);
				foreach ($params as $key => $const)
				{
					// Because vB doesn't like to just return the cleaned array -.-
					$cleaned[$key] = $GLOBALS['vbulletin']->GPC[$key];
				}

				return $cleaned;
				break;
		}
	}

	public static function renderTemplate($templateName, array $params = array())
	{
		$params = array_merge(self::getParams($templateName), $params);

		switch (self::getSystem())
		{
			case 'XenForo':
				self::preRenderView();
				return self::$fc->getDependencies()->createTemplateObject($templateName, $params)->render();
				break;

			case 'vBulletin':
				// Finish the main template
				$templater = vB_Template::create($templateName);
				foreach ($params as $param => $val)
				{
					$templater->register($param, $val);
				}
				return $templater->render();
				break;
		}
	}

	public static function renderOutput($innerContent, array $params = array(), $selectedTabId = 'forums')
	{
		$params = array_merge(self::getParams('output'), $params);

		switch (self::getSystem())
		{
			case 'XenForo':
				// Set selected tab
				$params['majorSection'] = $selectedTabId;

				self::preRenderView();
				$viewRenderer = self::$fc->getDependencies()->getViewRenderer(self::$fc->getResponse(), 'Html', self::$fc->getRequest());
				$containerParams = self::$fc->getDependencies()->getEffectiveContainerParams($params, self::$fc->getRequest());

				$content = $viewRenderer->renderContainer($innerContent, $containerParams);

				if (preg_match('#<head[^>]*>#sU', $content, $match))
				{
					$content = str_replace($match[0], $match[0] . '<base href="' . XenForo_Application::get('options')->boardUrl . '/" />', $content);
				}

				$bufferedContents = ob_get_contents();
				@ob_end_clean();
				if ($bufferedContents !== '' && is_string($content))
				{
					if (preg_match('#<body[^>]*>#sU', $content, $match))
					{
						$content = str_replace($match[0], $match[0] . $bufferedContents, $content);
					}
					else
					{
						$content = $bufferedContents . $content;
					}
				}

				$headers = self::$fc->getResponse()->getHeaders();
				$isText = false;
				foreach ($headers AS $header)
				{
					if ($header['name'] == 'Content-Type')
					{
						if (strpos($header['value'], 'text/') === 0)
						{
							$isText = true;
						}
						break;
					}
				}
				if ($isText && is_string($content) && $content)
				{
					$extraHeaders = XenForo_Application::gzipContentIfSupported($content);
					foreach ($extraHeaders AS $extraHeader)
					{
						self::$fc->getResponse()->setHeader($extraHeader[0], $extraHeader[1], $extraHeader[2]);
					}
				}

				if (is_string($content) && $content && !ob_get_level() && XenForo_Application::get('config')->enableContentLength)
				{
					if (self::$fc->getResponse()->getHttpResponseCode() >= 400
						&& strpos(self::$fc->getRequest()->getServer('HTTP_USER_AGENT', ''), 'IEMobile') !== false
					)
					{
						// Windows mobile bug - 400+ errors cause the standard browser error
						// to be output if a content length is sent. ...Err, what?
					}
					else
					{
						self::$fc->getResponse()->setHeader('Content-Length', strlen($content), true);
					}
				}

				self::$fc->getResponse()->sendHeaders();

				echo $content;
				break;

			case 'vBulletin':
				print_output($innerContent);
				break;
		}

		exit;
	}

	public static function link($url)
	{
		return $url;
	}

	public static function profileLink($user)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				return XenForo_Link::buildPublicLink('members', $user);
				break;

			case 'vBulletin':
				return 'member.php?u=' . $user['userid'];
				break;
		}
	}

	public static function downloadFile($output, $fileName, $mimeType)
	{
		self::$fc->getResponse()->setHeader('Content-type', $mimeType, true);
		self::$fc->getResponse()->setHeader('Content-Disposition', 'attachment; filename="' . str_replace('"', '', $fileName) . '"', true);
		self::$fc->getResponse()->sendHeaders();
		echo $output;
		die();
	}

	public static function fetchBitfield($bitfield)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				// Parse CPNav file
				$document = XenForo_Helper_DevelopmentXml::scanFile('includes/xml/bitfield_dbtech_vbshout.xml');

				$keys = preg_split('#\|#si', $bitfield, -1, PREG_SPLIT_NO_EMPTY);

				$retval = array();
				foreach ($document->xpath("//group[@name='" . $keys[0] . "']/group[@name='" . $keys[1] . "']/bitfield") as $bitfield)
				{
					$retval[(string)$bitfield['name']] = (int)$bitfield[0];
				}

				return $retval ? $retval : NULL;
				break;

			case 'vBulletin':
				// Ensure we can fetch bitfields
				require_once(DIR . '/includes/adminfunctions_options.php');
				return fetch_bitfield_definitions($bitfield);
				break;
		}
	}

	public static function isMemberOf(array $user, $userGroupId, $multipleIds = null)
	{
		if (!is_null($multipleIds))
		{
			// check multiple groups
			$userGroupId = array_slice(func_get_args(), 1);
		}

		switch (self::getSystem())
		{
			case 'XenForo':
				$userModel = self::createModel('XenForo_Model_User');
				return $userModel->isMemberOfUserGroup($user, $userGroupId);
				break;

			case 'vBulletin':
				return is_member_of($user, $userGroupId);
				break;
		}
	}

	/**
	* Escapes a string and makes it JavaScript-safe
	*
	* @param	mixed	The string or array to make JS-safe
	*/
	public static function jsEscapeString(&$arr)
	{
		$find = array(
			"\r\n",
			"\n",
			"\t",
			'"'
		);

		$replace = array(
			'\r\n',
			'\n',
			'\t',
			'\"',
		);

		$arr = str_replace($find, $replace, $arr);
	}

	/**
	* Encodes a string as a JSON object (consistent behaviour instead of relying on PHP built-in functions)
	*
	* @param	mixed	The string or array to encode
	* @param	boolean	(Optional) Whether this is an associative array
	* @param	boolean	(Optional) Whether we should escape the string or if they have already been escaped
	*/
	public static function encodeJSON($arr, $assoc = true, $doescape = true)
	{
		if ($doescape)
		{
			self::jsEscapeString($arr);
		}
		if (!$assoc)
		{
			// Not associative, simple return
			return '{"' . implode('","', $arr) . '"}';
		}

		$content = array();
		foreach ((array)$arr as $key => $val)
		{
			if (is_array($val))
			{
				// Recursion, definition: see recursion
				$val = self::encodeJSON($val);
				$content[] = '"' . $key . '":' . $val;
			}
			else
			{
				$content[] = '"' . $key . '":"' . $val . '"';
			}
		}

		return '{' . implode(',', $content) . '}';
	}

	protected static function preRenderView()
	{
		if (!self::$hasPreRendered)
		{
			self::$fc->getDependencies()->preRenderView();
			self::$hasPreRendered = true;
		}
	}

	protected static function createModel($class)
	{
		if (!isset(self::$_modelCache[$class]))
		{
			self::$_modelCache[$class] = XenForo_Model::create($class);
		}

		return self::$_modelCache[$class];
	}
}
?>