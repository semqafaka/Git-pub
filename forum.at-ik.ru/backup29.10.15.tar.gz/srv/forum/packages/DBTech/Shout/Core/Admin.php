<?php
class DBTech_Shout_Core_Admin extends DBTech_Shout_Core
{
	public static function init($isHook = false)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				chdir('../');

				$startTime = microtime(true);
				$fileDir = '.';

				if (!$isHook)
				{
					require_once($fileDir . '/library/XenForo/Autoloader.php');
					XenForo_Autoloader::getInstance()->setupAutoloader($fileDir . '/library');

					XenForo_Application::initialize($fileDir . '/library', $fileDir);
					XenForo_Application::set('page_start_time', $startTime);

					self::$fc = new XenForo_FrontController(new XenForo_Dependencies_Admin());

					ob_start();

					XenForo_Application::set('fc', self::$fc);

					self::$fc->setup();
					self::$fc->setRequestPaths();
					self::$fc->getDependencies()->preLoadData();

					if (!XenForo_Application::isRegistered('session'))
					{
						XenForo_Session::startAdminSession(self::$fc->getRequest());
					}
				}
				else
				{
					self::$fc = XenForo_Application::get('fc');
				}

				// Set the version number
				self::$versionnumber = XenForo_Application::$version;

				$visitor = XenForo_Visitor::getInstance()->toArray();
				self::$userinfo = $visitor;
				self::$userinfo['userid'] =& self::$userinfo['user_id'];
				self::$userinfo['usergroupid'] =& self::$userinfo['user_group_id'];
				self::$userinfo['membergroupids'] =& self::$userinfo['secondary_group_ids'];
				if (!$visitor['is_admin'])
				{
					self::renderOutput(self::renderTemplate('login_form'));
					die();
				}

				// Shorthand
				$db = XenForo_Application::getDb();

				// Pre-cache phrases
				XenForo_Phrase::setPhrases($db->fetchPairs('
					SELECT title, phrase_text
					FROM xf_phrase_compiled
					WHERE language_id = ?
						AND title LIKE \'dbtech_vbshout_%\'
				', self::$userinfo['language_id'] ? self::$userinfo['language_id'] : self::option('defaultLanguageId')));

				// Set a few required things
				XenForo_Template_Admin::setLanguageId(self::$userinfo['language_id'] ? self::$userinfo['language_id'] : self::option('defaultLanguageId'));

				// Set usergroup cache
				self::$usergroupcache = XenForo_Model::create('XenForo_Model_UserGroup')->getAllUserGroups();
				foreach (self::$usergroupcache as $key => $arr)
				{
					// Make it usable with vB code
					self::$usergroupcache[$key]['usergroupid'] =& self::$usergroupcache[$key]['user_group_id'];
				}

				// Set forum cache
				self::$forumcache = XenForo_Model::create('XenForo_Model_Node')->getAllNodes();
				foreach (self::$forumcache as $key => $arr)
				{
					// Make it usable with vB code
					self::$forumcache[$key]['forumid'] =& self::$forumcache[$key]['node_id'];
				}

				// Init DB
				self::$db = new DBTech_Shout_Database($db);

				// Ensure this is set
				self::$_input = new XenForo_Input(self::$fc->getRequest());

				// Define important constants
				define('TYPE_ARRAY', 		XenForo_Input::ARRAY_SIMPLE);
				define('TYPE_UINT', 		XenForo_Input::UINT);
				define('TYPE_INT', 			XenForo_Input::INT);
				define('TYPE_UNUM', 		XenForo_Input::UNUM);
				define('TYPE_NUM', 			XenForo_Input::NUM);
				define('TYPE_STR', 			XenForo_Input::STRING);
				define('TYPE_BOOL', 		XenForo_Input::BOOLEAN);
				define('TYPE_UNIXTIME', 	'unixtime');
				define('TYPE_NOHTML', 		'nohtml');
				break;

			case 'vBulletin':
				// Set the version number
				self::$versionnumber = $GLOBALS['vbulletin']->versionnumber;

				// Set caches
				self::$userinfo =& $GLOBALS['vbulletin']->userinfo;
				self::$usergroupcache = $GLOBALS['vbulletin']->usergroupcache;
				self::$forumcache = $GLOBALS['vbulletin']->forumcache;

				// Init DB
				self::$db = new DBTech_Newsletter_Database($GLOBALS['vbulletin']->db);
				break;
		}
	}

	public static function getSystem()
	{
		if (!isset(self::$system) OR !self::$system OR self::$system === NULL)
		{
			self::$system = is_dir('../library/XenForo') ? 'XenForo' : 'vBulletin';
		}

		return parent::getSystem();
	}

	public static function runAction()
	{
		// Default value
		$class = 'abstract';

		if (isset($_POST['do']) AND !empty($_POST['do']))
		{
			// $_POST requests take priority
			$class = $_POST['do'];
		}
		else if (isset($_GET['do']) AND !empty($_GET['do']))
		{
			// We had a GET request instead
			$class = $_GET['do'];
		}

		// Strip non-valid characters
		$class = preg_replace('/[^\w-_]/i', '', implode('_', array_map('ucfirst', explode('/', strtolower($class)))));

		if (!$class)
		{
			// No request
			$class = 'abstract';
		}

		// Shorthand
		$class = 'DBTech_Shout_Action_Admin_' . ucfirst($class);

		try
		{
			if (!class_exists($class))
			{
				// Action class didn't exist
				throw new Exception("Class <b>$class</b> cannot be found.");
			}

			// Default value
			$method = 'index';

			if (isset($_POST['action']) AND !empty($_POST['action']))
			{
				// $_POST requests take priority
				$method = $_POST['action'];
			}
			else if (isset($_GET['action']) AND !empty($_GET['action']))
			{
				// We had a GET request instead
				$method = $_GET['action'];
			}

			// Strip non-valid characters
			$method = preg_replace('/[^\w-]/i', '', strtolower($method));

			$reflection = new ReflectionClass($class);
			if (!$method OR $reflection->isAbstract())
			{
				// No request
				$method = 'index';
			}

			// Shorthand
			$method = 'action' . ucfirst($method);

			if (!method_exists($class, $method))
			{
				// Action class didn't exist
				throw new Exception("Method <b>$method</b> cannot be found in <b>$class</b>.");
			}

			// Shorthand
			$class::$method();

			print_cp_footer();
		}
		catch (Exception $e)
		{
			// Trigger error
			self::error($e->getMessage());
		}
	}

	public static function error($message)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				self::renderOutput($message);
				break;

			case 'vBulletin':
				print_cp_message($message);
				break;
		}
	}

	public static function redirect($message, $url)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				header('Location: ' . $url);
				die();
				break;

			case 'vBulletin':
				print_cp_message($message, $url);
				break;
		}
	}

	public static function link($url)
	{
		switch (self::getSystem())
		{
			case 'XenForo':
				$url = 'admincp/' . $url;
				break;
		}

		return $url;
	}

	public static function renderOutput($innerContent, array $params = array())
	{
		$params = array_merge(self::getParams('output'), $params);

		switch (self::getSystem())
		{
			case 'XenForo':
				// hacks
				$params['majorSection'] = 'applications';

				self::preRenderView();
				$viewRenderer = self::$fc->getDependencies()->getViewRenderer(self::$fc->getResponse(), 'Html', self::$fc->getRequest());
				$containerParams = self::$fc->getDependencies()->getEffectiveContainerParams($params, self::$fc->getRequest());

				$content = $viewRenderer->renderContainer($innerContent, $containerParams);

				if (preg_match('#<head[^>]*>#sU', $content, $match))
				{
					$content = str_replace($match[0], $match[0] . '<base href="' . XenForo_Application::get('options')->boardUrl . '/" />', $content);
				}

				$bufferedContents = ob_get_contents();
				@ob_end_clean();
				if ($bufferedContents !== '' && is_string($content))
				{
					if (preg_match('#<body[^>]*>#sU', $content, $match))
					{
						$content = str_replace($match[0], $match[0] . $bufferedContents, $content);
					}
					else
					{
						$content = $bufferedContents . $content;
					}
				}

				$headers = self::$fc->getResponse()->getHeaders();
				$isText = false;
				foreach ($headers AS $header)
				{
					if ($header['name'] == 'Content-Type')
					{
						if (strpos($header['value'], 'text/') === 0)
						{
							$isText = true;
						}
						break;
					}
				}
				if ($isText && is_string($content) && $content)
				{
					$extraHeaders = XenForo_Application::gzipContentIfSupported($content);
					foreach ($extraHeaders AS $extraHeader)
					{
						self::$fc->getResponse()->setHeader($extraHeader[0], $extraHeader[1], $extraHeader[2]);
					}
				}

				if (is_string($content) && $content && !ob_get_level() && XenForo_Application::get('config')->enableContentLength)
				{
					if (self::$fc->getResponse()->getHttpResponseCode() >= 400
						&& strpos(self::$fc->getRequest()->getServer('HTTP_USER_AGENT', ''), 'IEMobile') !== false
					)
					{
						// Windows mobile bug - 400+ errors cause the standard browser error
						// to be output if a content length is sent. ...Err, what?
					}
					else
					{
						self::$fc->getResponse()->setHeader('Content-Length', strlen($content), true);
					}
				}

				self::$fc->getResponse()->sendHeaders();

				echo $content;
				break;

			case 'vBulletin':
				break;
		}

		exit;
	}
}
?>