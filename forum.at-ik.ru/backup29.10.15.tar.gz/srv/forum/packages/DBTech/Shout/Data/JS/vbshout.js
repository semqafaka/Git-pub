
(function($){jQuery.fn.vBShout=function(option)
{return this.each(function()
{var $obj=$(this);var data=$obj.data('vbshout');if(!data)
{$obj.data('vbshout',(data=new vBShout(this,option)));}});};var vBShout=function(element,options)
{this.$el=$(element);this.$editor=$('.shoutboxEditorInput',this.$el);this.instanceId=this.$el.data('instanceid');this.opts=$.extend({buttons:['bold','italic','underline','fontcolor','fontsize','fontfamily'],toolbars:{fontcolor:'show',fontsize:'show',fontfamily:'show',bold:'exec',italic:'exec',underline:'exec'},colors:['#ffffff','#ff9999','#ffcc99','#ffff99','#ccff99','#99ff99','#99ffcc','#99ffff','#99ccff','#9999ff','#cc99ff','#ff99ff','#ff99cc','#bfbfbf','#ff4d4d','#ffa64d','#ffff4d','#a6ff4d','#4dff4d','#4dffa6','#4dffff','#4da6ff','#4d4dff','#a64dff','#ff4dff','#ff4da6','#808080','#ff0000','#ff8000','#ffff00','#80ff00','#00ff00','#00ff80','#00ffff','#0080ff','#0000ff','#8000ff','#ff00ff','#ff0080','#404040','#b30000','#b35900','#b3b300','#59b300','#00b300','#00b359','#00b3b3','#0059b3','#0000b3','#5900b3','#b300b3','#b30059','#000000','#660000','#663300','#666600','#336600','#006600','#006633','#006666','#003366','#000066','#330066','#660066','#660033'],fonts:['Arial','Arial Black','Arial Narrow','Book Antiqua','Century Gothic','Comic Sans MS','Courier New','Fixedsys','Franklin Gothic Medium','Garamond','Georgia','Impact','Lucida Console','Lucida Sans Unicode','Microsoft Sans Serif','Palatino Linotype','System','Tahoma','Times New Roman','Trebuchet MS','Verdana'],sizes:['9px','11px','13px','15px','17px','21px',],colorWidth:247,phrases:{},editorOptions:{},instanceOptions:{},instancePermissions:{},bbcodePermissions:{},userOptions:{},soundSettings:{},tabs:{}},options,this.$el.data());this.paused=false;this.tab='shouts';this.tabList={shouts:true,activeusers:true};this.pmTime=this.opts.userOptions.pmtime;this.aopTime={shouts:parseInt(new Date().getTime()/1000)};this.menuId=0;this.editorContents='';this.shoutDelay=0;this.idleTime=0;this.countDown=1;this.hasFetched=false;this.pmUserId=0;this.userIds={};this.shoutId=0;this.chatroom=0;this.init();this.setMuteButton();this.setInvisibleButton();this.$editor.trigger('keyup');if(this.opts.userOptions.archive==0)
{setInterval($.proxy(function()
{if(!$('.shoutboxNotice',this.$el).length)
{return true;}
if(this.shoutDelay>0)
{this.shoutDelay--;}
if(this.opts.instanceOptions.unIdle)
{console.log(this.timeStamp()+"Removing idle for instance %s.",this.instanceId);$('.shoutboxNotice',this.$el).fadeOut('fast');$('.shoutboxActiveImage',this.$el).removeClass('shoutboxSprite-user-offline').addClass('shoutboxSprite-user-online');if(this.opts.instanceOptions.invisible=='0'&&this.opts.instanceOptions.forceUnIdle)
{this.ajaxCall('unidle',{});}
this.idleTime=0;if(this.opts.instanceOptions.unPause)
{this.paused=false;this.countDown=1;}
this.opts.instanceOptions.unIdle=false;this.opts.instanceOptions.unPause=false;}
if(this.paused==true)
{return true;}
this.idleTime++;if(this.idleTime>=this.opts.instanceOptions.idletimeout&&this.opts.instancePermissions.idleexempt==0&&this.opts.instanceOptions.idletimeout>0||(!this.hasFetched&&this.opts.instancePermissions.autoidle))
{this.paused=true;this.setMessage(this.opts.phrases.dbtech_vbshout_flagged_idle,'Notice');$('.shoutboxActiveImage',this.$el).removeClass('shoutboxSprite-user-online').addClass('shoutboxSprite-user-offline');if(!this.hasFetched)
{this.fetchShouts('shouts',true);}
return true;}
if(--this.countDown>0)
{}
else
{if(!this.hasFetched)
{this.fetchShouts('shouts',true);this.hasFetched=true;}
else
{this.fetchShouts();}}},this),1000);}};vBShout.prototype={init:function(){if(typeof AJAX_Compatible!='undefined'&&!AJAX_Compatible)
{this.setMessage(this.opts.phrase.dbtech_vbshout_ajax_disabled,'Error');return false;}
if(typeof $.fn.xfActivate=='function')
{$.each(this.opts.buttons,$.proxy(function(i,key)
{var button=$('.redactor_btn_'+key);button.attr({unselectable:'on',tabindex:-1}).on('dragstart',function(e){e.preventDefault();});if(this.opts.toolbars[key]=='show')
{var dropdown=$('<div class="redactor_dropdown" style="display: none;">');switch(key)
{case'fontcolor':$(dropdown).width(this.opts.colorWidth);var len=this.opts.colors.length;for(var i=0;i<len;++i)
{var color=this.opts.colors[i];var swatch=$('<a rel="'+color+'" href="javascript:void(null);" class="redactor_color_link" unselectable="on"></a>').css({'backgroundColor':color});$(dropdown).append(swatch);}
$(dropdown).append($('<a href="javascript:void(null);" class="redactor_color_none" rel="" unselectable="on"></a>').html(this.opts.phrases.dbtech_vbshout_none));dropdown.appendTo($(document.body));this.hdlShowDropDown=$.proxy(function(e){this.showDropDown(e,dropdown,key);},this);button.click(this.hdlShowDropDown);break;case'fontfamily':var len=this.opts.fonts.length;for(var i=0;i<len;++i)
{var font=this.opts.fonts[i];var swatch=$('<a rel="'+font+'" href="javascript:void(null);" class="redactor_font_link" unselectable="on">'+font+'</a>').css({'fontFamily':font});$(dropdown).append(swatch);}
$(dropdown).append($('<a href="javascript:void(null);" class="redactor_font_none" rel="" unselectable="on"></a>').html(this.opts.phrases.dbtech_vbshout_none));dropdown.appendTo($(document.body));this.hdlShowDropDown=$.proxy(function(e){this.showDropDown(e,dropdown,key);},this);button.click(this.hdlShowDropDown);break;case'fontsize':var len=this.opts.sizes.length;for(var i=0;i<len;++i)
{var size=this.opts.sizes[i];var swatch=$('<a rel="'+size+'" href="javascript:void(null);" class="redactor_size_link" unselectable="on">'+size+'</a>').css({'fontSize':size});$(dropdown).append(swatch);}
$(dropdown).append($('<a href="javascript:void(null);" class="redactor_size_none" rel="" unselectable="on"></a>').html(this.opts.phrases.dbtech_vbshout_none));dropdown.appendTo($(document.body));this.hdlShowDropDown=$.proxy(function(e){this.showDropDown(e,dropdown,key);},this);button.click(this.hdlShowDropDown);break;}}},this));}
$.each(this.opts.tabs,$.proxy(function(i,tab)
{this.createTab(i,tab.text,tab.canclose,tab.extraparams);},this));this.$editor.on('keyup focus',$.proxy(function(e)
{if(this.opts.instanceOptions.maxchars==0)
{if(this.$editor.val().length)
{this.editorContents=this.$editor.val();}
return true;}
if(this.$editor.val().length>this.opts.instanceOptions.maxchars)
{this.$editor.val(this.$editor.val().substring(0,this.opts.instanceOptions.maxchars));}
if(this.$editor.val().length)
{this.editorContents=this.$editor.val();}
$('.shoutboxEditorRemaining',this.$el).text((this.opts.instanceOptions.maxchars-this.$editor.val().length));},this));this.$editor.on('keyup',$.proxy(function(e)
{e.preventDefault();if(e.which==27&&this.shoutId)
{$('.shoutboxEditorCancelBtn',this.$el).trigger('click');}
if(e.which==13)
{$('.shoutboxEditorSaveBtn',this.$el).trigger('click');}},this));$('.shoutboxNotice',this.$el).on('click','.shoutboxUnIdle',$.proxy(function(e)
{this.unIdle(false,'unidle');},this));$('.shoutboxEditorClearBtn',this.$el).on('click',$.proxy(function(e)
{this.$editor.val('');},this));$('.shoutboxEditorSaveBtn',this.$el).on('click',$.proxy(function(e)
{if(this.shoutId&&this.$editor.val()==$('.shoutboxRawShout[data-shoutid="'+this.shoutId+'"]',this.$el).val())
{$('.shoutboxEditorCancelBtn',this.$el).trigger('click');return true;}
this.saveShout();},this));$('.shoutboxEditorDeleteBtn',this.$el).on('click',$.proxy(function(e)
{if(!this.shoutId||this.shoutId=='0')
{return false;}
this.deleteShout(this.shoutId);},this));$('.shoutboxEditorCancelBtn',this.$el).on('click',$.proxy(function(e)
{this.paused=false;this.shoutId=0;this.$editor.val('');this.$editor.trigger('keyup');$('.shoutboxEditorCancelBtn',this.$el).fadeOut('fast');$('.shoutboxEditorDeleteBtn',this.$el).fadeOut('fast');$('.shoutboxTargetEditing',this.$el).fadeOut('fast').promise().done($.proxy(function(e)
{$('.shoutboxTarget',this.$el).fadeIn('fast');},this));},this));$('.shoutboxEditorLookupBtn',this.$el).on('click',$.proxy(function(e)
{var lookupArea=$('.shoutboxLookupInput',this.$el),userName=lookupArea.val();if(userName.length==0)
{return false;}
console.log(this.timeStamp()+'Attempting to lookup username: %s in instance %s...',userName,this.instanceId);this.paused=true;this.unIdle(false,'lookup');if(typeof this.userIds!='undefined')
{var userId=0;for(var i in this.userIds)
{if(this.userIds[i]!=userName)
{continue;}
userId=i;}
if(userId>0)
{this.createTab('pm_'+userId+'_'+this.instanceId,userName,'1',{'userid':userId});lookupArea.val('');return true;}}
this.ajaxCall('lookup',{'username':encodeURIComponent($.trim(userName))},'GET');},this));$('.shoutboxResetTarget',this.$el).on('click',$.proxy(function(e)
{console.log(this.timeStamp()+'Resetting shout target in instance %s...',this.instanceId);this.pmUserId=0;this.setShoutTarget(false);$('.shoutboxTab[data-tabid="shouts"]',this.$el).trigger('click');},this));$('.shoutboxCreateChatButton',this.$el).on('click',$.proxy(function(e)
{var chatroomName=$('.shoutboxChatRoomName',$('#ShoutboxCreateChatMenu'+this.instanceId)).val();if(chatroomName.length==0)
{return false;}
console.log(this.timeStamp()+'Attempting to create chatroom: %s in instance %s...',chatroomName,this.instanceId);this.paused=true;this.unIdle(false,'createchat');this.ajaxCall('createchat',{'title':encodeURIComponent($.trim(chatroomName))});},this));$('.shoutboxSoundImage',this.$el).on('click',$.proxy(function(e)
{this.opts.soundSettings[this.tab]=this.opts.soundSettings[this.tab]||'1';this.opts.soundSettings[this.tab]=(this.opts.soundSettings[this.tab]=='1'?'0':'1');this.setMuteButton();console.log(this.timeStamp()+'Toggle mute in instance %s...',this.instanceId);this.paused=true;this.unIdle(false,'savesounds');this.ajaxCall('sounds',{'tabs':this.opts.soundSettings});},this));$('.shoutboxActiveImageEnabled',this.$el).on('click',$.proxy(function(e)
{this.opts.instanceOptions.invisible=(this.opts.instanceOptions.invisible=='1'?'0':'1');this.setInvisibleButton();console.log(this.timeStamp()+'Toggle invisible in instance %s...',this.instanceId);this.paused=true;this.ajaxCall('invisible',{'invisibility':this.opts.instanceOptions.invisible});},this));$('.shoutboxEditorImageButton',this.$el).on('click mouseover mouseout',$.proxy(function(e)
{var thisButton=$(e.target),name=thisButton.data('button');if(thisButton.hasClass('imagebutton_disabled'))
{return false;}
thisButton.removeClass('imagebutton_selected imagebutton_hover imagebutton_down redactor_act');switch(this.opts.editorOptions[name])
{case null:case false:case'':case'0':case'false':case'null':switch(e.type)
{case'mouseover':thisButton.addClass('imagebutton_hover');break;case'mouseout':thisButton.removeClass('imagebutton_hover');break;case'click':thisButton.addClass('imagebutton_down redactor_act');this.saveStyleProps(name,name);break;}
break;default:switch(e.type)
{case'mouseover':thisButton.addClass('imagebutton_hover').addClass('imagebutton_down redactor_act');break;case'mouseout':thisButton.removeClass('imagebutton_hover').addClass('imagebutton_selected redactor_act');break;case'click':thisButton.addClass('imagebutton_hover');this.saveStyleProps(name,'');break;}
break;}},this));$('.shoutboxEditorImageButton',this.$el).each($.proxy(function(index,element)
{var thisButton=$(element),name=thisButton.data('button');if(this.opts.editorOptions[name]&&this.opts.editorOptions[name]!='0')
{thisButton.trigger('mouseout');this.saveStyleProps(name,this.opts.editorOptions[name],true);}},this));$(document).on('click','a[class^="redactor_color"]',$.proxy(function(e){this.saveStyleProps('color',$(e.target).attr('rel'));},this));$(document).on('click','a[class^="redactor_font"]',$.proxy(function(e){this.saveStyleProps('font',$(e.target).attr('rel'));},this));$(document).on('click','a[class^="redactor_size"]',$.proxy(function(e){this.saveStyleProps('size',$(e.target).attr('rel'));},this));$(document).on('click','.shoutboxEditorSetCommand',$.proxy(function(e)
{var cmd=$(e.target);console.log(cmd);this.closeMenu(cmd);this.$editor.val(cmd.data('command'));},this));$(document).on('click','.shoutboxEditorUserManage',$.proxy(function(e)
{var cmd=$(e.target),action=cmd.data('command'),userId=cmd.data('userid');if(confirm(this.opts.phrases['dbtech_vbshout_are_you_sure_'+action]))
{console.log(this.timeStamp()+'Attempting to perform action %s on userid %s, instance id %s...',action,userId,this.instanceId);this.closeMenu(cmd);var extraParams={};if(this.pmUserId)
{extraParams.type='pm_'+this.pmUserId+'_';}
else if(this.chatroom)
{extraParams.type='chatroom_'+this.chatroom+'_';}
extraParams.manageaction=action;extraParams.userid=userId;this.paused=true;this.unIdle(true,'usermanage');this.ajaxCall('usermanage',extraParams);}},this));$(document).on('click','.shoutboxEditorCreatePm',$.proxy(function(e)
{var cmd=$(e.target),userName=cmd.data('username'),userId=cmd.data('userid');this.closeMenu(cmd);this.userIds[userId]=userName;this.createTab('pm_'+userId+'_'+this.instanceId,userName,'1',{'userid':userId});$('.shoutboxTab[data-tabid="pm_'+userId+'_'+this.instanceId+'"]',this.$el).trigger('click');},this));$(document).on('click','.shoutboxEditorEditShout',$.proxy(function(e)
{var cmd=$(e.target),instanceId=cmd.data('instanceid'),shoutid=cmd.data('shoutid');if(!shoutid)
{return false;}
this.closeMenu(cmd);this.beginShoutEdit(shoutid);},this));$(document).on('click','.shoutboxEditorDeleteShout',$.proxy(function(e)
{var cmd=$(e.target),instanceId=cmd.data('instanceid'),shoutid=cmd.data('shoutid');if(!shoutid)
{return false;}
this.closeMenu(cmd);this.deleteShout(shoutid);},this));this.$el.on('dblclick','.shoutboxSticky',$.proxy(function(e)
{if(this.opts.instancePermissions.cansticky=='0')
{return true;}
console.log(this.timeStamp()+'Fetching sticky for instance %s...',this.instanceId);this.paused=true;this.unIdle(false,'fetchsticky');this.ajaxCall('fetchsticky',{},'GET');},this));this.$el.on('click','.shoutboxCloseTab',$.proxy(function(e)
{var closeLink=$(e.target),tabId=closeLink.data('tabid'),chatroomId=closeLink.parent().data('chatroomid');e.preventDefault();if(chatroomId)
{if(!confirm(this.opts.phrases.dbtech_vbshout_are_you_sure_chatleave))
{return false;}
console.log(this.timeStamp()+'Closing tab: %s in instance %s...',tabId,this.instanceId);this.paused=true;this.unIdle(false,'leavechat');this.ajaxCall('leavechat',{'chatroomid':chatroomId});}
this.closeTab(tabId);},this));this.$el.on('click','.shoutboxTab',$.proxy(function(e)
{var thisTab=$(e.target),tabId=thisTab.data('tabid'),userId=thisTab.data('userid'),chatroomId=thisTab.data('chatroomid');if(this.tab==tabId||e.isDefaultPrevented())
{return false;}
console.log(this.timeStamp()+"Switching from %s to %s for instance %s.",this.tab,tabId,this.instanceId);if(thisTab.data('loadurl'))
{window.location.href=thisTab.data('loadurl');return false;}
this.pmUserId=(userId!=''?userId:0);this.chatroom=(chatroomId!=''?chatroomId:0);this.setShoutTarget((userId!=''?this.userIds[userId]:false));this.chatroom?$('.shoutboxChatInvite',this.$el).fadeIn('fast'):$('.shoutboxChatInvite',this.$el).fadeOut('fast');$('.shoutboxTab[data-tabid="'+this.tab+'"]',this.$el).parent().removeClass('active');thisTab.removeClass('dbtech_vbshout_highlight').parent().addClass('active');this.tab=tabId;this.setMuteButton();$('.shoutboxShoutListFrame > ul').text('');this.paused=true;this.unIdle(false,'tabswitch');this.fetchShouts(this.tab,true);return false;},this));this.$el.on('dblclick','.shoutboxShoutMessageEditable',$.proxy(function(e)
{var cmd=$(e.target),shoutid=cmd.data('shoutid');if(!shoutid)
{return true;}
this.beginShoutEdit(shoutid);},this));},showDropDown:function(e,dropdown,key,s)
{var btn=this.getBtn(key);if(btn.hasClass('dropact'))
{this.hideAllDropDown();}
else
{this.hideAllDropDown();this.setBtnActive(key);btn.addClass('dropact');var offset=btn.offset(),left=offset.left,windowWidth=$(window).width(),dropdownWidth=$(dropdown).outerWidth();if(left+dropdownWidth>windowWidth)
{left=Math.max(left-dropdownWidth+this.getBtn(key).outerWidth(),0);}
if(this.opts.air)
{var air_top=this.air.offset().top;$(dropdown).css({position:'absolute',left:left+'px',top:air_top+30+'px'}).show();}
else if(this.opts.fixed&&this.fixed)
{$(dropdown).css({position:'fixed',left:left+'px',top:'30px'}).show();}
else
{var top=offset.top+btn.outerHeight();$(dropdown).css({position:'absolute',left:left+'px',top:top+'px'}).show();}}
var hdlHideDropDown=$.proxy(function(e){this.hideDropDown(e,dropdown,key);},this);$(document).one('click',hdlHideDropDown);this.$el.one('click',hdlHideDropDown);e.stopPropagation();},hideAllDropDown:function()
{this.$el.find('a.dropact').removeClass('redactor_act').removeClass('dropact');$('.redactor_dropdown').hide();},hideDropDown:function(e,dropdown,key)
{if(!$(e.target).hasClass('dropact'))
{$(dropdown).removeClass('dropact');this.showedDropDown=false;this.hideAllDropDown();}},getBtn:function(key)
{if(this.opts.toolbar===false)
{return false;}
return $(this.$el.find('a.redactor_btn_'+key));},setBtnActive:function(key)
{if(this.opts.toolbar===false)
{return;}
this.getBtn(key).addClass('redactor_act');},unIdle:function(keepPause,unIdleAction)
{this.opts.instanceOptions.unIdle=true;this.opts.instanceOptions.unPause=(keepPause?false:true);this.opts.instanceOptions.forceUnIdle=true;return false;},setShoutTarget:function(username)
{var everyone=$('.shoutTargetEveryone',this.$el);if(everyone.length)
{if(!username)
{everyone.html(this.opts.phrases.dbtech_vbshout_everyone);}
else
{everyone.html($.trim(username));}}},closeMenu:function(source)
{if(this.menuId)
{$('.shoutboxMenu[data-userid="'+this.menuId+'"]',this.$el).fadeOut('fast');this.menuId=0;}
else
{$('.OverlayCloser',source.closest('.memberCard')).trigger('click');}},createTab:function(tabId,tabText,canClose,extraParams)
{if(this.tabList[tabId])
{$('.shoutboxTab[data-tabid="'+tabId+'"]',this.$el).trigger('click');return false;}
this.tabList[tabId]=true;$('.tabs',this.$el).append('<li><a class="shoutboxTab" data-tabid="'+tabId+'">'+tabText+(canClose=='1'?' [<span class="shoutboxCloseTab" data-tabid="'+tabId+'">X</span>]':'')+'</a></li>');if(typeof extraParams=='undefined')
{return true;}
var newTab=$('.shoutboxTab[data-tabid="'+tabId+'"]',this.$el);for(var i in extraParams)
{newTab.data(''+i,extraParams[i]);}
return true;},closeTab:function(tabId)
{this.tabList[tabId]=false;if(this.tab==tabId)
{console.log(this.timeStamp()+"Attempting to switch from %s to %s for instance %s.",this.tab,'shouts',this.instanceId);$('.shoutboxTab[data-tabid="shouts"]',this.$el).trigger('click');}
$('.shoutboxTab[data-tabid="'+tabId+'"]',this.$el).parent().remove();return true;},beginShoutEdit:function(shoutid)
{this.paused=true;this.shoutId=shoutid;this.$editor.val($('.shoutboxRawShout[data-shoutid="'+shoutid+'"]',this.$el).val());this.$editor.trigger('keyup');$('.shoutboxTarget',this.$el).fadeOut('fast').promise().done($.proxy(function(e)
{$('.shoutboxEditorDeleteBtn',this.$el).fadeIn('fast');$('.shoutboxEditorCancelBtn',this.$el).fadeIn('fast');$('.shoutboxTargetEditing',this.$el).fadeIn('fast');},this));},deleteShout:function(shoutid)
{console.log(this.timeStamp()+'Attempting to delete shout: %s... in instance %s',shoutid,this.instanceId);var extraParams={};if(this.pmUserId)
{extraParams.type='pm_'+this.pmUserId+'_';}
else if(this.chatroom)
{extraParams.type='chatroom_'+this.chatroom+'_';}
extraParams.shoutid=shoutid;this.paused=true;this.unIdle(true,'deleteshout');this.ajaxCall('delete',extraParams);$('.shoutboxEditorCancelBtn',this.$el).trigger('click');},saveShout:function()
{if(!this.$editor.val().length)
{return false;}
this.opts.instanceOptions.floodchecktime=parseInt(this.opts.instanceOptions.floodchecktime);if(this.shoutDelay)
{this.setMessage(this.opts.phrases.dbtech_vbshout_must_wait_x_seconds.replace('%time%',this.opts.instanceOptions.floodchecktime).replace('%time2%',(this.opts.instanceOptions.floodchecktime-this.shoutDelay)),'Error');return false;}
var extraParams={};if(this.shoutId)
{console.log(this.timeStamp()+'Attempting to save shout: %s to instance: %s...',this.shoutId,this.instanceId);}
else
{console.log(this.timeStamp()+'Attempting to insert shout to instance: %s...',this.instanceId);}
if(this.pmUserId)
{extraParams.type='pm_'+this.pmUserId+'_';}
else if(this.chatroom)
{extraParams.type='chatroom_'+this.chatroom+'_';}
extraParams.message=encodeURIComponent($.trim(this.$editor.val()));this.paused=true;this.unIdle(true);this.shoutDelay=this.opts.instanceOptions.floodchecktime;this.ajaxCall('save',extraParams);if(this.shoutId)
{$('.shoutboxEditorCancelBtn',this.$el).trigger('click');}
else
{this.$editor.val('');}
return false;},saveStyleProps:function(type,value,noupdate)
{var property=type;var setValue=value;switch(type)
{case'bold':property='fontWeight';setValue=(value?type:'');break;case'italic':property='fontStyle';setValue=(value?type:'');break;case'underline':property='textDecoration';setValue=(value?type:'');break;case'font':property='fontFamily';break;case'size':property='fontSize';break;}
console.log(this.timeStamp()+"Style property %s set. Value: %s. Instance ID: %s",type,setValue,this.instanceId);if(type=='size')
{$('.shoutboxShoutListFrame',this.$el).css(property,setValue);}
else
{this.$editor.css(property,setValue);}
if(this.opts.editorOptions[type]!=value&&!noupdate)
{console.log(this.timeStamp()+"Style property %s changed. Old value: %s - New value: %s. Instance ID: %s",type,this.opts.editorOptions[type],value,this.instanceId);this.opts.editorOptions[type]=value;var extraParams={};extraParams.editor=this.opts.editorOptions;if(this.pmUserId)
{extraParams.type='pm_'+this.pmUserId+'_';}
else if(this.chatroom)
{extraParams.type='chatroom_'+this.chatroom+'_';}
this.paused=true;this.unIdle(true,'savestyles');this.ajaxCall('styleprops',extraParams);}},fetchShouts:function(type,force)
{this.paused=true;if(!type)
{type=this.tab;}
if(!(this.idleTime>=this.opts.instanceOptions.idletimeout&&this.opts.instancePermissions.idleexempt==0&&this.opts.instanceOptions.idletimeout>0)||force==true)
{var extraParams={};if(typeof this.aopTime[this.tab]=='undefined')
{force=true;}
switch(type)
{case'shout':extraParams.shoutid=this.shoutId;break;}
for(var i in this.tabList)
{if(this.tabList)
{extraParams['tabs['+i+']']=1;}}
extraParams.type=type;if((this.opts.instanceOptions.optimisation&&!force)&&type!='activeusers')
{if(type=='shouts'||type=='aop')
{type='shouts'+this.instanceId;}
if(type=='shoutnotifs'||type=='systemmsgs')
{type=type+this.instanceId;}
console.log(this.timeStamp()+'Fetching '+type+'...');$.ajax({type:'GET',url:'packages/DBTech/Shout/Data/Files/'+type+'.txt?v='+Math.random()*99999999999999,success:$.proxy(function(data,statusText,xhr)
{var d=new Date();var dateline=data;var timenow=parseInt(d.getTime()/1000);if(dateline>this.aopTime[this.tab])
{console.log(this.timeStamp()+this.tab+" AOP file returned new shouts: \n"+dateline+"\n"+this.aopTime[this.tab]);this.fetchShouts(this.tab,true);return false;}
if(dateline==0)
{console.log(this.timeStamp()+"AOP file returned 0");this.fetchShouts(this.tab,true);return false;}
if((timenow-dateline)>60)
{console.log(this.timeStamp()+"AOP file hasn't been modified for 60 seconds: "+(timenow-dateline));this.aopTime[this.tab]=(timenow+5);this.fetchShouts(this.tab,true);return false;}
else
{this.paused=false;this.countDown=this.opts.instanceOptions.refresh;}},this),error:$.proxy(function(data,statusText,error)
{this.fetchShouts(this.tab,true);},this)});}
else
{this.ajaxCall('fetch',extraParams,'GET');}}},ajaxCall:function(varname,extraParams,type)
{if(typeof type=='undefined')
{type='POST';if(typeof SECURITYTOKEN!='undefined')
{extraParams.securitytoken=SECURITYTOKEN;}}
extraParams.do='ajax/'+varname;extraParams.instanceid=this.instanceId;extraParams.tabid=this.tab;extraParams.type=extraParams.type||'shouts';if(this.opts.userOptions.is_detached=='1')
{extraParams.detached='1';}
if(this.pmUserId)
{extraParams.pmuserid=this.pmUserId;}
if(this.chatroom)
{extraParams.chatroomid=this.chatroom;}
if(this.shoutId)
{extraParams.shoutid=this.shoutId;}
extraParams.shoutorder=this.opts.instanceOptions.shoutorder;extraParams.pmtime=this.opts.userOptions.pmtime;if(type=='GET')
{extraParams.v=Math.random()*99999999999999;}
$.ajax({type:type,url:'vbshout.php',data:((typeof SESSIONURL!='undefined'&&SESSIONURL)?SESSIONURL:'')+$.param(extraParams),success:$.proxy(function(data)
{var tagData=$(data);data={};this.paused=false;this.countDown=this.opts.instanceOptions.refresh;if(!this.hasFetched&&this.opts.instancePermissions.autoidle)
{this.paused=this.hasFetched=true;}
var arrVals={0:'aoptimes',1:'chatrooms',2:'shouts'},singleVals={0:'ajax',1:'activereports',2:'content',3:'editor',4:'error',5:'pmtime',6:'pmuserid',7:'sticky'};if(tagData.find('activeusers').length)
{var tagData2=tagData.find('activeusers');data.activeusers={'count':tagData2.attr('count'),usernames:tagData2.text()};}
if(tagData.find('chatroom').length)
{var tagData2=tagData.find('chatroom');if(typeof tagData2.attr('chatroomid')!=undefined)
{data.chatroom={'chatroomid':tagData2.attr('chatroomid'),'title':tagData2.text()};}}
for(var i in singleVals)
{if(tagData.find(singleVals[i]).length)
{data[singleVals[i]]=tagData.find(singleVals[i]).text();}}
for(var i in arrVals)
{if(tagData.find(arrVals[i]).length)
{data[arrVals[i]]={};tagData.find(arrVals[i]).children().each(function(j)
{data[arrVals[i]][j]={};$(this).children().each(function()
{data[arrVals[i]][j][$(this).prop('tagName')]=$(this).text();});});}}
if(data.error)
{var tmp=data.error.split('_');if(tmp[0]=='disband')
{var chatroomid=parseInt(tmp[1]);if(chatroomid)
{if(this.chatroom==chatroomid)
{this.chatroom=0;$('.shoutboxTab[data-tabid="shouts"]',this.$el).trigger('click');}
this.closeTab($('.shoutboxTab[data-tabid^="chatroom_'+chatroomid+'_"]',this.$el).data('tabid'));return false;}}
this.setMessage(data.error,'Error');this.$editor.val(this.editorContents);console.error(this.timeStamp()+"AJAX Error: %s",data.error);return true;}
if(typeof data.sticky!='undefined')
{if(!data.sticky)
{$('.shoutboxSticky',this.$el).fadeOut('fast');}
else
{this.setMessage(data.sticky,'Sticky');}}
if(typeof data.activeusers!='undefined')
{$('.shoutboxTab[data-tabid="activeusers"] > span',this.$el).text(data.activeusers.count);$('.shoutboxActiveUsers',this.$el).html(data.activeusers.usernames);}
if(typeof data.activereports!='undefined')
{$('.shoutboxTab[data-tabid="shoutreports"] > span',this.$el).text(data.activereports);}
if(typeof data.editor!='undefined')
{this.$editor.val(data.editor);this.$editor.trigger('keyup');}
if(typeof data.content!='undefined')
{$('.shoutboxShoutListFrame > ul',this.$el).html(data.content);}
if(typeof data.archive!='undefined'&&typeof data.shoutid!='undefined')
{}
if(typeof data.pmuserid!='undefined')
{var tmp=$('.shoutboxLookupInput',this.$el);this.userIds[data.pmuserid]=tmp.val();this.createTab('pm_'+data.pmuserid+'_'+this.instanceId,tmp.val(),'1',{'userid':data.pmuserid});$('.shoutboxTab[data-tabid="pm_'+data.pmuserid+'_'+this.instanceId+'"]',this.$el).trigger('click');tmp.val('');}
if(typeof data.chatroom!='undefined')
{$('.shoutboxChatRoomName',$('#ShoutboxCreateChatMenu'+this.instanceId)).val('');this.createTab('chatroom_'+data.chatroom.chatroomid+'_'+this.instanceId,data.chatroom.title,'1',{'chatroomid':data.chatroom.chatroomid});$('.shoutboxTab[data-tabid="chatroom_'+data.chatroom.chatroomid+'_'+this.instanceId+'"]',this.$el).trigger('click');}
if(typeof data.aoptime!='undefined')
{if(this.aopTime[this.tab]<data.aoptime||!this.aopTime[this.tab])
{this.aopTime[this.tab]=data.aoptime;}}
if(typeof data.pmtime!='undefined')
{if(this.pmTime<data.pmtime)
{console.log(this.timeStamp()+"Playing pm sound for tab %s in instance %s",this.tab,this.instanceId);this.playSound('Pm');this.pmTime=data.pmtime;}}
if(typeof data.aoptimes!='undefined')
{for(var i in data.aoptimes)
{var aoptime=data.aoptimes[i].aoptime,tabId=data.aoptimes[i].tabid,noSound=data.aoptimes[i].nosound;if(!this.aopTime[tabId])
{this.aopTime[tabId]=aoptime;continue;}
if(this.aopTime[tabId]>=aoptime)
{continue;}
console.log(this.timeStamp()+"Tab: %s\nAOP: %s\nPrevious AOP: %s\nInstance: %s",tabId,aoptime,this.aopTime[tabId],this.instanceId);this.aopTime[tabId]=aoptime;if(noSound=='0')
{console.log(this.timeStamp()+"Playing shout sound for tab %s in instance %s",tabId,this.instanceId);this.playSound('Shout');}
if(tabId!=this.tab&&noSound=='0')
{$('.shoutboxTab[data-tabid="'+tabId+'"]',this.$el).addClass('dbtech_vbshout_highlight');}}}
if(typeof data.chatrooms!='undefined')
{for(var i in data.chatrooms)
{if(!this.tabList['chatroom_'+data.chatrooms[i].chatroomid+'_'+data.chatrooms[i].instanceid])
{this.playSound('Invite');if(confirm(this.opts.phrases.dbtech_vbshout_are_you_sure_chatjoin.replace(/%roomname%/igm,data.chatrooms[i].title).replace(/%username%/igm,data.chatrooms[i].username)))
{this.createTab('chatroom_'+data.chatrooms[i].chatroomid+'_'+data.chatrooms[i].instanceid,data.chatrooms[i].title,'1',{'chatroomid':data.chatrooms[i].chatroomid});this.paused=true;this.unIdle(false,'joinchat');this.ajaxCall('joinchat',{'chatroomid':data.chatrooms[i].chatroomid});$('.shoutboxTab[data-tabid="chatroom_'+data.chatrooms[i].chatroomid+'_'+data.chatrooms[i].instanceid+'"]',this.$el).trigger('click');}
else
{this.paused=true;this.unIdle(false,'leavechat');this.ajaxCall('leavechat',{'chatroomid':data.chatrooms[i].chatroomid,'status':1});}}}}
if(typeof data.shouts!='undefined')
{this.menuId=0;var shoutIds=[],shoutsById=[];for(var i in data.shouts)
{data.shouts[i].hidenewshout=!($('.shoutboxShoutWrapper[data-shoutid="'+data.shouts[i].shoutid+'"]').length);shoutIds[i]=data.shouts[i];shoutsById[data.shouts[i].shoutid]=true;}
$('.shoutboxShoutWrapper',this.$el).each(function(index,element)
{if(!shoutsById[$(this).data('shoutid')])
{$(this).fadeOut('fast',function()
{$(this).remove();});}});if(shoutIds.length)
{var contentObj=$('.shoutboxShoutListFrame > ul',this.$el);contentObj.html('');for(var i in shoutIds)
{var shout=shoutIds[i];shout.permissions=$.parseJSON(shout.permissions);$('#shoutboxShoutType'+shout.template).tmpl(shout).appendTo(contentObj);}
$('.shoutboxShoutWrapper',this.$el).filter(':hidden').fadeIn('fast',$.proxy(function()
{if(this.opts.instanceOptions.shoutorder=='ASC')
{$('.shoutboxShoutListFrame',this.$el).scrollTop(21474836);}},this));}}
if(typeof $.fn.xfActivate=='function')
{this.$el.xfActivate();}},this),error:$.proxy(function(data)
{this.paused=false;this.countDown=this.opts.instanceOptions.refresh;try
{if(data.statusText=='communication failure'||data.statusText=='transaction aborted'||data.status==0)
{return false;}
this.$editor.val(this.editorContents);this.setMessage(data.status+' '+textStatus,'Error');console.error(this.timeStamp()+"AJAX Error: Status = %s: %s",data.status,data.statusText);}
catch(e)
{console.error(this.timeStamp()+"AJAX Error: %s",data.responseText);}},this)});},playSound:function(sound)
{this.opts.soundSettings[this.tab]=this.opts.soundSettings[this.tab]||'1';if(this.opts.soundSettings[this.tab]=='0')
{return true;}
$('.shoutboxSound'+sound,this.$el).trigger('play');},setMuteButton:function()
{this.opts.soundSettings[this.tab]=this.opts.soundSettings[this.tab]||'1';var thisButton=$('.shoutboxSoundImage',this.$el);if(thisButton.length)
{if(this.opts.soundSettings[this.tab]=='0')
{thisButton.removeClass('shoutboxSprite-sound-on').addClass('shoutboxSprite-sound-off');}
else
{thisButton.removeClass('shoutboxSprite-sound-off').addClass('shoutboxSprite-sound-on');}}},setInvisibleButton:function()
{var thisButton=$('.shoutboxActiveImage',this.$el);if(thisButton.length)
{if(this.opts.instanceOptions.invisible=='1')
{thisButton.removeClass('shoutboxSprite-user-offline shoutboxSprite-user-online').addClass('shoutboxSprite-user-invisible');}
else
{thisButton.removeClass('shoutboxSprite-user-invisible').addClass('shoutboxSprite-user-online');}}},setMessage:function(msg,type)
{console.log(this.timeStamp()+"Setting %s: %s",type.charAt(0).toUpperCase()+''+type.substr(1),msg);var messageWrapper=$('.shoutbox'+type,this.$el);$('span',messageWrapper).html(msg);if(type!='Sticky'&&type!='Notice')
{messageWrapper.fadeIn('fast');setTimeout(function()
{messageWrapper.fadeOut('fast');},5000);}
else
{messageWrapper.show();}},timeStamp:function()
{var d=new Date();return'['+d.getHours()+':'+d.getMinutes()+':'+d.getSeconds()+'] ';},rgbToHex:function(colorStr)
{var hex='#';$.each(colorStr.substring(4).split(','),function(i,str)
{var h=($.trim(str.replace(')',''))*1).toString(16);hex+=(h.length==1)?"0"+h:h;});return hex;},htmlspecialchars:function(text)
{var map={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'};return text.replace(/[&<>"']/g,function(m){return map[m];});},unhtmlspecialchars:function(text)
{var map={'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&#039;':"'"};return text.replace(/[&<>"']/g,function(m){return map[m];});}};})(jQuery);