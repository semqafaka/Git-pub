<?php
/**
* Class that handles writing data to DB
*/
abstract class DBTech_Shout_DataManager
{
	const ERROR_EXCEPTION = 1;
	const ERROR_ARRAY = 2;
	const ERROR_SILENT = 3;

	protected $_fields = array();
	protected $_newData = array();
	protected $_existingData = array();
	protected $_errors = array();
	protected $_info = array();
	protected $_errorHandler = 0;
	protected $_preSaveCalled = null;
	protected $_preDeleteCalled = null;

	public function __construct($errorHandler = self::ERROR_ARRAY)
	{
		$this->_errorHandler = $errorHandler;

		if (!sizeof($this->_fields))
		{
			$this->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_field_data'));
		}
	}

	public function setExistingData($existing)
	{
		if (is_array($existing))
		{
			$this->_existingData = $existing;
			return true;
		}
		else
		{
			$this->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_existing_data'));
			return false;
		}
	}

	public function setInfo($key, $val)
	{
		$this->_info[$key] = $val;
	}

	public function getInfo($key)
	{
		return isset($this->_info[$key]) ? $this->_info[$key] : NULL;
	}

	public function bulkSet(array $fields)
	{
		foreach ($fields AS $field => $value)
		{
			$this->set($field, $value, '', true);
		}
	}

	public function set($field, $value, $tableName = '', $ignoreUndefined = false)
	{
		if ($this->_preSaveCalled)
		{
			throw new Exception('Set cannot be called after preSave has been called.');
		}

		$definedField = false;
		if (isset($this->_fields[$field]) AND is_array($this->_fields[$field]))
		{
			$definedField = true;

			if ($this->_isFieldValueValid($field, $this->_fields[$field], $value))
			{
				$this->_setInternal($field, $value);
			}
		}

		if (!$definedField AND !$ignoreUndefined)
		{
			$this->error("The field '$field' was not recognised.", $field, false);
		}

		return $definedField;
	}

	public function get($field, $existingOnly = false)
	{
		if (array_key_exists($field, $this->_newData) AND !$existingOnly)
		{
			return $this->_newData[$field];
		}
		else if (array_key_exists($field, $this->_existingData))
		{
			return $this->_existingData[$field];
		}

		return null;
	}

	public function getExisting($field)
	{
		return $this->get($field, true);
	}

	public function save()
	{
		$this->preSave();

		if ($this->_haveErrorsPreventSave())
		{
			if ($this->_errorHandler == self::ERROR_ARRAY)
			{
				return $this->_errors;
			}
			return false;
		}

		if (!$this->_newData)
		{
			if (!$this->_existingData)
			{
				return false;
			}
		}

		$this->_save();

		$this->_postSave();

		return $this->get(static::TABLE_ID);
	}

	public function preSave()
	{
		if ($this->_preSaveCalled)
		{
			return;
		}

		$this->_preSave();

		$this->_checkRequired();

		$this->_preSaveCalled = true;
	}

	public function isChanged($field)
	{
		return $this->isInsert() OR ($this->isUpdate() AND $this->get($field) != $this->get($field, true));
	}

	/**
	 * Returns true if this DW is updating a record, rather than inserting one.
	 *
	 * @return boolean
	 */
	public function isUpdate()
	{
		return !empty($this->_existingData);
	}

	/**
	 * Returns true if this DW is inserting a record, rather than updating one.
	 *
	 * @return boolean
	 */
	public function isInsert()
	{
		return !$this->isUpdate();
	}

	protected function _haveErrorsPreventSave()
	{
		if ($this->_errors)
		{
			switch ($this->_errorHandler)
			{
				case self::ERROR_SILENT:
				case self::ERROR_ARRAY:
					return true;
					break;

				case self::ERROR_EXCEPTION:
					throw new Exception($this->_errors);
					break;
			}
		}

		return false;
	}

	protected function _checkRequired()
	{
		foreach ($this->_fields AS $field => $fieldData)
		{
			if (!empty($fieldData['required'])
				AND (!array_key_exists($field, $this->_newData)
					OR $this->_newData[$field] === ''
				)
				AND (!array_key_exists($field, $this->_existingData)
					OR $this->_existingData[$field] === ''
				)
			)
			{
				//$this->error(DBTech_Shout_Core::phrase('dbtech_vbshout_please_enter_value_for_required_field_x', array('param1' => $field)), $field, false);
				$this->error("Missing required field $field", $field, false);
			}
		}
	}

	public function getUpdateCondition()
	{
		if (!$this->_existingData)
		{
			return '';
		}
		else
		{
			return $this->_getUpdateCondition();
		}
	}

	/**
	* Internal save handler. Deals with both updates and inserts.
	*/
	protected function _save()
	{
		if ($this->isUpdate())
		{
			$this->_update();
		}
		else
		{
			$this->_insert();
		}
	}

	protected function _insert()
	{
		$insertId = DBTech_Shout_Core::$db->insert(static::TABLE_NAME, $this->_newData);
		if (isset($this->_fields[static::TABLE_ID]['autoIncrement']) AND $this->_fields[static::TABLE_ID]['autoIncrement'])
		{
			$this->_newData[static::TABLE_ID] = $insertId;
		}

		return $insertId;
	}

	protected function _update()
	{
		$condition = $this->getUpdateCondition();
		if (!$condition)
		{
			throw new Exception('Cannot update data without a condition');
		}

		if ($this->_newData)
		{
			DBTech_Shout_Core::$db->update(static::TABLE_NAME, $this->_newData, 'WHERE ' . $condition);
		}
	}

	public function delete()
	{
		$this->preDelete();

		if ($this->_haveErrorsPreventSave())
		{
			if ($this->_errorHandler == self::ERROR_ARRAY)
			{
				return $this->_errors;
			}

			return false;
		}

		$this->_delete();

		$this->_postDelete();

		return true;
	}

	public function preDelete()
	{
		if ($this->_preDeleteCalled)
		{
			return;
		}

		$this->_preDelete();

		$this->_preDeleteCalled = true;
	}

	protected function _delete()
	{
		$condition = $this->getUpdateCondition();
		if (!$condition)
		{
			throw new Exception('Cannot delete data without a condition');
		}
		DBTech_Shout_Core::$db->delete(static::TABLE_NAME, array(), 'WHERE ' . $condition);
	}

	public function error($error, $errorKey = false, $specificError = true)
	{
		if ($errorKey !== false)
		{
			if ($specificError OR !isset($this->_errors[strval($errorKey)]))
			{
				$this->_errors[strval($errorKey)] = $error;
			}
		}
		else
		{
			$this->_errors[] = $error;
		}

		if ($this->_errorHandler == self::ERROR_EXCEPTION)
		{
			throw new Exception($error, true);
		}
	}


	protected function _preSave()
	{
	}

	protected function _postSave()
	{
	}

	protected function _preDelete()
	{
	}

	protected function _postDelete()
	{
	}

	protected function _isFieldValueValid($fieldName, array $fieldData, &$value, array $options = array())
	{
		$fieldType = isset($fieldData['type']) ? $fieldData['type'] : self::TYPE_BINARY;
		$value = $this->_castValueToType($fieldType, $value, $fieldName, $fieldData);

		if (!empty($fieldData['verification']))
		{
			if (!$this->_runVerificationCallback($fieldData['verification'], $value, $fieldData, $fieldName))
			{
				// verification callbacks are responsible for throwing errors
				return false;
			}
		}

		return true;
	}

	protected function _castValueToType($fieldType, $value, $fieldName, array $fieldData)
	{
		switch ($fieldType)
		{
			case 'string':
				if (isset($fieldData['noTrim']))
				{
					return strval($value);
				}
				else
				{
					return trim(strval($value));
				}

			case 'binary':
				return strval($value);

			case 'uint_forced':
				$value = intval($value);
				return ($value < 0 ? 0 : $value);

			case 'uint':
			case 'int':
				return intval($value);

			case 'float':
				return strval($value) + 0;

			case 'boolean':
				return ($value ? 1 : 0);

			case 'serialized':
				if (!is_string($value))
				{
					return serialize($value);
				}

				if (@unserialize($value) === false AND $value != serialize(false))
				{
					throw new Exception('Value is not unserializable');
				}

				return $value;

			case 'unknown':
				return $value; // unmodified

			default:
				throw new Exception((
					($fieldName === false)
					? "There is no field type '$fieldType'."
					: "The field type specified for '$fieldName' is not valid ($fieldType)."
				));
		}
	}

	protected function _runVerificationCallback($callback, &$value, array $fieldData, $fieldName = false)
	{
		if (is_array($callback) AND isset($callback[0]) AND $callback[0] == '$this')
		{
			$callback[0] = $this;
		}

		return (boolean)call_user_func_array($callback,
			array(&$value, $this, $fieldName, $fieldData)
		);
	}

	protected function _setInternal($field, $newValue, $forceSet = false)
	{
		$existingValue = $this->get($field);
		if ($forceSet
			OR $existingValue === null
			OR !is_scalar($newValue)
			OR !is_scalar($existingValue)
			OR strval($newValue) !== strval($existingValue)
		)
		{
			if ($newValue === $this->getExisting($field))
			{
				unset($this->_newData[$field]);
			}
			else
			{
				$this->_newData[$field] = $newValue;
			}
		}
	}

	public static function verifyUserId(&$userid, DBTech_Shout_DataManager $dm, $fieldName = false)
	{
		// Check for existing instance of this name
		if ($existing = DBTech_Shout_Core::$db->fetchRow('
			SELECT `' . DBTech_Shout_Core::$db->lookup('user', 'userid') . '`
			FROM `$user`
			WHERE `' . DBTech_Shout_Core::$db->lookup('user', 'userid') . '` = ?
		', array(
			$userid
		)))
		{
			return true;
		}

		$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_userid'), $fieldName);
		return false;
	}

	public static function verifyCommaList(&$list, DBTech_Shout_DataManager $dm, $fieldName = false)
	{
		if ($list === '')
		{
			return true;
		}

		if (is_array($list))
		{
			$list = implode(',', $list);
		}

		$items = explode(',', $list);
		$listNew = implode(',', $items);

		if ($list === $listNew)
		{
			return true;
		}

		// debugging message, no need for phrasing
		$dm->error("Please provide a list of values separated by commas only.", $fieldName);
		return false;
	}


}