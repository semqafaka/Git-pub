<?php
/**
* DataManager for Chatrooms.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Chatroom extends DBTech_Shout_DataManager
{
	const TABLE_NAME = 'dbtech_vbshout_chatroom';
	const TABLE_ID = 'chatroomid';

	protected $_fields = array(
		self::TABLE_ID		=> array(
			'type'				=> 'uint',
			'autoIncrement' 	=> true
		),
		'title' 			=> array(
			'type' 				=> 'string',
			'required' 			=> true,
		),
		'active' 			=> array(
			'type' 				=> 'boolean',
			'required' 			=> false,
		),
		'instanceid' 		=> array(
			'type' 				=> 'uint',
			'required' 			=> false,
			'verification' 		=> array('DBTech_Shout_DataManager_Helper_Instance', '_verifyInstance'),
		),
		'membergroupids' 		=> array(
			'type' 				=> 'unknown',
			'required' 			=> false,
			'verification' 		=> array('$this', 'verifyCommaList'),
		),
		'creator' 		=> array(
			'type' 				=> 'uint',
			'required' 			=> true,
			'verification' 		=> array('$this', 'verifyUserId'),
		),
		'members' => array(
			'type' 				=> 'serialized',
			'required' 			=> false,
		),
	);

	/**
	* Gets SQL condition to update the existing record.
	*
	* @return string
	*/
	protected function _getUpdateCondition()
	{
		return 'chatroomid = ' . DBTech_Shout_Core::$db->quote($this->getExisting('chatroomid'));
	}

	/**
	 * Post-save handling.
	 */
	protected function _postSave()
	{
		DBTech_Shout_Cache::build('chatroom');
	}

	/**
	 * Post-delete handling.
	 */
	protected function _postDelete()
	{
		// remove shouts belonging to this instance
		DBTech_Shout_Core::$db->delete('dbtech_vbshout_shout', array($this->getExisting('instanceid')), 'WHERE `instanceid` = ?');

		// Rebuild the cache
		DBTech_Shout_Cache::build('chatroom');

		// Rebuild shout counters
		DBTech_Shout_Shoutbox::buildShoutsCounter();
	}
}