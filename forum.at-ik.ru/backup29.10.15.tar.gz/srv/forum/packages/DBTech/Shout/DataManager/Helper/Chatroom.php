<?php
/**
* DataManager for Chatrooms.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Helper_Chatroom
{
	/**
	* Verifies that the chatroomid is valid
	*
	* @param	integer	chatroomid of the shout
	*
	* @return	boolean
	*/
	public static function _verifyChatroom(&$chatroomid, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		// Init this
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');

		return (!$chatroomid OR (isset($chatroomCache[$chatroomid]) AND is_array($chatroomCache[$chatroomid])));
	}
}