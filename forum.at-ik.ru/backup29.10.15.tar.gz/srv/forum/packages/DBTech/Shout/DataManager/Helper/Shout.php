<?php
/**
* DataManager for Shouts.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Helper_Shout
{
	/**
	* Verifies that the notification is valid
	*
	* @param	integer	notification of the shout
	*
	* @return	boolean
	*/
	public static function _verifyNotification(&$data, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		return (in_array($data, array('', 'thread', 'reply')));
	}

	/**
	 * Verifies that the forumid is valid.
	 *
	 * @param string $forumid
	 *
	 * @return boolean
	 */
	public static function _verifyForum(&$forumid, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		$forumid = intval($forumid);
		if ($forumid === 0)
		{
			// Forumid 0 is valid
			return true;
		}

		// Check for existing instance of this name
		if (!isset(DBTech_Shout_Core::$forumcache[$forumid]))
		{
			// Whoopsie, exists
			$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_forum'), $fieldName);
			return false;
		}

		return true;
	}

	/**
	 * Verifies that the message is valid.
	 *
	 * @param string $message
	 *
	 * @return boolean
	 */
	public static function _verifyMessage(&$message, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');

		$instanceid = $dm->get('instanceid');
		if (!$instance = $dm->getInfo('instance'))
		{
			$instance = $instanceCache[$instanceid];
			$dm->setInfo('instance', $instance);
		}

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				break;

			case 'vBulletin':
				$message = convert_urlencoded_unicode($message);
				break;
		}

		$message = str_replace(array("\n", '&lt;', '&gt;', '&quot;', '&amp;'), array('', '<', '>', '"', '&'), trim($message));

		if ($instance['options']['maxchars'] AND !DBTech_Shout_Core::usergroupPermission('dbtech_vbshoutpermissions', 'ismanager') AND !$dm->getInfo('verifiedmessage'))
		{
			$message = substr($message, 0, $instance['options']['maxchars']);
			$dm->setInfo('verifiedmessage', true);
		}

		if (empty($message))
		{
			$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_message_specified'));
			return false;
		}

		// Strip out some characters we can't deal with
		$message = preg_replace('/[\x00-\x1F]/', '', $message);

		if ($instance['options']['allcaps'])
		{
			switch (DBTech_Shout_Core::getSystem())
			{
				case 'XenForo':
					if ($message == utf8_strtoupper($message))
					{
						// Sort this out
						$message = utf8_ucfirst(utf8_strtolower($message));
					}
					break;

				case 'vBulletin':
					// Grab the noshout text
					require_once(DIR . '/includes/functions_newpost.php');
					$message = fetch_no_shouting_text($message);
					break;
			}
		}

		return true;
	}

	/**
	 * Parses action codes
	 *
	 * @return boolean
	 */
	public static function _parseActionCodes(DBTech_Shout_DataManager $dm)
	{
		if ($dm->get('type') != DBTech_Shout_Shoutbox::$shouttypes['shout'])
		{
			// We're not doing anything with a non-shout type
			// Notifications / PMs are already parsed and ready
			return true;
		}

		// Init this
		$instanceCache = DBTech_Shout_Cache::get('instance');
		$chatroomCache = DBTech_Shout_Cache::get('chatroom');
		

		$instanceid = $dm->get('instanceid');
		if (!$instance = $dm->getInfo('instance'))
		{
			$instance = $instanceCache[$instanceid];
			$dm->setInfo('instance', $instance);
		}

		// Shorthand
		$message = $dm->get('message');

		// The PM command is special and can't be prettified.
		// It's also the only 3-stage command we have, so it doesn't matter
		if (preg_match("#^(\/pm)\s+?(.+?);\s+?(.+?)$#i", $message, $matches))
		{
			if (!$instance['permissions_parsed']['canpm'])
			{
				// We has an error
				$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_pming_disabled_usergroup'));
				return false;
			}

			if ($matches[2] == DBTech_Shout_Core::$userinfo['username'])
			{
				// We has an error
				$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_pm_self'));
				return false;
			}

			if (!$exists = DBTech_Shout_Core::$db->fetchRow('
				SELECT *, ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' AS userid
				FROM $user AS user
				WHERE username = ?
			', array(htmlspecialchars($matches[2]))))
			{
				// We has an error
				$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_user'));
				return false;
			}

			$return_value = true;
			

			if (!$return_value)
			{
				// We're ending it early
				return $return_value;
			}

			// Override some values
			$dm->set('id', 			$exists['userid']);
			$dm->set('type', 		DBTech_Shout_Shoutbox::$shouttypes['pm']);
			$dm->set('message', 	$matches[3]);
			$dm->set('chatroomid', 	0);
		}
		else if (preg_match("#^(\/[a-z0-9]*?)$#i", $message, $matches))
		{
			// 1-stage command
			switch ($matches[1])
			{
				case '/prune':

					if (!$dm->get('chatroomid'))
					{
						if (!$instance['permissions_parsed']['canprune'])
						{
							// We has an error
							$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}
					else
					{
						if ($chatroomCache[$dm->get('chatroomid')]['creator'] != DBTech_Shout_Core::$userinfo['userid'] AND !$instance['permissions_parsed']['canprune'])
						{
							// Only chat room creators can prune
							$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}

					// Now get rid of the shouts
					DBTech_Shout_Core::$db->delete('dbtech_vbshout_shout', array($dm->get('instanceid'), $dm->get('chatroomid')), 'WHERE instanceid = ? AND chatroomid = ?');

					// Rebuild shout counts
					DBTech_Shout_Shoutbox::buildShoutsCounter();

					// Log the prune command
					DBTech_Shout_Shoutbox::logCommand('prune');

					// Blank out the message and change type
					$dm->set('type', 		DBTech_Shout_Shoutbox::$shouttypes['system']);
					$dm->set('message', 	DBTech_Shout_Core::phrase('dbtech_vbshout_shoutbox_pruned'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}
					break;

				case '/editsticky':
					if (!$instance['permissions_parsed']['cansticky'])
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_sticky'));
						return false;
					}

					// What we need to put in the editor
					DBTech_Shout_Shoutbox::$fetched['editor'] = '/sticky ' . $instance['sticky_raw'];

					// We're not continuing
					return false;
					break;

				case '/createchat':
					$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_chatroom_name'));
					return false;
					break;

				case '/resetshouts':
					if (!$dm->get('chatroomid'))
					{
						if (!$instance['permissions_parsed']['canprune'])
						{
							// We has an error
							$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}
					else
					{
						if ($chatroomCache[$dm->get('chatroomid')]['creator'] != DBTech_Shout_Core::$userinfo['userid'] AND !$instance['permissions_parsed']['canprune'])
						{
							// Only chat room creators can prune
							$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}

					// Reset all users' lifetime shouts
					DBTech_Shout_Core::$db->query('UPDATE $user SET dbtech_vbshout_shouts_lifetime = dbtech_vbshout_shouts', array(), 'query_write');

					// Log the removesticky command
					DBTech_Shout_Shoutbox::logCommand('resetshouts');

					// Blank out the message and change type
					$dm->set('type', 		DBTech_Shout_Shoutbox::$shouttypes['system']);
					$dm->set('message', 	DBTech_Shout_Core::phrase('dbtech_vbshout_shouts_reset'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}

					break;

				case '/removenotice':
				case '/removesticky':
				case '/sticky':
					if (!$instance['permissions_parsed']['cansticky'])
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_sticky'));
						return false;
					}

					// Remove the sticky note
					DBTech_Shout_Shoutbox::setSticky('', $instance);

					// Log the removesticky command
					DBTech_Shout_Shoutbox::logCommand('removesticky');

						// Blank out the message
					$dm->set('type', 		DBTech_Shout_Shoutbox::$shouttypes['system']);
					$dm->set('message', 	DBTech_Shout_Core::phrase('dbtech_vbshout_sticky_note_removed'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}
					break;

				case '/banlist':
					if (!$instance['permissions_parsed']['canban'])
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_ban'));
						return false;
					}

					$users = DBTech_Shout_Core::$db->fetchAll('
						SELECT *
						FROM $user
						WHERE dbtech_vbshout_banned = 1
					');

					$bannedUsers = array();
					foreach ($users as $user)
					{
						switch (DBTech_Shout_Core::getSystem())
						{
							case 'XenForo':
								$user['musername'] = $user['username'];
								break;

							case 'vBulletin':
								// Grab the markup username for this user
								fetch_musername($user);
								break;
						}


						

						// Store silenced user
						$bannedUsers[] = $user['musername'];
					}

					// Blank out the message and change type
					$dm->set('userid', 	DBTech_Shout_Core::$userinfo['userid']);
					$dm->set('id', 		DBTech_Shout_Core::$userinfo['userid']);
					$dm->set('type', 	DBTech_Shout_Shoutbox::$shouttypes['pm']);
					$dm->set('message', (count($bannedUsers) ? implode(', ', $bannedUsers) : DBTech_Shout_Core::phrase('dbtech_vbshout_no_banned_users')));
					break;

				default:
					$return_value = true;
					$handled = false;

					

					return $return_value;
					break;
			}
		}
		else if (preg_match("#^(\/[a-z0-9]*?)\s(.+?)$#i", $message, $matches))
		{
			// 2-stage command
			switch ($matches[1])
			{
				case '/me':
					// ZE ME COMMAND, IT DOEZ NOZING
					break;

				case '/invite':
				case '/chatinvite':
					// Invite an user to chat
					$chatroomid = $dm->get('chatroomid');

					if (!isset($chatroomCache[$chatroomid]) OR $chatroomCache[$chatroomid]['membergroupids'])
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_chat_room'));
						return false;
					}

					if (!$userId = DBTech_Shout_Core::$db->fetchAll('
						SELECT ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . '
						FROM $user AS user
						WHERE username = ?
					', array(htmlspecialchars($matches[2]))))
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_user'));
						return false;
					}

					// Invite to join the chat room
					DBTech_Shout_Shoutbox::chatInvite($chatroomCache[$chatroomid], $userId, DBTech_Shout_Core::$userinfo['userid']);

					return false;
					break;

				case '/ignore':
				case '/unignore':
					// Ignore an user
					if (!$exists = DBTech_Shout_Core::$db->fetchRow('
						SELECT *, ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' AS userid
						FROM $user AS user
						WHERE username = ?
					', array(htmlspecialchars($matches[2]))))
					{
						// We has an error
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_user'));
						return false;
					}

					if ($exists['userid'] == DBTech_Shout_Core::$userinfo['userid'])
					{
						// Ourselves, duh
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_ignore_self'));
						return false;
					}

					$isProtected = false;
					try
					{
						DBTech_Shout_Shoutbox::checkProtectedUserGroup($instance, $exists);
					}
					catch (Exception $e)
					{
						// Yeah
						$isProtected = true;
					}

					if ($isProtected)
					{
						// We had an error
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_protected_usergroup'));
						return false;
					}

					if ($matches[1] == '/ignore')
					{
						// Ignore the user
						DBTech_Shout_Core::$db->replace('dbtech_vbshout_ignorelist', array(
							'userid' => DBTech_Shout_Core::$userinfo['userid'],
							'ignoreuserid' => $exists['userid']
						));
					}
					else
					{
						// Unignore the user
						DBTech_Shout_Core::$db->delete('dbtech_vbshout_ignorelist', array(DBTech_Shout_Core::$userinfo['userid'], $exists['userid']), 'WHERE userid = ? AND ignoreuserid = ?');
					}
					return false;
					break;

				case '/notice':
				case '/setnotice':
				case '/sticky':
				case '/setsticky':
					if (!$instance['permissions_parsed']['cansticky'])
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_sticky'));
						return false;
					}

					// Set the sticky note
					DBTech_Shout_Shoutbox::setSticky($matches[2], $instance);

					// Log the setsticky command
					DBTech_Shout_Shoutbox::logCommand('setsticky', $matches[2]);

					// Blank out the message
					$dm->set('type', 		DBTech_Shout_Shoutbox::$shouttypes['system']);
					$dm->set('message', 	DBTech_Shout_Core::phrase('dbtech_vbshout_sticky_note_set'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}
					break;

				case '/ban':
				case '/unban':
					if (!$instance['permissions_parsed']['canban'])
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_ban'));
						return false;
					}

					// Banning an user
					if (!$exists = DBTech_Shout_Core::$db->fetchRow('
						SELECT *, ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' AS userid
						FROM $user AS user
						WHERE username = ?
					', array(htmlspecialchars($matches[2]))))
					{
						// We has an error
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_invalid_user'));
						return false;
					}

					if ($exists['userid'] == DBTech_Shout_Core::$userinfo['userid'])
					{
						// Ourselves, duh
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cannot_ban_self'));
						return false;
					}

					$isProtected = false;
					try
					{
						DBTech_Shout_Shoutbox::checkProtectedUserGroup($instance, $exists);
					}
					catch (Exception $e)
					{
						// Yeah
						$isProtected = true;
					}

					if ($isProtected)
					{
						// We had an error
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_protected_usergroup'));
						return false;
					}

					// Log the ban command
					DBTech_Shout_Shoutbox::logCommand(($matches[1] == '/ban' ? 'ban' : 'unban'), $exists['userid']);

					// Ban the user
					DBTech_Shout_Core::$db->update('user', array('dbtech_vbshout_banned' => ($matches[1] == '/ban' ? 1 : 0)), 'WHERE ' . DBTech_Shout_Core::$db->lookup('user', 'userid') . ' = ' . $exists['userid']);

					if (!$instance['permissions_parsed']['showaction'])
					{
						return false;
					}

					// Print success message
					$dm->set('type', 		DBTech_Shout_Shoutbox::$shouttypes['system']);
					$dm->set('message', 	($matches[1] == '/ban' ? DBTech_Shout_Core::phrase('dbtech_vbshout_banned_successfully', array('param1' => $matches[2])) : DBTech_Shout_Core::phrase('dbtech_vbshout_unbanned_successfully', array('param1' => $matches[2]))));
					break;

				case '/createchat':
					if (!$instance['permissions_parsed']['cancreatechat'])
					{
						$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_cant_create_chat'));
						return false;
					}

					if ($instance['options']['maxchats'])
					{
						$i = 0;
						foreach ((array)$chatroomCache as $chatroomid => $chatroom)
						{
							if (!$chatroom['active'])
							{
								// Don't count closed rooms
								continue;
							}

							if ($chatroom['creator'] == DBTech_Shout_Core::$userinfo['userid'])
							{
								// We're the creator
								$i++;
							}
						}

						if ($i >= $instance['options']['maxchats'])
						{
							// Waaaay too many chats, slow down tiger!
							$dm->error(DBTech_Shout_Core::phrase('dbtech_vbshout_too_many_chats'));
							return false;
						}
					}

					// init data manager
					$chatroomDm = new DBTech_Shout_DataManager_Chatroom(DBTech_Shout_DataManager::ERROR_ARRAY);
						$chatroomDm->bulkSet(array(
							'title' => $matches[2],
							'instanceid' => $instance['instanceid'],
							'creator' => DBTech_Shout_Core::$userinfo['userid'],
							'members' => array(DBTech_Shout_Core::$userinfo['userid'] => '1')
						));
					$chatroomid = $chatroomDm->save();
					unset($chatroomDm);

					// Insert the chat member
					DBTech_Shout_Core::$db->insert('dbtech_vbshout_chatroommember', array(
						'chatroomid' => $chatroomid,
						'userid' => DBTech_Shout_Core::$userinfo['userid'],
						'status' => 1
					));

					// Set chat room info
					DBTech_Shout_Shoutbox::$fetched['chatroom'] = array(
						'chatroomid' 	=> $chatroomid,
						'title' 		=> $matches[2]
					);

					return false;
					break;

				default:
					$return_value = true;
					$handled = false;

					

					return $return_value;
					break;
			}
		}

		return true;
	}

	/**
	 * Verifies that the forumid is valid.
	 *
	 * @param string $forumid
	 *
	 * @return boolean
	 */
	public static function _verifyImageCount(&$message, array $instance, DBTech_Shout_DataManager $dm)
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$maxImages = $instance['options']['maximages'] ? $instance['options']['maximages'] : DBTech_Shout_Core::option('messageMaxImages');

				if ($maxImages AND !$dm->getInfo('is_automated'))
				{
					$formatter = XenForo_BbCode_Formatter_Base::create('ImageCount', false);
					$parser = XenForo_BbCode_Parser::create($formatter);
					$parser->render($message);

					// Grab image count
					$imageCount = $formatter->getImageCount();
				}
				break;

			case 'vBulletin':
				$maxImages = $instance['options']['maximages'] ? $instance['options']['maximages'] : DBTech_Shout_Core::option('maximages');

				if ($maxImages AND !$dm->getInfo('is_automated'))
				{
					// check max images
					require_once(DIR . '/includes/functions_misc.php');
					require_once(DIR . '/includes/class_bbcode_alt.php');
					$bbcode_parser = new vB_BbCodeParser_ImgCheck($GLOBALS['vbulletin'], fetch_tag_list());
					$bbcode_parser->set_parse_userinfo(DBTech_Shout_Core::$userinfo);

					// Grab image count
					$imageCount = fetch_character_count($bbcode_parser->parse($message, 'nonforum', $instance['options']['allowsmilies'], true), '<img');
				}
				break;
		}

		if ($imageCount > $maxImages)
		{
			$this->error(DBTech_Shout_Core::phrase('dbtech_vbshout_too_many_images', array('param1' => $imageCount, 'param2' => $maxImages)));
			return false;
		}

		return true;
	}
}