<?php
/**
* DataManager for Instances.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Instance extends DBTech_Shout_DataManager
{
	const TABLE_NAME = 'dbtech_vbshout_instance';
	const TABLE_ID = 'instanceid';

	protected $_fields = array(
		self::TABLE_ID		=> array(
			'type'				=> 'uint',
			'autoIncrement' 	=> true
		),
		'varname' 			=> array(
			'type' 				=> 'string',
			'required' 			=> true,
			'verification' 		=> array('DBTech_Shout_DataManager_Helper_Instance', '_verifyVarname'),
		),
		'name' => array(
			'type' 				=> 'string',
			'required' 			=> true,
		),
		'description' => array(
			'type' 				=> 'string',
			'required' 			=> false,
		),
		'active' 			=> array(
			'type' 				=> 'boolean',
			'required' 			=> false,
		),
		'displayorder' 		=> array(
			'type' 				=> 'uint',
			'required' 			=> false,
		),
		'autodisplay' 		=> array(
			'type' 				=> 'uint',
			'required' 			=> true,
		),
		'permissions' 		=> array(
			'type' 				=> 'serialized',
			'required' 			=> false,
		),
		'bbcodepermissions' => array(
			'type' 				=> 'serialized',
			'required' 			=> false,
		),
		'options' 			=> array(
			'type' 				=> 'serialized',
			'required' 			=> true,
		),
		'forumids' 			=> array(
			'type' 				=> 'serialized',
			'required' 			=> false,
		),
		'sticky' 			=> array(
			'type' 				=> 'string',
			'required' 			=> false,
		),
		'sticky_raw' 		=> array(
			'type' 				=> 'string',
			'required' 			=> false,
		),
		'notices' 			=> array(
			'type' 				=> 'serialized',
			'required' 			=> false,
		),
		'shoutsound' 		=> array(
			'type' 				=> 'string',
			'required' 			=> false,
		),
		'invitesound' 		=> array(
			'type' 				=> 'string',
			'required' 			=> false,
		),
		'pmsound' 			=> array(
			'type' 				=> 'string',
			'required' 			=> false,
		),
	);

	/**
	* Gets SQL condition to update the existing record.
	*
	* @return string
	*/
	protected function _getUpdateCondition()
	{
		return 'instanceid = ' . DBTech_Shout_Core::$db->quote($this->getExisting('instanceid'));
	}

	/**
	 * Post-save handling.
	 */
	protected function _postSave()
	{
		DBTech_Shout_Cache::build('instance');
	}

	/**
	 * Post-delete handling.
	 */
	protected function _postDelete()
	{
		// remove shouts belonging to this instance
		DBTech_Shout_Core::$db->delete('dbtech_vbshout_shout', array($this->getExisting('instanceid')), 'WHERE `instanceid` = ?');

		// Rebuild the cache
		DBTech_Shout_Cache::build('instance');

		// Rebuild shout counters
		DBTech_Shout_Shoutbox::buildShoutsCounter();
	}
}