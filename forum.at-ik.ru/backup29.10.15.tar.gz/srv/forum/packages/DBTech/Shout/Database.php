<?php
// #############################################################################
// database functionality class

/**
* Class that handles database wrapper
*/
class DBTech_Shout_Database
{
	/**
	* The database object
	*
	* @private	Database
	*/
	private $db;

	/**
	* The query result we executed
	*
	* @private	MySQL_Result
	*/
	private $result;

	/**
	* The query result we executed
	*
	* @private	MySQL_Result
	*/
	private $resultLoopable;

	/**
	* Whether we're debugging output
	*
	* @public	boolean
	*/
	public $debug = false;

	/**
	* Lookup for common tables
	*
	* @public	array
	*/
	protected $lookup = array(
		'XenForo' => array(
			'user' => array(
				'userid' => 'user_id',
				'joindate' => 'register_date',
				'posts' => 'message_count',
			),
		),
	);


	/**
	* Does important checking before anything else should be going on
	*/
	function __construct($dbobj)
	{
		$this->db = $dbobj;
	}

	public function lookup($table, $column)
	{
		$system = DBTech_Shout_Core::getSystem();
		return isset($this->lookup[$system][$table][$column]) ? $this->lookup[$system][$table][$column] : $column;
	}

	/**
	 * Hides DB errrors
	 *
	 * @return void
	 */
	public function hideErrors()
	{
		if (method_exists($this->db, 'hide_errors'))
		{
			$this->db->hide_errors();
		}
	}

	/**
	 * Shows DB errrors
	 *
	 * @return void
	 */
	public function showErrors()
	{
		if (method_exists($this->db, 'show_errors'))
		{
			$this->db->show_errors();
		}
	}

	public function quote($value)
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return $this->db->quote($value);
				break;

			case 'vBulletin':
				return $this->db->sql_prepare($value);
				break;
		}
	}

	public function quoteLike($value, $wildCard)
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return XenForo_Db::quoteLike($value, $wildCard, $this->db);
				break;

			case 'vBulletin':
				switch ($wildCard)
				{
					case 'r':
						$prefix = '';
						$suffix = '%';
						break;

					case 'l':
						$prefix = '%';
						$suffix = '';
						break;

					case 'lr':
						$prefix = '%';
						$suffix = '%';
						break;

					default:
						$prefix = '';
						$suffix = '';
						break;
				}

				return "'" . $prefix . $this->db->escape_string_like($value) . $suffix . "'";
				break;
		}
	}

	/**
	 * Inserts a table row with specified data.
	 *
	 * @param mixed $table The table to insert data into.
	 * @param array $bind Column-value pairs.
	 * @param array $exclusions Array of field names that should be ignored from the $bind array
	 * @param boolean $displayErrors Whether SQL errors should be displayed
	 * @param string $type Whether it's insert, insert ignore or replace
	 *
	 * @return int The number of affected rows.
	 */
	public function insert($table, array $bind, array $exclusions = array(), $displayErrors = true, $type = 'insert')
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$sql = self::constructSql($table, $bind, '', $exclusions, $type);
				break;

			case 'vBulletin':
				$sql = fetch_query_sql($bind, $table, '', $exclusions);

				switch ($type)
				{
					case 'ignore':
						$sql = str_replace('INSERT INTO', 'INSERT IGNORE INTO', $sql);
						break;

					case 'replace':
						$sql = str_replace('INSERT INTO', 'REPLACE INTO', $sql);
						break;
				}
				break;
		}

		if ($this->debug)
		{
			echo "<pre>";
			echo $sql;
			echo "</pre>";
			die();
		}

		if (!$displayErrors)
		{
			$this->hideErrors();
		}

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$result = $this->db->query($sql, $bind, Zend_Db::FETCH_ASSOC);
				break;

			case 'vBulletin':
				$result = $this->db->query_write($sql);
				break;
		}
		if (!$displayErrors)
		{
			$this->showErrors();
		}

		// Return insert ID if only one row was inserted, otherwise return number of affected rows
		$affected = $this->affectedRows($result);
		return(($affected === 1 AND $type == 'insert') ? $this->insertId() : $affected);
	}

	/**
	 * Inserts a table row with specified data, ignoring duplicates.
	 *
	 * @param mixed $table The table to insert data into.
	 * @param array $bind Column-value pairs.
	 * @param array $exclusions Array of field names that should be ignored from the $bind array
	 * @param boolean $displayErrors Whether SQL errors should be displayed
	 *
	 * @return int The number of affected rows.
	 */
	public function insertIgnore($table, array $bind, array $exclusions = array(), $displayErrors = true)
	{
		return $this->insert($table, $bind, $exclusions, $displayErrors, 'ignore');
	}

	/**
	 * Inserts a table row with specified data, replacing duplicates.
	 *
	 * @param mixed $table The table to insert data into.
	 * @param array $bind Column-value pairs.
	 * @param array $exclusions Array of field names that should be ignored from the $bind array
	 * @param boolean $displayErrors Whether SQL errors should be displayed
	 *
	 * @return int The number of affected rows.
	 */
	public function replace($table, array $bind, array $exclusions = array(), $displayErrors = true)
	{
		return $this->insert($table, $bind, $exclusions, $displayErrors, 'replace');
	}

	/**
	 * Updates table rows with specified data based on a WHERE clause.
	 *
	 * @param  mixed		$table The table to update.
	 * @param  array		$bind  Column-value pairs.
	 * @param  mixed		$where UPDATE WHERE clause(s).
	 * @param  mixed		$exclusions Array of field names that should be ignored from the $bind array
	 *
	 * @return int		  The number of affected rows.
	 */
	public function update($table, array $bind, $where, array $exclusions = array(), $type = 'insert')
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$sql = self::constructSql($table, $bind, $where, $exclusions, $type);
				break;

			case 'vBulletin':
				$sql = fetch_query_sql($bind, $table, $where, $exclusions);

				switch ($type)
				{
					case 'ignore':
						$sql = str_replace('INSERT INTO', 'INSERT IGNORE INTO', $sql);
						break;

					case 'replace':
						$sql = str_replace('INSERT INTO', 'REPLACE INTO', $sql);
						break;
				}
				break;
		}

		if ($this->debug)
		{
			echo "<pre>";
			echo $sql;
			echo "</pre>";
			die();
		}

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$result = $this->db->query($sql, $bind, Zend_Db::FETCH_ASSOC);
				break;

			case 'vBulletin':
				$result = $this->db->query_write($sql);
				break;
		}

		return $this->affectedRows($result);
	}

	/**
	 * Deletes table rows based on a WHERE clause.
	 *
	 * @param  mixed		$table The table to update.
	 * @param  mixed  		$bind Data to bind into DELETE placeholders.
	 * @param  mixed		$where DELETE WHERE clause(s).
	 *
	 * @return int		  The number of affected rows.
	 */
	public function delete($table, array $bind, $where = '')
	{
		/**
		 * Build the DELETE statement
		 */
		$sql = $this->replaceTablePrefix('DELETE FROM $' . $table . ' ' . $where);

		/**
		 * Execute the statement and return the number of affected rows
		 */
		$result = $this->query($sql, $bind, 'query_write');
		return $this->affectedRows($result);
	}

	/**
	 * Fetches all SQL result rows as a sequential array.
	 *
	 * @param string $sql  An SQL SELECT statement.
	 * @param mixed  $bind Data to bind into SELECT placeholders.
	 *
	 * @return array
	 */
	public function fetchAll($sql, $bind = array())
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return $this->db->fetchAll($this->replaceTablePrefix($sql), $bind);
				break;

			case 'vBulletin':
				$results = array();

				$this->query($sql, $bind, 'query_read');
				while ($row = $this->db->fetch_array($this->result))
				{
					$results[] = $row;
				}
				return $results;
				break;
		}
	}

	/**
	 * Fetches results from the database with a specified column from each row keyed according to preference.
	 * The 'key' parameter provides the column name with which to key the result.
	 * The 'column' parameter provides the column name with which to use as the result.
	 * For example, calling fetchAllSingleKeyed('SELECT item_id, title, date FROM table', 'item_id', 'title')
	 * would result in an array keyed by item_id:
	 * [$itemId] => $title
	 *
	 * Note that the specified key must exist in the query result, or it will be ignored.
	 *
	 * @param string SQL to execute
	 * @param string Column with which to key the results array
	 * @param string Column to use as the result for that key
	 * @param mixed Parameters for the SQL
	 *
	 * @return array
	 */
	public function fetchAllSingleKeyed($sql, $key, $column, $bind = array())
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$results = array();
				$i = 0;

				$stmt = $this->db->query($this->replaceTablePrefix($sql), $bind, Zend_Db::FETCH_ASSOC);
				while ($row = $stmt->fetch())
				{
					$results[(isset($row[$key]) ? $row[$key] : $i)] = $row[$column];
					$i++;
				}

				return $results;
				break;

			case 'vBulletin':
				$results = array();
				$i = 0;

				$this->query($sql, $bind, 'query_read');
				while ($row = $this->db->fetch_array($this->result))
				{
					$results[(isset($row[$key]) ? $row[$key] : $i)] = $row[$column];
					$i++;
				}

				return $results;
				break;
		}
	}

	/**
	 * Fetches results from the database with each row keyed according to preference.
	 * The 'key' parameter provides the column name with which to key the result.
	 * For example, calling fetchAllKeyed('SELECT item_id, title, date FROM table', 'item_id')
	 * would result in an array keyed by item_id:
	 * [$itemId] => array('item_id' => $itemId, 'title' => $title, 'date' => $date)
	 *
	 * Note that the specified key must exist in the query result, or it will be ignored.
	 *
	 * @param string SQL to execute
	 * @param string Column with which to key the results array
	 * @param mixed Parameters for the SQL
	 *
	 * @return array
	 */
	public function fetchAllKeyed($sql, $key, $bind = array())
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				$results = array();
				$i = 0;

				$stmt = $this->db->query($this->replaceTablePrefix($sql), $bind, Zend_Db::FETCH_ASSOC);
				while ($row = $stmt->fetch())
				{
					$results[(isset($row[$key]) ? $row[$key] : $i)] = $row;
					$i++;
				}

				return $results;
				break;

			case 'vBulletin':
				$results = array();
				$i = 0;

				$this->query($sql, $bind, 'query_read');
				while ($row = $this->db->fetch_array($this->result))
				{
					$results[(isset($row[$key]) ? $row[$key] : $i)] = $row;
					$i++;
				}

				return $results;
				break;
		}
	}

	/**
	 * Fetches all SQL result rows as an associative array.
	 *
	 * The first column is the key, the entire row array is the
	 * value.  You should construct the query to be sure that
	 * the first column contains unique values, or else
	 * rows with duplicate values in the first column will
	 * overwrite previous data.
	 *
	 * @param string $sql An SQL SELECT statement.
	 * @param mixed $bind Data to bind into SELECT placeholders.
	 *
	 * @return array
	 */
	public function fetchAssoc($sql, $bind = array())
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return $this->db->fetchAssoc($this->replaceTablePrefix($sql), $bind);
				break;

			case 'vBulletin':
				$data = array();
				$this->query($sql, $bind, 'query_read');
				while ($row = $this->db->fetch_array($this->result))
				{
					$key = key($row);
					$data[$row[$key]] = $row;
				}
				return $data;
				break;
		}
	}

	/**
	 * Fetches the first row of the SQL result.
	 *
	 * @param string $sql An SQL SELECT statement.
	 * @param mixed  $bind Data to bind into SELECT placeholders.
	 * @param mixed  $fetchMode Override current fetch mode.
	 *
	 * @return array
	 */
	public function fetchRow($sql, $bind = array())
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return $this->db->fetchRow($this->replaceTablePrefix($sql), $bind);
				break;

			case 'vBulletin':
				// Check the limit and fix $sql
				$limit = explode('limit', strtolower($sql));
				if (sizeof($limit) != 2 OR !is_numeric(trim($limit[1])))
				{
					// Append limit
					$sql .= ' LIMIT 1';
				}

				$result = $this->query($sql, $bind, 'query_first');
				return $result;
				break;
		}
	}

	/**
	 * Fetches the first column of all SQL result rows as an array.
	 *
	 * @param string $sql An SQL SELECT statement.
	 * @param mixed  $bind Data to bind into SELECT placeholders.
	 * @param mixed  $column OPTIONAL - Key to use for the column index
	 * @return array
	 */
	public function fetchCol($sql, $bind = array(), $column = '')
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return $this->db->fetchCol($this->replaceTablePrefix($sql), $bind);
				break;

			case 'vBulletin':
				$data = array();
				$this->query($sql, $bind, 'query_read');
				while ($row = $this->db->fetch_array($this->result))
				{
					// Validate the key
					$key = ((isset($row[$column]) AND $column) ? $column : key($row));
					$data[] = $row[$key];
				}
				return $data;
				break;
		}
	}

	/**
	 * Fetches the first column of the first row of the SQL result.
	 *
	 * @param string $sql An SQL SELECT statement.
	 * @param mixed  $bind Data to bind into SELECT placeholders.
	 * @param mixed  $column OPTIONAL - Key to use for the column index
	 * @return string
	 */
	public function fetchOne($sql, $bind = array(), $column = '')
	{
		$result = $this->fetchRow($sql, $bind);
		return ($column ? $result[$column] : (is_array($result) ? reset($result) : ''));
	}

	/**
	 * Prepares and executes an SQL statement with bound data.
	 *
	 * @param  mixed  $sql  The SQL statement with placeholders.
	 * @param  mixed  $bind An array of data to bind to the placeholders.
	 * @param  string Which query method to use
	 *
	 * @return mixed  Result
	 */
	public function query($sql, $bind = array(), $which = 'query_read')
	{
		// make sure $bind is an array
		if (!is_array($bind))
		{
			$bind = (array)$bind;
		}

		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				// Set the table prefix
				$sql = $this->replaceTablePrefix($sql);

				if ($this->debug)
				{
					echo "<pre>";
					echo $sql;
					echo "</pre>";
					die();
				}

				// Execute the query
				$this->result = $this->db->query($sql, $bind, Zend_Db::FETCH_ASSOC);
				break;

			case 'vBulletin':
				if (!in_array($which, array('query_read', 'query_write', 'query_first')))
				{
					// Default to query read
					$which = 'query_read';
				}

				if (in_array($which, array('query_read', 'query_first')))
				{
					// Support slave servers
					$which .= '_slave';
				}

				foreach ($bind as $key => $val)
				{
					if (is_numeric($key))
					{
						// Sort string mapping
						$val = (is_numeric($val) ? "'$val'" : $this->quote($val));

						// Replace first instance of ?
						$sql = implode($val, explode('?', $sql, 2));
					}
				}

				foreach ($bind as $key => $val)
				{
					if (!is_numeric($key))
					{
						// Array of token replacements
						$sql = str_replace($key, $val, $sql);
					}
				}

				// Set the table prefix
				$sql = $this->replaceTablePrefix($sql);

				if ($this->debug)
				{
					echo "<pre>";
					echo $sql;
					echo "</pre>";
					die();
				}

				// Execute the query
				$this->result = $this->db->$which($sql);
				break;
		}

		return $this->result;
	}

	/**
	 * Helper function for IN statements for SQL queries.
	 * For example, with an array $userids = array(1, 2, 3, 4, 5);
	 * the query would be WHERE userid IN' . $this->queryList($userids) . '
	 *
	 * @param  array The array to work with
	 *
	 * @return mixed  Properly escaped and parenthesised IN() list
	 */
	public function queryList($arr)
	{
		$values = array();
		foreach ($arr as $val)
		{
			// Ensure the value is escaped properly
			$values[] = (is_numeric($val) ? "'$val'" : $this->quote($val));
		}

		if (!count($values))
		{
			// Ensure there's no SQL errors
			$values[] = "'0'";
		}

		return 'IN(' . implode(', ', $values) . ')';
	}

	/**
	* Returns an UPDATE or INSERT query string for use in big queries with loads of fields...
	*
	* @param	array	Array of fieldname = value pairs - array('userid' => 21, 'username' => 'John Doe')
	* @param	string	Name of the table into which the data should be saved
	* @param	string	SQL condition to add to the query string
	* @param	array	Array of field names that should be ignored from the $queryvalues array
	*
	* @return	string
	*/
	protected function constructSql($table, array $bind, $condition = '', array $exclusions = array(), $type = 'insert')
	{
		if (!empty($condition))
		{
			$querystring = array();
			foreach ($bind AS $fieldname => $value)
			{
				if (!preg_match('#^\w+$#', $fieldname))
				{
					continue;
				}
				$querystring[] = "`$fieldname` = ?";
			}
			return "UPDATE xf_{$table} SET\n" . implode(', ', $querystring) . " $condition";
		}
		else
		{
			$fields = $values = array();
			foreach ($bind AS $fieldname => $value)
			{
				if (!preg_match('#^\w+$#', $fieldname))
				{
					continue;
				}
				$fields[] = '`' . $fieldname . '`';
				$values[] = '?';
			}

			switch ($type)
			{
				case 'ignore':
					$which = 'INSERT IGNORE INTO';
					break;

				case 'replace':
					$which = 'REPLACE INTO';
					break;

				default:
					$which = 'INSERT INTO';
					break;
			}

			return "$which xf_{$table}\n\t(" . implode(', ', $fields) . ")\nVALUES\n\t(" . implode(', ', $values) . ")";
		}
	}

	protected function affectedRows($result = NULL)
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return $result->rowCount();
				break;

			case 'vBulletin':
				return $this->db->affected_rows();
				break;
		}
	}

	protected function insertId($result = NULL)
	{
		switch (DBTech_Shout_Core::getSystem())
		{
			case 'XenForo':
				return $this->db->lastInsertId();
				break;

			case 'vBulletin':
				return $this->db->insert_id();
				break;
		}
	}

	protected function replaceTablePrefix($sql)
	{
		return preg_replace('/\s+(`?)\$/U', ' $1' . (DBTech_Shout_Core::getSystem() == 'vBulletin' ? TABLE_PREFIX : 'xf_'), $sql);
	}
}
?>