<?php
// #############################################################################
/**
* Starts Gzip encoding and prints out the main control panel page start / header
*
* @param	string	The page title
* @param	string	Javascript functions to be run on page start - for example "alert('moo'); alert('baa');"
* @param	string	Code to be inserted into the <head> of the page
* @param	integer	Width in pixels of page margins (default = 0)
* @param	string	HTML attributes for <body> tag - for example 'bgcolor="red" text="orange"'
*/
function print_cp_header($title = '', $onload = '', $headinsert = '', $marginwidth = 0, $bodyattributes = '')
{
	DBTech_Shout_Core_Admin::setParam('output', 'title', $title);
	DBTech_Shout_Core_Admin::setOutput("
		<script>
		$(function() {
			$('input[name=\"allbox\"]').click(function(){
			    $('input:checkbox').not(this).prop('checked', this.checked);
			});
		});
		</script>
	");
}

// #############################################################################
/**
* Prints the page footer, finishes Gzip encoding and terminates execution
*/
function print_cp_footer()
{
	DBTech_Shout_Core_Admin::renderOutput(DBTech_Shout_Core_Admin::getOutput());
}

// #############################################################################
/**
* Halts execution and shows a message based upon a parsed phrase
*
* After the first parameter, this function can take any number of additional
* parameters, in order to replace {1}, {2}, {3},... {n} variable place holders
* within the given phrase text. The parsed phrase is then passed to print_cp_message()
*
* Note that a redirect can be performed if CP_REDIRECT is defined with a URL
*
* @param	string	Name of phrase (from the Error phrase group)
* @param	string	1st variable replacement {1}
* @param	string	2nd variable replacement {2}
* @param	string	Nth variable replacement {n}
*/
function print_stop_message($phrasename)
{
	$params = func_get_args();
	unset($params[0]);

	$constructedParams = array();
	foreach ($params as $key => $param)
	{
		$constructedParams["param$key"] = $param;
	}

	$output = DBTech_Shout_Core_Admin::phrase($phrasename, $constructedParams);

	if (defined('CP_REDIRECT'))
	{
		$output .= '<script type="text/javascript">window.location="' . XenForo_Link::convertUriToAbsoluteUri(CP_REDIRECT, true) . '";</script>';
	}

	DBTech_Shout_Core_Admin::renderOutput($output);
}

// #############################################################################
/**
* Prints the standard form header, setting target script and action to perform
*
* @param	string	PHP script to which the form will submit (ommit file suffix)
* @param	string	'do' action for target script
* @param	boolean	Whether or not to include an encoding type for the form (for file uploads)
* @param	boolean	Whether or not to add a <table> to give the form structure
* @param	string	Name for the form - <form name="$name" ... >
* @param	string	Width for the <table> - default = '90%'
* @param	string	Value for 'target' attribute of form
* @param	boolean	Whether or not to place a <br /> before the opening form tag
* @param	string	Form method (GET / POST)
* @param	integer	CellSpacing for Table
*/
function print_form_header($phpscript = '', $do = '', $uploadform = false, $addtable = true, $name = 'cpform', $width = '90%', $target = '', $echobr = true, $method = 'post', $cellspacing = 0, $border_collapse = false, $formid = '')
{
	global $formOptions;

	$formOptions['id'] = $name;
	$formOptions['name'] = $name;
	$formOptions['method'] = $method;
	$formOptions['action'] = "admincp/$phpscript.php?do=$do";
	$formOptions['upload'] = $uploadform;
}


// #############################################################################
/**
* This does nothing as we don't use tables
*/
function print_table_start()
{
}

// #############################################################################
/**
* This does nothing as we don't use tables
*/
function print_table_break()
{
}

// #############################################################################
/**
* Adds an entry to the $_HIDDENFIELDS array for later printing as an <input type="hidden" />
*
* @param	string	Name for hidden field
* @param	string	Value for hidden field
* @param	boolean	Whether or not to htmlspecialchars the hidden field value
*/
function construct_hidden_code($name, $value = '', $htmlise = true)
{
	global $_HIDDENFIELDS;

	$_HIDDENFIELDS[$name] = ($htmlise ? htmlspecialchars($value) : $value);
}


// #############################################################################
/**
* Makes a column-spanning bar with a named <A> and a title, then  reinitialises the background class counter.
*
* @param	string	Title for the row
* @param	integer	Number of columns to span
* @param	boolean	Whether or not to htmlspecialchars the title
* @param	string	Name for <a name=""> anchor tag
* @param	string	Alignment for the title (center / left / right)
* @param	boolean	Whether or not to show the help button in the row
*/
function print_table_header($title, $colspan = 2, $htmlise = false, $anchor = '', $align = 'center', $helplink = true)
{
	if (!$anchor)
	{
		DBTech_Shout_Core_Admin::setOutput(
			"\n<div class=\"heading\" style=\"margin-bottom:0\">$title</div>\n",
			'table'
		);
	}
	else if ($helplink)
	{
		DBTech_Shout_Core_Admin::setOutput(
			$title,
			'tableSectionFooter'
		);
	}
}

// #############################################################################
/**
* Prints a row containing an arbitrary number of cells, each containing arbitrary HTML
*
* @param	array	Each array element contains the HTML code for one cell. If the array contains 4 elements, 4 cells will be printed
* @param	boolean	If true, make all cells' contents bold and use the 'thead' CSS class
* @param	mixed	If specified, override the alternating CSS classes with the specified class
* @param	integer	Cell offset - controls alignment of cells... best to experiment with small +ve and -ve numbers
* @param	string	Vertical alignment for the row
* @param	boolean	Whether or not to treat the cells as part of columns - will alternate classes horizontally instead of vertically
* @param	boolean	Whether or not to use 'smallfont' for cell contents
*/
function print_cells_row($array, $isheaderrow = false, $class = false, $i = 0, $valign = 'top', $column = false, $smallfont = false, $helpname = NULL)
{
	static $counter;
	if (!is_array($array))
	{
		DBTech_Shout_Core_Admin::setOutput("<tr><td class=\"sectionFooter\" colspan=\"$counter\">" . DBTech_Shout_Core_Admin::getOutput('tableSectionFooter') . "</td></tr>", 'table');
		DBTech_Shout_Core_Admin::setOutput("</table></div>", 'table');
		DBTech_Shout_Core_Admin::setOutput('', 'tableSectionFooter', true);

		$counter = 0;
		return;
	}

	if ($isheaderrow)
	{
		$counter = count($array);
		DBTech_Shout_Core_Admin::setOutput("
			<div class=\"dataTableWrapper\">
			<table class=\"dataTable\" style=\"table-layout: fixed; min-width: 450px; margin-top:0\">
			<tr class=\"dataRow\">
		", 'table');

		foreach ($array as $val)
		{
			DBTech_Shout_Core_Admin::setOutput("
					<th>$val</th>
			", 'table');
		}

		DBTech_Shout_Core_Admin::setOutput("
			</tr>
		", 'table');
	}
	else
	{
		DBTech_Shout_Core_Admin::setOutput("
			<tr class=\"dataRow\">
		", 'table');

		foreach ($array as $val)
		{
			DBTech_Shout_Core_Admin::setOutput("
					<td>$val</td>
			", 'table');
		}

		DBTech_Shout_Core_Admin::setOutput("
			</tr>
		", 'table');
	}
}

// #############################################################################
/**
* Returns a hyperlink
*
* @param	string	Hyperlink text
* @param	string	Hyperlink URL
* @param	boolean	If true, hyperlink target="_blank"
* @param	string	If specified, parameter will be used as title="x" tooltip for link
*
* @param	string
*/
function construct_link_code($text, $url, $newwin = false, $tooltip = '', $smallfont = false)
{
	if ($newwin === true OR $newwin === 1)
	{
		$newwin = '_blank';
	}

	return ($smallfont ? '<span class="smallfont">' : '') . " <a href=\"admincp/$url\"" . ($newwin ? " target=\"$newwin\"" : '') . (!empty($tooltip) ? " title=\"$tooltip\"" : '') . '>' . "[$text]</a> " . ($smallfont ? '</span>' : '');
}


// #############################################################################
/**
* Prints submit and reset buttons for the current form, then closes the form and table tags
*
* @param	string	Value for submit button - if left blank, will use DBTech_Shout_Core_Admin::phrase('save')
* @param	string	Value for reset button - if left blank, will use DBTech_Shout_Core_Admin::phrase('reset')
* @param	integer	Number of table columns the cell containing the buttons should span
* @param	string	Optional value for 'Go Back' button
* @param	string	Optional arbitrary HTML code to add to the table cell
* @param	boolean	If true, reverses the order of the buttons in the cell
*/
function print_submit_row($submitname = '', $resetname = '_default_', $colspan = 2, $goback = '', $extra = '', $alt = false)
{
	// do submit button
	if ($submitname === '_default_' OR $submitname === '')
	{
		$submitname = DBTech_Shout_Core_Admin::phrase('save');
	}

	if ($resetname)
	{
		if ($resetname === '_default_')
		{
			$resetname = DBTech_Shout_Core_Admin::phrase('reset');
		}
	}

	print_table_footer($colspan, XenForo_Template_Helper_Admin::submitUnit($extra, array('save' => $submitname, 'reset' => $resetname)));
}


// #############################################################################
/**
* Prints a closing table tag and closes the form tag if it is open
*
* @param	integer	Column span of the optional table row to be printed
* @param	string	If specified, creates an additional table row with this code as its contents
* @param	string	Tooltip for optional table row
* @param	boolean	Whether or not to close the <form> tag
*/
function print_table_footer($colspan = 2, $rowhtml = '', $tooltip = '', $echoform = true)
{
	global $_HIDDENFIELDS, $formOptions;

	if ($echoform AND is_array($formOptions) AND sizeof($formOptions))
	{
		DBTech_Shout_Core_Admin::setOutput($rowhtml, 'table');

		if (is_array($_HIDDENFIELDS))
		{
			//DEVDEBUG("Do hidden fields...");
			foreach($_HIDDENFIELDS AS $name => $value)
			{
				DBTech_Shout_Core_Admin::setOutput("<input type=\"hidden\" name=\"$name\" value=\"$value\" />\n", 'table');
				//DEVDEBUG("> hidden field: $name='$value'");
			}
		}
		$_HIDDENFIELDS = array();

		DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::form(DBTech_Shout_Core_Admin::getOutput('table'), $formOptions));
		DBTech_Shout_Core_Admin::setOutput('', 'table', true);
		DBTech_Shout_Core_Admin::setOutput('', 'tableSectionFooter', true);
	}
	else if ($rowhtml != '  &nbsp;  ')
	{
		DBTech_Shout_Core_Admin::setOutput("<p class=\"sectionFooter\"$tooltip>$rowhtml</p>\n", 'table');
	}
}

// #############################################################################
/**
* Prints a column-spanning row containing arbitrary HTML
*
* @param	string	HTML contents for row
* @param	boolean	Whether or not to htmlspecialchars the row contents
* @param	integer	Number of columns to span
* @param	string	Optional CSS class to override the alternating classes
* @param	string	Alignment for row contents
* @param	string	Name for help button
*/
function print_description_row($text, $htmlise = false, $colspan = 2, $class = '', $align = '')
{
	DBTech_Shout_Core_Admin::setOutput("<p class=\"" . ($class ? 'secondaryContent' : 'primaryContent') . "\">" . ($htmlise ? htmlspecialchars($text) : $text) . "</p>\n", 'table');
}

// #############################################################################
/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function print_input_row($title, $name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::textBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, array('explain' => isset($matches[1]) ? $matches[1] : ''), array('size' => $size, 'maxlength' => $maxlength)), 'table');
}

// #############################################################################
/**
* Prints a row containing 'yes', 'no' <input type="radio" / > buttons
*
* @param	string	Title for row
* @param	string	Name for radio buttons
* @param	string	Selected button's value
* @param	string	Optional Javascript code to run when radio buttons are clicked - example: ' onclick="do_something()"'
*/
function print_yes_no_row($title, $name, $value = 1, $onclick = '')
{
	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::radioUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, array(1 => DBTech_Shout_Core_Admin::phrase('yes'), 0 => DBTech_Shout_Core_Admin::phrase('no')), array('explain' => isset($matches[1]) ? $matches[1] : '')), 'table');
}

// #############################################################################
/**
* Prints a row containing a <select> field
*
* @param	string	Title for row
* @param	string	Name for select field
* @param	array	Array of value => text pairs representing '<option value="$key">$value</option>' fields
* @param	string	Selected option
* @param	boolean	Whether or not to htmlspecialchars the text for the options
* @param	integer	Size of select field (non-zero means multi-line)
* @param	boolean	Whether or not to allow multiple selections
*/
function print_select_row($title, $name, $array, $selected = '', $htmlise = false, $size = 0, $multiple = false)
{
	if ($multiple)
	{
		// vB wants you to specify this, xF does not
		$name = str_replace('[]', '', $name);
	}

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::selectUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $selected, $array, array('explain' => isset($matches[1]) ? $matches[1] : ''), array('size' => $size, 'multiple' => $multiple)), 'table');
}

// #############################################################################
/**
* Prints a row containing a number of <input type="checkbox" /> fields representing a user's membergroups
*
* @param	string	Title for row
* @param	string	Base name for checkboxes - $name[]
* @param	integer	Number of columns to split checkboxes into
* @param	mixed	Either NULL or a user info array
*/
function print_membergroup_row($title, $name = 'membergroup', $columns = 0, $userarray = NULL)
{
	// create a blank user array if one is not set
	if (!is_array($userarray))
	{
		$userarray = array('membergroupids' => '');
	}

	$options = array(
		array('name' => $name . '[]', 'label' => DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_all_usergroups'), 'value' => -1, 'selected' => (strpos(",$userarray[membergroupids],", ",-1,") !== false))
	);
	foreach(DBTech_Shout_Core_Admin::$usergroupcache AS $usergroupid => $usergroup)
	{
		// don't show the user's primary group (if set)
		$options[] = array('name' => $name . '[]', 'label' => $usergroup['title'], 'value' => $usergroupid, 'selected' => (strpos(",$userarray[membergroupids],", ",$usergroupid,") !== false));
	}

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::checkBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), '', $options, array('explain' => isset($matches[1]) ? $matches[1] : '')), 'table');
}

// #############################################################################
/**
* Prints a row containing form elements to input a date & time
*
* Resulting form element names: $name[day], $name[month], $name[year], $name[hour], $name[minute]
*
* @param	string	Title for row
* @param	string	Base name for form elements - $name[day], $name[month], $name[year] etc.
* @param	mixed	Unix timestamp to be represented by the form fields OR SQL date field (yyyy-mm-dd)
* @param	boolean	Whether or not to show the time input components, or only the date
* @param	boolean	If true, expect an SQL date field from the unix timestamp parameter instead (for birthdays)
* @param	string	Vertical alignment for the row
*/
function print_time_row($title, $name = 'date', $unixtime = '', $showtime = true, $birthday = false, $valign = 'middle')
{
	$month = $day = $year = $hour = $minute = '';

	if ($birthday)
	{
		if ($unixtime == '')
		{
			$month = 0;
			$day = '';
			$year = '';
		}
		else
		{
			$temp = explode('-', $unixtime);
			$month = intval($temp[0]);
			$day = intval($temp[1]);
			if ($temp[2] == '0000')
			{
				$year = '';
			}
			else
			{
				$year = intval($temp[2]);
			}
		}
	}
	else
	{
		if ($unixtime)
		{
			$month = DBTech_Shout_Core_Admin::date('n', $unixtime);
			$day = DBTech_Shout_Core_Admin::date('j', $unixtime);
			$year = DBTech_Shout_Core_Admin::date('Y', $unixtime);
			$hour = DBTech_Shout_Core_Admin::date('G', $unixtime);
			$minute = DBTech_Shout_Core_Admin::date('i', $unixtime);
		}
	}

	$choices = array(
		'' => '',
		1 => DBTech_Shout_Core_Admin::phrase('month_1'),
		2 => DBTech_Shout_Core_Admin::phrase('month_2'),
		3 => DBTech_Shout_Core_Admin::phrase('month_3'),
		4 => DBTech_Shout_Core_Admin::phrase('month_4'),
		5 => DBTech_Shout_Core_Admin::phrase('month_5'),
		6 => DBTech_Shout_Core_Admin::phrase('month_6'),
		7 => DBTech_Shout_Core_Admin::phrase('month_7'),
		8 => DBTech_Shout_Core_Admin::phrase('month_8'),
		9 => DBTech_Shout_Core_Admin::phrase('month_9'),
		10 => DBTech_Shout_Core_Admin::phrase('month_10'),
		11 => DBTech_Shout_Core_Admin::phrase('month_11'),
		12 => DBTech_Shout_Core_Admin::phrase('month_12'),
	);

	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::select($name . '_month', $month, $choices, array('inputclass' => 'autoSize')), 'timerow');
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::textBox($name . '_day', $day, array('inputclass' => 'autoSize', 'placeholder' => DBTech_Shout_Core_Admin::phrase('day'))), 'timerow');
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::textBox($name . '_year', $year, array('inputclass' => 'autoSize', 'placeholder' => DBTech_Shout_Core_Admin::phrase('year'))), 'timerow');

	if ($showtime)
	{
		DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::textBox($name . '_hour', $hour, array('inputclass' => 'autoSize', 'placeholder' => DBTech_Shout_Core_Admin::phrase('hour'))), 'timerow');
		DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::textBox($name . '_minute', $minute, array('inputclass' => 'autoSize', 'placeholder' => DBTech_Shout_Core_Admin::phrase('minute'))), 'timerow');
	}

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::controlUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), array('html' => DBTech_Shout_Core_Admin::getOutput('timerow'), 'explain' => isset($matches[1]) ? $matches[1] : '')), 'table');

	DBTech_Shout_Core_Admin::setOutput('', 'timerow', true);
}

// #############################################################################
/**
* Returns a 'depth mark' for use in prefixing items that need to show depth in a hierarchy
*
* @param	integer	Depth of item (0 = no depth, 3 = third level depth)
* @param	string	Character or string to repeat $depth times to build the depth mark
* @param	string	Existing depth mark to append to
*
* @return	string
*/
function construct_depth_mark($depth, $depthchar, $depthmark = '')
{
	for ($i = 0; $i < $depth; $i++)
	{
		$depthmark .= $depthchar;
	}
	return $depthmark;
}

// #############################################################################
/**
* Prints a two-cell row with arbitrary contents in each cell
*
* @param	string	HTML contents for first cell
* @param	string	HTML comments for second cell
* @param	string	CSS class for row - if not specified, uses alternating alt1/alt2 classes
* @param	string	Vertical alignment attribute for row (top / bottom etc.)
* @param	string	Name for help button
* @param	boolean	If true, set first cell to 30% width and second to 70%
*/
function print_label_row($title, $value = '&nbsp;', $class = '', $valign = 'top', $helpname = NULL, $dowidth = false)
{
	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::controlUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), array('html' => $value, 'explain' => isset($matches[1]) ? $matches[1] : '')), 'table');
}

// #############################################################################
/**
* Prints a row containing a <textarea>
*
* @param	string	Title for row
* @param	string	Name for textarea field
* @param	string	Value for textarea field
* @param	integer	Number of rows for textarea field
* @param	integer	Number of columns for textarea field
* @param	boolean	Whether or not to htmlspecialchars the textarea field value
* @param	boolean	Whether or not to show the 'large edit box' button
* @param	string	Text direction for textarea field
* @param	mixed	If specified, overrides the default CSS class for the textare field
*/
function print_textarea_row($title, $name, $value = '', $rows = 4, $cols = 40, $htmlise = true, $doeditbutton = true, $direction = '', $textareaclass = false)
{
	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::textBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, array('explain' => isset($matches[1]) ? $matches[1] : ''), array('size' => $cols, 'rows' => $rows)), 'table');
}

// #############################################################################
/**
 * Constructs a bitfield row
 *
 * @param	string	The label text
 * @param	string	The name of the row for the form
 * @param	string	What bitfields we are using
 * @param	integer	The value of the setting
 */
function print_bitfield_row($title, $name, $bitfield, $value)
{
	$value = intval($value);
	$HTML = '';
	$bitfielddefs = DBTech_Shout_Core::fetchBitfield($bitfield);

	if ($bitfielddefs === NULL)
	{
		print_label_row($title, "<strong>An error occurred fetching the bitfields</strong>", '', 'top', $name, 40);
	}
	else
	{
		$options = array();
		foreach ($bitfielddefs AS $key => $val)
		{
			// don't show the user's primary group (if set)
			$options[] = array('name' => "{$name}[$val]", 'label' => DBTech_Shout_Core_Admin::phrase($key), 'value' => $val, 'selected' => ($value & $val));
		}

		preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
		DBTech_Shout_Core_Admin::setOutput(XenForo_Template_Helper_Admin::checkBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), '', $options, array('explain' => isset($matches[1]) ? $matches[1] : '')), 'table');
	}
}

// #############################################################################
/**
* Prints a dialog box asking if the user is sure they want to delete the specified item from the database
*
* @param	string	Name of table from which item will be deleted
* @param	mixed		ID of item to be deleted
* @param	string	PHP script to which the form will submit
* @param	string	'do' action for target script
* @param	string	Word describing item to be deleted - eg: 'forum' or 'user' or 'post' etc.
* @param	mixed		If not empty, an array containing name=>value pairs to be used as hidden input fields
* @param	string	Extra text to be printed in the dialog box
* @param	string	Name of 'title' field in the table in the database
* @param	string	Name of 'idfield' field in the table in the database
*/
function print_delete_confirmation($table, $itemid, $phpscript, $do, $itemname = '', $hiddenfields = 0, $extra = '', $titlename = 'title', $idfield = '')
{
	$idfield = $idfield ? $idfield : $table . 'id';
	$itemname = $itemname ? $itemname : $table;
	$deleteword = 'delete';
	$encodehtml = true;


	$item = DBTech_Shout_Core_Admin::$db->fetchRow('
		SELECT ' . $idfield . ', ' . $titlename . ' AS title
		FROM $' . $table . '
		WHERE ' . $idfield . ' = ' . $itemid
	);

	if ($encodehtml
		AND (strcspn($item['title'], '<>"') < strlen($item['title'])
			OR (strpos($item['title'], '&') !== false AND !preg_match('/&(#[0-9]+|amp|lt|gt|quot);/si', $item['title']))
		)
	)
	{
		// title contains html entities that should be encoded
		$item['title'] = htmlspecialchars($item['title']);
	}

	if ($item[$idfield] == $itemid AND !empty($itemid))
	{
		print_form_header($phpscript, $do, 0, 1, '', '75%');
		construct_hidden_code(($idfield == 'styleid' OR $idfield == 'languageid') ? 'do' . $idfield : $idfield, $itemid);
		if (is_array($hiddenfields))
		{
			foreach($hiddenfields AS $varname => $value)
			{
				construct_hidden_code($varname, $value);
			}
		}

		print_table_header(DBTech_Shout_Core_Admin::phrase('dbtech_vbshout_confirm_deletion_x', array('param1' => $item['title'])), 2, false, ' ');
		print_description_row("
			<blockquote><br />
			" . DBTech_Shout_Core_Admin::phrase("are_you_sure_want_to_{$deleteword}_{$itemname}_x", array(
				'param1' => $item['title'],
				'param2' => $idfield,
				'param3' => $item["$idfield"],
				'param4' => ($extra ? "$extra<br /><br />" : '')
			)) . "
			<br /></blockquote>\n\t");
		print_submit_row(DBTech_Shout_Core_Admin::phrase('yes'), 0, 2, DBTech_Shout_Core_Admin::phrase('no'));
	}
	else
	{
		print_stop_message('could_not_find', '<b>' . $itemname . '</b>', $idfield, $itemid);
	}
}

// #############################################################################
/**
* Returns an <input type="button" /> that acts like a hyperlink
*
* @param	string	Value for button
* @param	string	Hyperlink URL; special cases 'submit' and 'reset'
* @param	boolean	If true, hyperlink will open in a new window
* @param	string	If specified, parameter will be used as title="x" tooltip for button
* @param	boolean	If true, the hyperlink URL parameter will be treated as a javascript function call instead
*
* @return	string
*/
function construct_button_code($text = 'Click!', $link = '', $newwindow = false, $tooltip = '', $jsfunction = 0)
{
	if (preg_match('#^(submit|reset),?(\w+)?$#siU', $link, $matches))
	{
		$name_attribute = ($matches[2] ? " name=\"$matches[2]\"" : '');
		return " <input type=\"$matches[1]\"$name_attribute class=\"button\" value=\"$text\" title=\"$tooltip\" tabindex=\"1\" />";
	}
	else
	{
		return " <input type=\"button\" class=\"button\" value=\"$text\" title=\"$tooltip\" tabindex=\"1\" onclick=\"" . ($jsfunction ? $link : ($newwindow ? "window.open('$link')" : "window.location='$link'")) . ";\"$tooltip/> ";
	}
}
?>