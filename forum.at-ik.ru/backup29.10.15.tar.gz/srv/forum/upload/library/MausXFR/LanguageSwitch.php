<?php

class MausXFR_LanguageSwitch
{
	static function getClientLanguagePreferences()
	{
		$result = array();
		$headerValue = str_replace(' ', '', $_SERVER['HTTP_ACCEPT_LANGUAGE']);
		foreach (explode(';', $headerValue) as $langs)
		{
			$q = '1.0'; $langarr = array();
			foreach (explode(',', $langs) as $item)
			{
				if (strpos($item, 'q=') === 0)
				{
					$q = substr($item, 2);
				}
				else
				{
					$langarr[] = strtolower($item);
				}
			}
			if (!empty($langarr))
			{
				$result[$q] = $langarr;
			}
		}
		krsort($result);
		
		$result_plain = array();
		foreach ($result as $langarr) {
			$result_plain = array_merge($result_plain, $langarr);
		}
		return $result_plain;
	}

	static function getClientPreferredLanguageId()
	{
		$languageModel = XenForo_Model::create('XenForo_Model_Language');
		$languageList = $languageModel->getAllLanguages();
		$languageCodes = array();
		foreach ($languageList as $language)
		{
			$languageCodes[strtolower($language['language_code'])] = $language['language_id'];
		}

		$languagePreferences = MausXFR_LanguageSwitch::getClientLanguagePreferences();

		$preferredLanguageId = null;
		foreach($languagePreferences as $preferenceCode)
		{
			foreach(array_keys($languageCodes) as $code)
			{
				$found = ($code == $preferenceCode);

				if (!$found) {
					$a = explode('-', $code);
					$b = explode('-', $preferenceCode);
					$found = $a[0] == $b[0];
				}

				if ($found) {
					$preferredLanguageId = $languageCodes[$code];
					break 2;
				}
			}
		}

		return $preferredLanguageId;
	}

	static function controller_pre_dispatch($controller, $action)
	{
		if (XenForo_Application::get('session')->sessionExists())
			return;

		$langId = MausXFR_LanguageSwitch::getClientPreferredLanguageId();

		if ($langId !== null)
			XenForo_Visitor::getInstance()->setVisitorLanguage($langId);
	}
}
