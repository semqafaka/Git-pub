<?php

class Spoiler_formatter extends XFCP_Spoiler_formatter
{
	protected $_tags;

	public function getTags()
	{
		$this->_tags = parent::getTags();

		$this->_tags['spoiler'] = array(
			'trimLeadingLinesAfter' => 1,
			'callback' => array($this, 'renderTagSpoiler')
		);

		return $this->_tags;
	}

	public function renderTagSpoiler(array $tag, array $rendererStates)
	{
		$content = $this->renderSubTree($tag['children'], $rendererStates);
		$spoiler = $tag['option'];

		if ($this->_view)
		{
			$template = $this->_view->createTemplateObject('RT_Spoiler', array(
				'content' => $content,
				'spoiler' => $spoiler
			));
			return $template->render();
		}
		else
		{
			$name = '<div>' . new XenForo_Phrase('RT_Spoiler_warning') . ($spoiler ? ': '.$spoiler : '') . '</div>';
			return '<blockquote>' . $name . $content . '</blockquote>';
		}
	}
}