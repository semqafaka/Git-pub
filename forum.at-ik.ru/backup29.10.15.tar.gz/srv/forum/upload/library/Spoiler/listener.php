<?php

class Spoiler_listener
{
	public static function listen($class, array &$extend)
	{
		if ($class == 'XenForo_BbCode_Formatter_Base')
		{
			$extend[] = 'Spoiler_formatter';
		}
	}
}